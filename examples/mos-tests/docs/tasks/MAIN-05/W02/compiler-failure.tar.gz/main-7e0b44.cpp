# 1 "<built-in>"
# 1 "src/main.cpp"
#if 0 /* expanded by -frewrite-includes */
#include "generated.h"
#endif /* expanded by -frewrite-includes */
# 1 "src/main.cpp"
# 1 "./include/generated.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "./include/generated.h"
#if 0 /* expanded by -frewrite-includes */
#include "../../runner/include/catalogue_generated.h"
#endif /* expanded by -frewrite-includes */
# 2 "./include/generated.h"
# 1 "./include/../../runner/include/catalogue_generated.h" 1
// Generated from catalogue/catalogue.json; do not edit.
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 3 "./include/../../runner/include/catalogue_generated.h"
#if 0 /* expanded by -frewrite-includes */
#include "lifecycle.h"
#endif /* expanded by -frewrite-includes */
# 3 "./include/../../runner/include/catalogue_generated.h"
# 1 "../runner/include/lifecycle.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "../runner/include/lifecycle.h"
#if 0 /* expanded by -frewrite-includes */
#include <stdint.h>
#endif /* expanded by -frewrite-includes */
# 2 "../runner/include/lifecycle.h"
# 1 "/home/smith/Agon/agondev/release/include/stdint.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#ifndef _STDINT_H
#define _STDINT_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/stdint.h" 3
# 1 "/home/smith/Agon/agondev/release/include/cdefs.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef _CDEFS_H
#define _CDEFS_H

#define __JOIN2(x, y)     x ## y
#define __JOIN3(x, y, z)  x ## y ## z
#define __CONCAT(x, y)    __JOIN2(x, y)
#define __TOSTRING(x)     #x

#define __STDINT_C(C, T)  __CONCAT(C, __##T##_C_SUFFIX__)
#define __STDINT_WIDTH(T) (sizeof(__##T##_TYPE__)*__CHAR_BIT__)

#ifndef __cplusplus
# define __BEGIN_DECLS
# define __END_DECLS
# define __NOEXCEPT     __attribute__((__nothrow__, __leaf__))
# define __IGNORE(expr) ((void)(expr))
#else /* __cplusplus */
# 22 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
# define __BEGIN_DECLS  extern "C" {
# define __END_DECLS    }
# define __NOEXCEPT     noexcept
# define __IGNORE(expr) (static_cast<void>(expr))
#endif /* __cplusplus */
# 27 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef NULL
# ifndef __cplusplus
#  define NULL ((void *)0)
# else /* __cplusplus */
# 32 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
#  define NULL 0
# endif /* __cplusplus */
# 34 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
#endif /* NULL */
# 35 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef SIZE_T_DEFINED
#define SIZE_T_DEFINED
typedef __SIZE_TYPE__ size_t;
#endif /* SIZE_T_DEFINED */
# 40 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#endif /* _CDEFS_H */
# 42 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifdef __cplusplus
}
#endif
# 46 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
# 9 "/home/smith/Agon/agondev/release/include/stdint.h" 2 3

typedef          __INT8_TYPE__                        int8_t;
#define            INT8_MIN                       (~__INT8_MAX__)
#define            INT8_MAX                         __INT8_MAX__
#define            INT8_WIDTH          __STDINT_WIDTH(INT8)
#define            INT8_C(C)            __STDINT_C(C, INT8)
typedef         __UINT8_TYPE__                       uint8_t;
#define           UINT8_MAX                        __UINT8_MAX__
#define           UINT8_WIDTH         __STDINT_WIDTH(UINT8)
#define           UINT8_C(C)           __STDINT_C(C, UINT8)
typedef     __INT_FAST8_TYPE__                   int_fast8_t;
#define       INT_FAST8_MIN                  (~__INT_FAST8_MAX__)
#define       INT_FAST8_MAX                    __INT_FAST8_MAX__
#define       INT_FAST8_WIDTH     __STDINT_WIDTH(INT_FAST8)
typedef    __UINT_FAST8_TYPE__                  uint_fast8_t;
#define      UINT_FAST8_MAX                   __UINT_FAST8_MAX__
#define      UINT_FAST8_WIDTH    __STDINT_WIDTH(UINT_FAST8)
typedef    __INT_LEAST8_TYPE__                  int_least8_t;
#define      INT_LEAST8_MIN                 (~__INT_LEAST8_MAX__)
#define      INT_LEAST8_MAX                   __INT_LEAST8_MAX__
#define      INT_LEAST8_WIDTH    __STDINT_WIDTH(INT_LEAST8)
typedef   __UINT_LEAST8_TYPE__                 uint_least8_t;
#define     UINT_LEAST8_MAX                  __UINT_LEAST8_MAX__
#define     UINT_LEAST8_WIDTH   __STDINT_WIDTH(UINT_LEAST8)

typedef         __INT16_TYPE__                       int16_t;
#define           INT16_MIN                      (~__INT16_MAX__)
#define           INT16_MAX                        __INT16_MAX__
#define           INT16_WIDTH         __STDINT_WIDTH(INT16)
#define           INT16_C(C)           __STDINT_C(C, INT16)
typedef        __UINT16_TYPE__                      uint16_t;
#define          UINT16_MAX                       __UINT16_MAX__
#define          UINT16_WIDTH        __STDINT_WIDTH(UINT16)
#define          UINT16_C(C)          __STDINT_C(C, UINT16)
typedef    __INT_FAST16_TYPE__                  int_fast16_t;
#define      INT_FAST16_MIN                 (~__INT_FAST16_MAX__)
#define      INT_FAST16_MAX                   __INT_FAST16_MAX__
#define      INT_FAST16_WIDTH    __STDINT_WIDTH(INT_FAST16)
typedef   __UINT_FAST16_TYPE__                 uint_fast16_t;
#define     UINT_FAST16_MAX                  __UINT_FAST16_MAX__
#define     UINT_FAST16_WIDTH   __STDINT_WIDTH(UINT_FAST16)
typedef   __INT_LEAST16_TYPE__                 int_least16_t;
#define     INT_LEAST16_MIN                (~__INT_LEAST16_MAX__)
#define     INT_LEAST16_MAX                  __INT_LEAST16_MAX__
#define     INT_LEAST16_WIDTH   __STDINT_WIDTH(INT_LEAST16)
typedef  __UINT_LEAST16_TYPE__                uint_least16_t;
#define    UINT_LEAST16_MAX                 __UINT_LEAST16_MAX__
#define    UINT_LEAST16_WIDTH  __STDINT_WIDTH(UINT_LEAST16)

#ifdef          __INT24_TYPE__
typedef         __INT24_TYPE__                       int24_t;
#define           INT24_MIN                      (~__INT24_MAX__)
#define           INT24_MAX                        __INT24_MAX__
#define           INT24_WIDTH         __STDINT_WIDTH(INT24)
#define           INT24_C(C)           __STDINT_C(C, INT24)
typedef        __UINT24_TYPE__                      uint24_t;
#define          UINT24_MAX                       __UINT24_MAX__
#define          UINT24_WIDTH        __STDINT_WIDTH(UINT24)
#define          UINT24_C(C)          __STDINT_C(C, UINT24)
#endif        /*__INT24_TYPE_*/
# 69 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef         __INT32_TYPE__                       int32_t;
#define           INT32_MIN                      (~__INT32_MAX__)
#define           INT32_MAX                        __INT32_MAX__
#define           INT32_WIDTH         __STDINT_WIDTH(INT32)
#define           INT32_C(C)           __STDINT_C(C, INT32)
typedef        __UINT32_TYPE__                      uint32_t;
#define          UINT32_MAX                       __UINT32_MAX__
#define          UINT32_WIDTH        __STDINT_WIDTH(UINT32)
#define          UINT32_C(C)          __STDINT_C(C, UINT32)
typedef    __INT_FAST32_TYPE__                  int_fast32_t;
#define      INT_FAST32_MIN                 (~__INT_FAST32_MAX__)
#define      INT_FAST32_MAX                   __INT_FAST32_MAX__
#define      INT_FAST32_WIDTH    __STDINT_WIDTH(INT_FAST32)
typedef   __UINT_FAST32_TYPE__                 uint_fast32_t;
#define     UINT_FAST32_MAX                  __UINT_FAST32_MAX__
#define     UINT_FAST32_WIDTH   __STDINT_WIDTH(UINT_FAST32)
typedef   __INT_LEAST32_TYPE__                 int_least32_t;
#define     INT_LEAST32_MIN                (~__INT_LEAST32_MAX__)
#define     INT_LEAST32_MAX                  __INT_LEAST32_MAX__
#define     INT_LEAST32_WIDTH   __STDINT_WIDTH(INT_LEAST32)
typedef  __UINT_LEAST32_TYPE__                uint_least32_t;
#define    UINT_LEAST32_MAX                 __UINT_LEAST32_MAX__
#define    UINT_LEAST32_WIDTH  __STDINT_WIDTH(UINT_LEAST32)

#ifdef   __SIZEOF_INT48__
#define         __INT48_TYPE__              signed __int48
#define         __INT48_MAX__  ((__UINT48_TYPE__)(__UINT48_MAX__>>1))
typedef         __INT48_TYPE__                       int48_t;
#define           INT48_MIN                      (~__INT48_MAX__)
#define           INT48_MAX                        __INT48_MAX__
#define           INT48_WIDTH         __STDINT_WIDTH(INT48)
#define           INT48_C(C)                     ((__INT48_TYPE__)(INT64_C(C)))
#define        __UINT48_TYPE__            unsigned __int48
#define        __UINT48_MAX__                   ((__UINT48_TYPE__)~0)
typedef        __UINT48_TYPE__                      uint48_t;
#define          UINT48_MAX                       __UINT48_MAX__
#define          UINT48_WIDTH        __STDINT_WIDTH(UINT48)
#define          UINT48_C(C)                    ((__UINT48_TYPE__)(UINT64_C(C)))
#endif /*__SIZEOF_INT48__*/
# 109 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef         __INT64_TYPE__                       int64_t;
#define           INT64_MIN                      (~__INT64_MAX__)
#define           INT64_MAX                        __INT64_MAX__
#define           INT64_WIDTH         __STDINT_WIDTH(INT64)
#define           INT64_C(C)           __STDINT_C(C, INT64)
typedef        __UINT64_TYPE__                      uint64_t;
#define          UINT64_MAX                       __UINT64_MAX__
#define          UINT64_WIDTH        __STDINT_WIDTH(UINT64)
#define          UINT64_C(C)          __STDINT_C(C, UINT64)
typedef    __INT_FAST64_TYPE__                  int_fast64_t;
#define      INT_FAST64_MIN                 (~__INT_FAST64_MAX__)
#define      INT_FAST64_MAX                   __INT_FAST64_MAX__
#define      INT_FAST64_WIDTH    __STDINT_WIDTH(INT_FAST64)
typedef   __UINT_FAST64_TYPE__                 uint_fast64_t;
#define     UINT_FAST64_MAX                  __UINT_FAST64_MAX__
#define     UINT_FAST64_WIDTH   __STDINT_WIDTH(UINT_FAST64)
typedef   __INT_LEAST64_TYPE__                 int_least64_t;
#define     INT_LEAST64_MIN                (~__INT_LEAST64_MAX__)
#define     INT_LEAST64_MAX                  __INT_LEAST64_MAX__
#define     INT_LEAST64_WIDTH   __STDINT_WIDTH(INT_LEAST64)
typedef  __UINT_LEAST64_TYPE__                uint_least64_t;
#define    UINT_LEAST64_MAX                 __UINT_LEAST64_MAX__
#define    UINT_LEAST64_WIDTH  __STDINT_WIDTH(UINT_LEAST64)

#ifdef  __SIZEOF_INT128__
#define        __INT128_TYPE__             signed __int128
#define        __INT128_MAX__ ((__INT128_TYPE__)(__UINT128_MAX__>>1))
typedef        __INT128_TYPE__                      int128_t;
#define          INT128_MIN                     (~__INT128_MAX__)
#define          INT128_MAX                       __INT128_MAX__
#define          INT128_WIDTH        __STDINT_WIDTH(INT128)
#define       __UINT128_TYPE__           unsigned __int128
#define       __UINT128_MAX__                  ((__UINT128_TYPE__)~0)
typedef       __UINT128_TYPE__                     uint128_t;
#define         UINT128_MAX                      __UINT128_MAX__
#define         UINT128_WIDTH       __STDINT_WIDTH(UINT128)
#endif/*__SIZEOF_INT128__*/
# 147 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef        __INTMAX_TYPE__                      intmax_t;
#define          INTMAX_MIN                     (~__INTMAX_MAX__)
#define          INTMAX_MAX                       __INTMAX_MAX__
#define          INTMAX_WIDTH                     __INTMAX_WIDTH__
#define          INTMAX_C(C)          __STDINT_C(C, INTMAX)
typedef       __UINTMAX_TYPE__                     uintmax_t;
#define         UINTMAX_MAX                      __UINTMAX_MAX__
#define         UINTMAX_WIDTH                    __UINTMAX_WIDTH__
#define         UINTMAX_C(C)         __STDINT_C(C, UINTMAX)

typedef        __INTPTR_TYPE__                      intptr_t;
#define          INTPTR_MIN                     (~__INTPTR_MAX__)
#define          INTPTR_MAX                       __INTPTR_MAX__
#define          INTPTR_WIDTH                     __INTPTR_WIDTH__
typedef       __UINTPTR_TYPE__                     uintptr_t;
#define         UINTPTR_MAX                      __UINTPTR_MAX__
#define         UINTPTR_WIDTH                    __UINTPTR_WIDTH__

#define         PTRDIFF_MIN                    (~__PTRDIFF_MAX__)
#define         PTRDIFF_MAX                      __PTRDIFF_MAX__
#define         PTRDIFF_WIDTH                    __PTRDIFF_WIDTH__

#define            SIZE_MAX                         __SIZE_MAX__
#define            SIZE_WIDTH                       __SIZE_WIDTH__

#define            WINT_MIN                       (~__WINT_MAX__)
#define            WINT_MAX                         __WINT_MAX__
#define            WINT_WIDTH                       __WINT_WIDTH__

#ifndef _WCHAR_LIMITS_DEFINED
#define _WCHAR_LIMITS_DEFINED
#define           WCHAR_MIN                      (~__WCHAR_MAX__)
#define           WCHAR_MAX                        __WCHAR_MAX__
#define           WCHAR_WIDTH                      __WCHAR_WIDTH__
#endif
# 183 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#endif/*_STDINT_H*/
# 185 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#ifdef __cplusplus
}
#endif
# 189 "/home/smith/Agon/agondev/release/include/stdint.h" 3
# 3 "../runner/include/lifecycle.h" 2
#if 0 /* expanded by -frewrite-includes */
#include <stddef.h>
#endif /* expanded by -frewrite-includes */
# 3 "../runner/include/lifecycle.h"
# 1 "/home/smith/Agon/agondev/release/include/stddef.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#ifndef _STDDEF_H
#define _STDDEF_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/stddef.h" 3
# 1 "/home/smith/Agon/agondev/release/include/cdefs.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef _CDEFS_H
#define _CDEFS_H

#define __JOIN2(x, y)     x ## y
#define __JOIN3(x, y, z)  x ## y ## z
#define __CONCAT(x, y)    __JOIN2(x, y)
#define __TOSTRING(x)     #x

#define __STDINT_C(C, T)  __CONCAT(C, __##T##_C_SUFFIX__)
#define __STDINT_WIDTH(T) (sizeof(__##T##_TYPE__)*__CHAR_BIT__)

#ifndef __cplusplus
# define __BEGIN_DECLS
# define __END_DECLS
# define __NOEXCEPT     __attribute__((__nothrow__, __leaf__))
# define __IGNORE(expr) ((void)(expr))
#else /* __cplusplus */
# 22 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
# define __BEGIN_DECLS  extern "C" {
# define __END_DECLS    }
# define __NOEXCEPT     noexcept
# define __IGNORE(expr) (static_cast<void>(expr))
#endif /* __cplusplus */
# 27 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef NULL
# ifndef __cplusplus
#  define NULL ((void *)0)
# else /* __cplusplus */
# 32 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
#  define NULL 0
# endif /* __cplusplus */
# 34 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
#endif /* NULL */
# 35 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef SIZE_T_DEFINED
#define SIZE_T_DEFINED
typedef __SIZE_TYPE__ size_t;
#endif /* SIZE_T_DEFINED */
# 40 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#endif /* _CDEFS_H */
# 42 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifdef __cplusplus
}
#endif
# 46 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
# 9 "/home/smith/Agon/agondev/release/include/stddef.h" 2 3

#define offsetof(type, member) __builtin_offsetof(type, member)

typedef __PTRDIFF_TYPE__ ptrdiff_t;

#ifndef _WCHAR_T_DEFINED
#define _WCHAR_T_DEFINED
#ifndef __cplusplus
typedef __WCHAR_TYPE__ wchar_t;
#endif /* __cplusplus */
# 19 "/home/smith/Agon/agondev/release/include/stddef.h" 3
#endif /* _WCHAR_T_DEFINED */
# 20 "/home/smith/Agon/agondev/release/include/stddef.h" 3

typedef struct {
    long long    __max_align_ll __attribute__((__aligned__(__alignof__(  long long))));
    long double  __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
#ifdef __FLOAT128__
    __float128 __max_align_f128 __attribute__((__aligned__(__alignof__( __float128))));
#endif
# 27 "/home/smith/Agon/agondev/release/include/stddef.h" 3
} max_align_t;

#endif /* _STDDEF_H */
# 30 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#ifdef __cplusplus
}
#endif
# 34 "/home/smith/Agon/agondev/release/include/stddef.h" 3
# 4 "../runner/include/lifecycle.h" 2
namespace suite {
enum class Outcome : uint8_t { Passed=1, Failed, Observed, Skipped, Unsupported, Blocked, Error, Incomplete };
struct Result { Outcome outcome; uint32_t assertions, failed; const char* reason; };
struct Case { uint32_t key; const char *id, *function, *group; uint32_t required; };
struct Hooks {
    void* context;
    bool (*start)(void*, const Case&);
    Result (*execute)(void*, const Case&);
    bool (*finish)(void*, const Case&, const Result&);
    bool (*cleanup)(void*, const Case&);
};
struct Totals { uint32_t counts[8]; uint32_t terminal; bool complete; bool infrastructure_error; };
inline bool valid(const Result& r) {
    unsigned n=static_cast<unsigned>(r.outcome);
    if(n<1 || n>8 || r.failed>r.assertions) return false;
    if(r.outcome==Outcome::Passed) return r.assertions>0 && r.failed==0;
    if(!r.reason || !*r.reason) return false;
    if(r.outcome==Outcome::Failed) return r.failed>0;
    if(n>=3 && n<=6) return r.assertions==0 && r.failed==0;
    return true;
}
// Hooks provide durable boundaries. No production I/O or capture is implied here.
inline Totals run(const Case* const* plan, size_t count, uint32_t capabilities, const Hooks& h) {
    Totals t={};
    if(!count || !h.start || !h.execute || !h.finish || !h.cleanup) { t.infrastructure_error=true; return t; }
    // Validate the whole plan before any effect.
    for(size_t i=0;i<count;++i) {
        if(!plan[i] || !plan[i]->key) { t.infrastructure_error=true; return t; }
        for(size_t j=0;j<i;++j) if(plan[i]->key==plan[j]->key) { t.infrastructure_error=true; return t; }
    }
    for(size_t i=0;i<count;++i) {
        const Case& c=*plan[i];
        if(!h.start(h.context,c)) { t.infrastructure_error=true; return t; }
        const bool supported=(c.required & capabilities)==c.required;
        Result r=supported ? h.execute(h.context,c) : Result{Outcome::Unsupported,0,0,"missing capability"};
        if(!valid(r)) r={Outcome::Error,0,0,"invalid executor result"};
        // Finish means evidence committed; cleanup failure still makes the run incomplete.
        if(!h.finish(h.context,c,r)) { t.infrastructure_error=true; return t; }
        ++t.counts[static_cast<unsigned>(r.outcome)-1]; ++t.terminal;
        if(supported && !h.cleanup(h.context,c)) { t.infrastructure_error=true; return t; }
        if(r.outcome==Outcome::Error || r.outcome==Outcome::Incomplete) { t.infrastructure_error=true; return t; }
    }
    t.complete=true; return t;
}
}
# 4 "./include/../../runner/include/catalogue_generated.h" 2
static const char CATALOGUE_SHA256[]="7ee450ce126b2a23f17334c1abf6af2985075db1cd48423fc24ec30bb0f8c893";
static const suite::Case CASES[]={
{1,"control.preserve.001","synthetic_preserve","controls",0},
{2,"control.ix-upper.001","synthetic_clobber","controls",1},
{3,"control.uart-required.001","synthetic_capability","controls",2},
};
static constexpr size_t CASE_COUNT=sizeof(CASES)/sizeof(CASES[0]);
# 3 "./include/generated.h" 2
static const uint8_t BACKEND=1;
static const char* const FUNCTIONS[3]={"synthetic_preserve","synthetic_clobber","synthetic_capability"};
static const uint8_t CATALOGUE_DIGEST[32]={126,228,80,206,18,107,42,35,241,115,52,193,171,246,175,41,133,7,93,177,205,72,66,63,194,78,195,11,176,248,200,147};
static const uint8_t CASE_HASHES[3][64]={{133,23,240,171,98,27,36,224,8,227,89,28,42,100,5,141,30,140,107,203,198,87,6,95,18,254,60,235,143,14,210,153,57,84,44,235,9,170,28,99,223,193,126,101,242,77,25,31,158,230,154,174,232,166,98,0,10,231,174,64,51,161,210,81},{133,23,240,171,98,27,36,224,8,227,89,28,42,100,5,141,30,140,107,203,198,87,6,95,18,254,60,235,143,14,210,153,190,84,198,154,237,80,130,67,122,180,34,86,32,22,90,143,82,66,254,140,131,179,103,95,22,19,126,74,87,243,136,65},{133,23,240,171,98,27,36,224,8,227,89,28,42,100,5,141,30,140,107,203,198,87,6,95,18,254,60,235,143,14,210,153,242,182,67,69,249,237,109,64,229,191,211,152,1,20,125,65,164,27,20,44,60,172,66,128,228,163,181,213,210,177,29,94}};
# 2 "src/main.cpp" 2
#if 0 /* expanded by -frewrite-includes */
#include "sha256.h"
#endif /* expanded by -frewrite-includes */
# 2 "src/main.cpp"
# 1 "./include/sha256.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "./include/sha256.h"
#if 0 /* expanded by -frewrite-includes */
#include <stdint.h>
#endif /* expanded by -frewrite-includes */
# 2 "./include/sha256.h"
# 1 "/home/smith/Agon/agondev/release/include/stdint.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#ifndef _STDINT_H
#define _STDINT_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/stdint.h" 3
# 9 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef          __INT8_TYPE__                        int8_t;
#define            INT8_MIN                       (~__INT8_MAX__)
#define            INT8_MAX                         __INT8_MAX__
#define            INT8_WIDTH          __STDINT_WIDTH(INT8)
#define            INT8_C(C)            __STDINT_C(C, INT8)
typedef         __UINT8_TYPE__                       uint8_t;
#define           UINT8_MAX                        __UINT8_MAX__
#define           UINT8_WIDTH         __STDINT_WIDTH(UINT8)
#define           UINT8_C(C)           __STDINT_C(C, UINT8)
typedef     __INT_FAST8_TYPE__                   int_fast8_t;
#define       INT_FAST8_MIN                  (~__INT_FAST8_MAX__)
#define       INT_FAST8_MAX                    __INT_FAST8_MAX__
#define       INT_FAST8_WIDTH     __STDINT_WIDTH(INT_FAST8)
typedef    __UINT_FAST8_TYPE__                  uint_fast8_t;
#define      UINT_FAST8_MAX                   __UINT_FAST8_MAX__
#define      UINT_FAST8_WIDTH    __STDINT_WIDTH(UINT_FAST8)
typedef    __INT_LEAST8_TYPE__                  int_least8_t;
#define      INT_LEAST8_MIN                 (~__INT_LEAST8_MAX__)
#define      INT_LEAST8_MAX                   __INT_LEAST8_MAX__
#define      INT_LEAST8_WIDTH    __STDINT_WIDTH(INT_LEAST8)
typedef   __UINT_LEAST8_TYPE__                 uint_least8_t;
#define     UINT_LEAST8_MAX                  __UINT_LEAST8_MAX__
#define     UINT_LEAST8_WIDTH   __STDINT_WIDTH(UINT_LEAST8)

typedef         __INT16_TYPE__                       int16_t;
#define           INT16_MIN                      (~__INT16_MAX__)
#define           INT16_MAX                        __INT16_MAX__
#define           INT16_WIDTH         __STDINT_WIDTH(INT16)
#define           INT16_C(C)           __STDINT_C(C, INT16)
typedef        __UINT16_TYPE__                      uint16_t;
#define          UINT16_MAX                       __UINT16_MAX__
#define          UINT16_WIDTH        __STDINT_WIDTH(UINT16)
#define          UINT16_C(C)          __STDINT_C(C, UINT16)
typedef    __INT_FAST16_TYPE__                  int_fast16_t;
#define      INT_FAST16_MIN                 (~__INT_FAST16_MAX__)
#define      INT_FAST16_MAX                   __INT_FAST16_MAX__
#define      INT_FAST16_WIDTH    __STDINT_WIDTH(INT_FAST16)
typedef   __UINT_FAST16_TYPE__                 uint_fast16_t;
#define     UINT_FAST16_MAX                  __UINT_FAST16_MAX__
#define     UINT_FAST16_WIDTH   __STDINT_WIDTH(UINT_FAST16)
typedef   __INT_LEAST16_TYPE__                 int_least16_t;
#define     INT_LEAST16_MIN                (~__INT_LEAST16_MAX__)
#define     INT_LEAST16_MAX                  __INT_LEAST16_MAX__
#define     INT_LEAST16_WIDTH   __STDINT_WIDTH(INT_LEAST16)
typedef  __UINT_LEAST16_TYPE__                uint_least16_t;
#define    UINT_LEAST16_MAX                 __UINT_LEAST16_MAX__
#define    UINT_LEAST16_WIDTH  __STDINT_WIDTH(UINT_LEAST16)

#ifdef          __INT24_TYPE__
typedef         __INT24_TYPE__                       int24_t;
#define           INT24_MIN                      (~__INT24_MAX__)
#define           INT24_MAX                        __INT24_MAX__
#define           INT24_WIDTH         __STDINT_WIDTH(INT24)
#define           INT24_C(C)           __STDINT_C(C, INT24)
typedef        __UINT24_TYPE__                      uint24_t;
#define          UINT24_MAX                       __UINT24_MAX__
#define          UINT24_WIDTH        __STDINT_WIDTH(UINT24)
#define          UINT24_C(C)          __STDINT_C(C, UINT24)
#endif        /*__INT24_TYPE_*/
# 69 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef         __INT32_TYPE__                       int32_t;
#define           INT32_MIN                      (~__INT32_MAX__)
#define           INT32_MAX                        __INT32_MAX__
#define           INT32_WIDTH         __STDINT_WIDTH(INT32)
#define           INT32_C(C)           __STDINT_C(C, INT32)
typedef        __UINT32_TYPE__                      uint32_t;
#define          UINT32_MAX                       __UINT32_MAX__
#define          UINT32_WIDTH        __STDINT_WIDTH(UINT32)
#define          UINT32_C(C)          __STDINT_C(C, UINT32)
typedef    __INT_FAST32_TYPE__                  int_fast32_t;
#define      INT_FAST32_MIN                 (~__INT_FAST32_MAX__)
#define      INT_FAST32_MAX                   __INT_FAST32_MAX__
#define      INT_FAST32_WIDTH    __STDINT_WIDTH(INT_FAST32)
typedef   __UINT_FAST32_TYPE__                 uint_fast32_t;
#define     UINT_FAST32_MAX                  __UINT_FAST32_MAX__
#define     UINT_FAST32_WIDTH   __STDINT_WIDTH(UINT_FAST32)
typedef   __INT_LEAST32_TYPE__                 int_least32_t;
#define     INT_LEAST32_MIN                (~__INT_LEAST32_MAX__)
#define     INT_LEAST32_MAX                  __INT_LEAST32_MAX__
#define     INT_LEAST32_WIDTH   __STDINT_WIDTH(INT_LEAST32)
typedef  __UINT_LEAST32_TYPE__                uint_least32_t;
#define    UINT_LEAST32_MAX                 __UINT_LEAST32_MAX__
#define    UINT_LEAST32_WIDTH  __STDINT_WIDTH(UINT_LEAST32)

#ifdef   __SIZEOF_INT48__
#define         __INT48_TYPE__              signed __int48
#define         __INT48_MAX__  ((__UINT48_TYPE__)(__UINT48_MAX__>>1))
typedef         __INT48_TYPE__                       int48_t;
#define           INT48_MIN                      (~__INT48_MAX__)
#define           INT48_MAX                        __INT48_MAX__
#define           INT48_WIDTH         __STDINT_WIDTH(INT48)
#define           INT48_C(C)                     ((__INT48_TYPE__)(INT64_C(C)))
#define        __UINT48_TYPE__            unsigned __int48
#define        __UINT48_MAX__                   ((__UINT48_TYPE__)~0)
typedef        __UINT48_TYPE__                      uint48_t;
#define          UINT48_MAX                       __UINT48_MAX__
#define          UINT48_WIDTH        __STDINT_WIDTH(UINT48)
#define          UINT48_C(C)                    ((__UINT48_TYPE__)(UINT64_C(C)))
#endif /*__SIZEOF_INT48__*/
# 109 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef         __INT64_TYPE__                       int64_t;
#define           INT64_MIN                      (~__INT64_MAX__)
#define           INT64_MAX                        __INT64_MAX__
#define           INT64_WIDTH         __STDINT_WIDTH(INT64)
#define           INT64_C(C)           __STDINT_C(C, INT64)
typedef        __UINT64_TYPE__                      uint64_t;
#define          UINT64_MAX                       __UINT64_MAX__
#define          UINT64_WIDTH        __STDINT_WIDTH(UINT64)
#define          UINT64_C(C)          __STDINT_C(C, UINT64)
typedef    __INT_FAST64_TYPE__                  int_fast64_t;
#define      INT_FAST64_MIN                 (~__INT_FAST64_MAX__)
#define      INT_FAST64_MAX                   __INT_FAST64_MAX__
#define      INT_FAST64_WIDTH    __STDINT_WIDTH(INT_FAST64)
typedef   __UINT_FAST64_TYPE__                 uint_fast64_t;
#define     UINT_FAST64_MAX                  __UINT_FAST64_MAX__
#define     UINT_FAST64_WIDTH   __STDINT_WIDTH(UINT_FAST64)
typedef   __INT_LEAST64_TYPE__                 int_least64_t;
#define     INT_LEAST64_MIN                (~__INT_LEAST64_MAX__)
#define     INT_LEAST64_MAX                  __INT_LEAST64_MAX__
#define     INT_LEAST64_WIDTH   __STDINT_WIDTH(INT_LEAST64)
typedef  __UINT_LEAST64_TYPE__                uint_least64_t;
#define    UINT_LEAST64_MAX                 __UINT_LEAST64_MAX__
#define    UINT_LEAST64_WIDTH  __STDINT_WIDTH(UINT_LEAST64)

#ifdef  __SIZEOF_INT128__
#define        __INT128_TYPE__             signed __int128
#define        __INT128_MAX__ ((__INT128_TYPE__)(__UINT128_MAX__>>1))
typedef        __INT128_TYPE__                      int128_t;
#define          INT128_MIN                     (~__INT128_MAX__)
#define          INT128_MAX                       __INT128_MAX__
#define          INT128_WIDTH        __STDINT_WIDTH(INT128)
#define       __UINT128_TYPE__           unsigned __int128
#define       __UINT128_MAX__                  ((__UINT128_TYPE__)~0)
typedef       __UINT128_TYPE__                     uint128_t;
#define         UINT128_MAX                      __UINT128_MAX__
#define         UINT128_WIDTH       __STDINT_WIDTH(UINT128)
#endif/*__SIZEOF_INT128__*/
# 147 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef        __INTMAX_TYPE__                      intmax_t;
#define          INTMAX_MIN                     (~__INTMAX_MAX__)
#define          INTMAX_MAX                       __INTMAX_MAX__
#define          INTMAX_WIDTH                     __INTMAX_WIDTH__
#define          INTMAX_C(C)          __STDINT_C(C, INTMAX)
typedef       __UINTMAX_TYPE__                     uintmax_t;
#define         UINTMAX_MAX                      __UINTMAX_MAX__
#define         UINTMAX_WIDTH                    __UINTMAX_WIDTH__
#define         UINTMAX_C(C)         __STDINT_C(C, UINTMAX)

typedef        __INTPTR_TYPE__                      intptr_t;
#define          INTPTR_MIN                     (~__INTPTR_MAX__)
#define          INTPTR_MAX                       __INTPTR_MAX__
#define          INTPTR_WIDTH                     __INTPTR_WIDTH__
typedef       __UINTPTR_TYPE__                     uintptr_t;
#define         UINTPTR_MAX                      __UINTPTR_MAX__
#define         UINTPTR_WIDTH                    __UINTPTR_WIDTH__

#define         PTRDIFF_MIN                    (~__PTRDIFF_MAX__)
#define         PTRDIFF_MAX                      __PTRDIFF_MAX__
#define         PTRDIFF_WIDTH                    __PTRDIFF_WIDTH__

#define            SIZE_MAX                         __SIZE_MAX__
#define            SIZE_WIDTH                       __SIZE_WIDTH__

#define            WINT_MIN                       (~__WINT_MAX__)
#define            WINT_MAX                         __WINT_MAX__
#define            WINT_WIDTH                       __WINT_WIDTH__

#ifndef _WCHAR_LIMITS_DEFINED
#define _WCHAR_LIMITS_DEFINED
#define           WCHAR_MIN                      (~__WCHAR_MAX__)
#define           WCHAR_MAX                        __WCHAR_MAX__
#define           WCHAR_WIDTH                      __WCHAR_WIDTH__
#endif
# 183 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#endif/*_STDINT_H*/
# 185 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#ifdef __cplusplus
}
#endif
# 189 "/home/smith/Agon/agondev/release/include/stdint.h" 3
# 3 "./include/sha256.h" 2
#if 0 /* expanded by -frewrite-includes */
#include <stddef.h>
#endif /* expanded by -frewrite-includes */
# 3 "./include/sha256.h"
# 1 "/home/smith/Agon/agondev/release/include/stddef.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#ifndef _STDDEF_H
#define _STDDEF_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/stddef.h" 3
# 9 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#define offsetof(type, member) __builtin_offsetof(type, member)

typedef __PTRDIFF_TYPE__ ptrdiff_t;

#ifndef _WCHAR_T_DEFINED
#define _WCHAR_T_DEFINED
#ifndef __cplusplus
typedef __WCHAR_TYPE__ wchar_t;
#endif /* __cplusplus */
# 19 "/home/smith/Agon/agondev/release/include/stddef.h" 3
#endif /* _WCHAR_T_DEFINED */
# 20 "/home/smith/Agon/agondev/release/include/stddef.h" 3

typedef struct {
    long long    __max_align_ll __attribute__((__aligned__(__alignof__(  long long))));
    long double  __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
#ifdef __FLOAT128__
    __float128 __max_align_f128 __attribute__((__aligned__(__alignof__( __float128))));
#endif
# 27 "/home/smith/Agon/agondev/release/include/stddef.h" 3
} max_align_t;

#endif /* _STDDEF_H */
# 30 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#ifdef __cplusplus
}
#endif
# 34 "/home/smith/Agon/agondev/release/include/stddef.h" 3
# 4 "./include/sha256.h" 2
#if 0 /* expanded by -frewrite-includes */
#include <string.h>
#endif /* expanded by -frewrite-includes */
# 4 "./include/sha256.h"
# 1 "/home/smith/Agon/agondev/release/include/string.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/string.h" 3

#ifndef _STRING_H
#define _STRING_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/string.h" 3
# 1 "/home/smith/Agon/agondev/release/include/cdefs.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef _CDEFS_H
#define _CDEFS_H

#define __JOIN2(x, y)     x ## y
#define __JOIN3(x, y, z)  x ## y ## z
#define __CONCAT(x, y)    __JOIN2(x, y)
#define __TOSTRING(x)     #x

#define __STDINT_C(C, T)  __CONCAT(C, __##T##_C_SUFFIX__)
#define __STDINT_WIDTH(T) (sizeof(__##T##_TYPE__)*__CHAR_BIT__)

#ifndef __cplusplus
# define __BEGIN_DECLS
# define __END_DECLS
# define __NOEXCEPT     __attribute__((__nothrow__, __leaf__))
# define __IGNORE(expr) ((void)(expr))
#else /* __cplusplus */
# 22 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
# define __BEGIN_DECLS  extern "C" {
# define __END_DECLS    }
# define __NOEXCEPT     noexcept
# define __IGNORE(expr) (static_cast<void>(expr))
#endif /* __cplusplus */
# 27 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef NULL
# ifndef __cplusplus
#  define NULL ((void *)0)
# else /* __cplusplus */
# 32 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
#  define NULL 0
# endif /* __cplusplus */
# 34 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
#endif /* NULL */
# 35 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef SIZE_T_DEFINED
#define SIZE_T_DEFINED
typedef __SIZE_TYPE__ size_t;
#endif /* SIZE_T_DEFINED */
# 40 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#endif /* _CDEFS_H */
# 42 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifdef __cplusplus
}
#endif
# 46 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
# 9 "/home/smith/Agon/agondev/release/include/string.h" 2 3

__BEGIN_DECLS

extern void *memcpy(void *__restrict dest, const void *__restrict src,
                    size_t n) __attribute__((nonnull(1, 2)));

void *memmove(void *dest, const void *src, size_t n)
              __attribute__((nonnull(1, 2)));

void *memset(void *s, int c, size_t n) __attribute__((nonnull(1)));

int memcmp(const void *s1, const void *s2, size_t n)
          __attribute__((nonnull(1, 2)));

void *memchr(const void *s, int c, size_t n) __attribute__((nonnull(1)));

char *strcpy(char *__restrict dest, const char *__restrict src)
             __attribute__((nonnull(1, 2)));

char *strncpy(char *__restrict dest, const char *__restrict src, size_t n)
              __attribute__((nonnull(1, 2)));

char *stpcpy(char *__restrict dest, const char *__restrict src)
    __NOEXCEPT __attribute__((nonnull(1, 2)));

char *stpncpy(char *__restrict dest, const char *__restrict src, size_t n)
    __NOEXCEPT __attribute__((nonnull(1, 2)));

char *strcat(char *__restrict dest, const char *__restrict src)
             __attribute__((nonnull(1, 2)));

char *strncat(char *__restrict dest, const char *__restrict src, size_t n)
              __attribute__((nonnull(1, 2)));

char *strchr(const char *s, int c) __attribute__((nonnull(1)));

char *strrchr(const char *s, int c) __attribute__((nonnull(1)));

char *strchrnul(const char *s, int c)
    __NOEXCEPT __attribute__((nonnull(1))) __attribute__((__pure__));

char *strpbrk(const char *s, const char *accept) __attribute__((nonnull(1, 2)));

char *strstr(const char *haystack, const char *needle)
             __attribute__((nonnull(1, 2)));

char *strtok(char *__restrict s, const char *__restrict delim)
             __attribute__((nonnull(2)));

char *strdup(const char *s)
             __attribute__ ((__malloc__)) __attribute__((nonnull(1)));

char *strndup(const char *s, size_t n)
              __attribute__ ((__malloc__)) __attribute__((nonnull(1)));

size_t strcspn(const char *s, const char *reject)
               __attribute__((nonnull(1, 2)));

size_t strspn(const char *s, const char *accept)
              __attribute__((nonnull(1, 2)));

size_t strlen(const char *s)
              __attribute__((nonnull(1)));

size_t strnlen(const char *s, size_t maxlen)
               __attribute__((nonnull(1)));

int strcmp(const char *s1, const char *s2)
           __attribute__((nonnull(1, 2)));

int strncmp(const char *s1, const char *s2, size_t n)
            __attribute__((nonnull(1, 2)));

int strcasecmp(const char *s1, const char *s2)
               __attribute__((nonnull(1, 2)));

int strncasecmp(const char *s1, const char *s2, size_t n)
                __attribute__((nonnull(1, 2)));


__END_DECLS

#endif /* _STRING_H */
# 92 "/home/smith/Agon/agondev/release/include/string.h" 3

#ifdef __cplusplus
}
#endif
# 96 "/home/smith/Agon/agondev/release/include/string.h" 3
# 5 "./include/sha256.h" 2
struct Sha256 {
 uint32_t h[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};uint8_t buf[64];size_t used=0;uint64_t bytes=0;
 static uint32_t rotr(uint32_t x,unsigned n){return (x>>n)|(x<<(32-n));}
 void block(){
 static const uint32_t k[64]={0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
 uint32_t w[64];for(unsigned i=0;i<16;++i)w[i]=uint32_t(buf[4*i])<<24|uint32_t(buf[4*i+1])<<16|uint32_t(buf[4*i+2])<<8|buf[4*i+3];
 for(unsigned i=16;i<64;++i){uint32_t a=w[i-15],b=w[i-2];w[i]=w[i-16]+(rotr(a,7)^rotr(a,18)^(a>>3))+w[i-7]+(rotr(b,17)^rotr(b,19)^(b>>10));}
 uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],q=h[7];
 for(unsigned i=0;i<64;++i){uint32_t t=q+(rotr(e,6)^rotr(e,11)^rotr(e,25))+((e&f)^(~e&g))+k[i]+w[i],u=(rotr(a,2)^rotr(a,13)^rotr(a,22))+((a&b)^(a&c)^(b&c));q=g;g=f;f=e;e=d+t;d=c;c=b;b=a;a=t+u;}
 uint32_t v[8]={a,b,c,d,e,f,g,q};for(unsigned i=0;i<8;++i)h[i]+=v[i];
 }
 void add(const void* data,size_t n){const uint8_t* p=static_cast<const uint8_t*>(data);bytes+=n;while(n--){buf[used++]=*p++;if(used==64){block();used=0;}}}
 void finish(uint8_t out[32]){uint64_t bits=bytes*8;uint8_t c=128;add(&c,1);c=0;while(used!=56)add(&c,1);for(int i=7;i>=0;--i){c=bits>>(8*i);add(&c,1);}for(unsigned i=0;i<32;++i)out[i]=h[i/4]>>(24-8*(i%4));}
};
inline void hex(const uint8_t* b,size_t n,char* out){const char* digits="0123456789abcdef";for(size_t i=0;i<n;++i){out[2*i]=digits[b[i]>>4];out[2*i+1]=digits[b[i]&15];}out[2*n]=0;}
# 3 "src/main.cpp" 2
#if 0 /* expanded by -frewrite-includes */
#include "script.h"
#endif /* expanded by -frewrite-includes */
# 3 "src/main.cpp"
# 1 "./include/script.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "./include/script.h"
#if 0 /* expanded by -frewrite-includes */
#include <string.h>
#endif /* expanded by -frewrite-includes */
# 2 "./include/script.h"
# 1 "/home/smith/Agon/agondev/release/include/string.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/string.h" 3

#ifndef _STRING_H
#define _STRING_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/string.h" 3
# 9 "/home/smith/Agon/agondev/release/include/string.h" 3

__BEGIN_DECLS

extern void *memcpy(void *__restrict dest, const void *__restrict src,
                    size_t n) __attribute__((nonnull(1, 2)));

void *memmove(void *dest, const void *src, size_t n)
              __attribute__((nonnull(1, 2)));

void *memset(void *s, int c, size_t n) __attribute__((nonnull(1)));

int memcmp(const void *s1, const void *s2, size_t n)
          __attribute__((nonnull(1, 2)));

void *memchr(const void *s, int c, size_t n) __attribute__((nonnull(1)));

char *strcpy(char *__restrict dest, const char *__restrict src)
             __attribute__((nonnull(1, 2)));

char *strncpy(char *__restrict dest, const char *__restrict src, size_t n)
              __attribute__((nonnull(1, 2)));

char *stpcpy(char *__restrict dest, const char *__restrict src)
    __NOEXCEPT __attribute__((nonnull(1, 2)));

char *stpncpy(char *__restrict dest, const char *__restrict src, size_t n)
    __NOEXCEPT __attribute__((nonnull(1, 2)));

char *strcat(char *__restrict dest, const char *__restrict src)
             __attribute__((nonnull(1, 2)));

char *strncat(char *__restrict dest, const char *__restrict src, size_t n)
              __attribute__((nonnull(1, 2)));

char *strchr(const char *s, int c) __attribute__((nonnull(1)));

char *strrchr(const char *s, int c) __attribute__((nonnull(1)));

char *strchrnul(const char *s, int c)
    __NOEXCEPT __attribute__((nonnull(1))) __attribute__((__pure__));

char *strpbrk(const char *s, const char *accept) __attribute__((nonnull(1, 2)));

char *strstr(const char *haystack, const char *needle)
             __attribute__((nonnull(1, 2)));

char *strtok(char *__restrict s, const char *__restrict delim)
             __attribute__((nonnull(2)));

char *strdup(const char *s)
             __attribute__ ((__malloc__)) __attribute__((nonnull(1)));

char *strndup(const char *s, size_t n)
              __attribute__ ((__malloc__)) __attribute__((nonnull(1)));

size_t strcspn(const char *s, const char *reject)
               __attribute__((nonnull(1, 2)));

size_t strspn(const char *s, const char *accept)
              __attribute__((nonnull(1, 2)));

size_t strlen(const char *s)
              __attribute__((nonnull(1)));

size_t strnlen(const char *s, size_t maxlen)
               __attribute__((nonnull(1)));

int strcmp(const char *s1, const char *s2)
           __attribute__((nonnull(1, 2)));

int strncmp(const char *s1, const char *s2, size_t n)
            __attribute__((nonnull(1, 2)));

int strcasecmp(const char *s1, const char *s2)
               __attribute__((nonnull(1, 2)));

int strncasecmp(const char *s1, const char *s2, size_t n)
                __attribute__((nonnull(1, 2)));


__END_DECLS

#endif /* _STRING_H */
# 92 "/home/smith/Agon/agondev/release/include/string.h" 3

#ifdef __cplusplus
}
#endif
# 96 "/home/smith/Agon/agondev/release/include/string.h" 3
# 3 "./include/script.h" 2
#if 0 /* expanded by -frewrite-includes */
#include <stddef.h>
#endif /* expanded by -frewrite-includes */
# 3 "./include/script.h"
# 1 "/home/smith/Agon/agondev/release/include/stddef.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#ifndef _STDDEF_H
#define _STDDEF_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/stddef.h" 3
# 9 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#define offsetof(type, member) __builtin_offsetof(type, member)

typedef __PTRDIFF_TYPE__ ptrdiff_t;

#ifndef _WCHAR_T_DEFINED
#define _WCHAR_T_DEFINED
#ifndef __cplusplus
typedef __WCHAR_TYPE__ wchar_t;
#endif /* __cplusplus */
# 19 "/home/smith/Agon/agondev/release/include/stddef.h" 3
#endif /* _WCHAR_T_DEFINED */
# 20 "/home/smith/Agon/agondev/release/include/stddef.h" 3

typedef struct {
    long long    __max_align_ll __attribute__((__aligned__(__alignof__(  long long))));
    long double  __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
#ifdef __FLOAT128__
    __float128 __max_align_f128 __attribute__((__aligned__(__alignof__( __float128))));
#endif
# 27 "/home/smith/Agon/agondev/release/include/stddef.h" 3
} max_align_t;

#endif /* _STDDEF_H */
# 30 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#ifdef __cplusplus
}
#endif
# 34 "/home/smith/Agon/agondev/release/include/stddef.h" 3
# 4 "./include/script.h" 2
// Generated subset only: no shell emulation, bounded input, canonical function order.
struct Selection {unsigned mask=0;unsigned order[3]={};unsigned count=0;};
inline bool parse_script(const char* text,size_t size,const char* const* functions,Selection& out) {
 if(!size||size>8192)return false;bool load=false,begin=false,end=false;unsigned previous=0;char line[256];size_t pos=0;
 while(pos<size){size_t n=0;while(pos<size&&text[pos]!='\n'){if(n==255||!text[pos])return false;line[n++]=text[pos++];}if(pos<size)++pos;
  while(n&&(line[n-1]=='\r'||line[n-1]==' '||line[n-1]=='\t'))--n;line[n]=0;char* s=line;while(*s==' '||*s=='\t')++s;
  if(!*s||*s=='#')continue;if(end)return false;
  if(strcmp(s,"LOAD /mos-tests/runner.bin")==0){if(load)return false;load=true;continue;}
  if(!load)return false;load=false;
  if(strcmp(s,"RUN . begin")==0){if(begin)return false;begin=true;continue;}
  if(!begin)return false;
  if(strcmp(s,"RUN . finalize")==0){if(!out.count)return false;end=true;continue;}
  const char* prefix="RUN . function ";if(strncmp(s,prefix,strlen(prefix)))return false;
  unsigned found=3;for(unsigned i=0;i<3;++i)if(strcmp(s+strlen(prefix),functions[i])==0)found=i;
  if(found==3||(out.mask&(1<<found))||(out.count&&found<previous))return false;
  out.mask|=1<<found;out.order[out.count++]=found;previous=found;
 }
 return begin&&end&&!load;
}
# 4 "src/main.cpp" 2
#if 0 /* expanded by -frewrite-includes */
#include "continuation.h"
#endif /* expanded by -frewrite-includes */
# 4 "src/main.cpp"
# 1 "./include/continuation.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "./include/continuation.h"
#if 0 /* expanded by -frewrite-includes */
#include "recording.h"
#endif /* expanded by -frewrite-includes */
# 2 "./include/continuation.h"
# 1 "../runner/include/recording.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "../runner/include/recording.h"
#if 0 /* expanded by -frewrite-includes */
#include <stdint.h>
#endif /* expanded by -frewrite-includes */
# 2 "../runner/include/recording.h"
# 1 "/home/smith/Agon/agondev/release/include/stdint.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#ifndef _STDINT_H
#define _STDINT_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/stdint.h" 3
# 9 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef          __INT8_TYPE__                        int8_t;
#define            INT8_MIN                       (~__INT8_MAX__)
#define            INT8_MAX                         __INT8_MAX__
#define            INT8_WIDTH          __STDINT_WIDTH(INT8)
#define            INT8_C(C)            __STDINT_C(C, INT8)
typedef         __UINT8_TYPE__                       uint8_t;
#define           UINT8_MAX                        __UINT8_MAX__
#define           UINT8_WIDTH         __STDINT_WIDTH(UINT8)
#define           UINT8_C(C)           __STDINT_C(C, UINT8)
typedef     __INT_FAST8_TYPE__                   int_fast8_t;
#define       INT_FAST8_MIN                  (~__INT_FAST8_MAX__)
#define       INT_FAST8_MAX                    __INT_FAST8_MAX__
#define       INT_FAST8_WIDTH     __STDINT_WIDTH(INT_FAST8)
typedef    __UINT_FAST8_TYPE__                  uint_fast8_t;
#define      UINT_FAST8_MAX                   __UINT_FAST8_MAX__
#define      UINT_FAST8_WIDTH    __STDINT_WIDTH(UINT_FAST8)
typedef    __INT_LEAST8_TYPE__                  int_least8_t;
#define      INT_LEAST8_MIN                 (~__INT_LEAST8_MAX__)
#define      INT_LEAST8_MAX                   __INT_LEAST8_MAX__
#define      INT_LEAST8_WIDTH    __STDINT_WIDTH(INT_LEAST8)
typedef   __UINT_LEAST8_TYPE__                 uint_least8_t;
#define     UINT_LEAST8_MAX                  __UINT_LEAST8_MAX__
#define     UINT_LEAST8_WIDTH   __STDINT_WIDTH(UINT_LEAST8)

typedef         __INT16_TYPE__                       int16_t;
#define           INT16_MIN                      (~__INT16_MAX__)
#define           INT16_MAX                        __INT16_MAX__
#define           INT16_WIDTH         __STDINT_WIDTH(INT16)
#define           INT16_C(C)           __STDINT_C(C, INT16)
typedef        __UINT16_TYPE__                      uint16_t;
#define          UINT16_MAX                       __UINT16_MAX__
#define          UINT16_WIDTH        __STDINT_WIDTH(UINT16)
#define          UINT16_C(C)          __STDINT_C(C, UINT16)
typedef    __INT_FAST16_TYPE__                  int_fast16_t;
#define      INT_FAST16_MIN                 (~__INT_FAST16_MAX__)
#define      INT_FAST16_MAX                   __INT_FAST16_MAX__
#define      INT_FAST16_WIDTH    __STDINT_WIDTH(INT_FAST16)
typedef   __UINT_FAST16_TYPE__                 uint_fast16_t;
#define     UINT_FAST16_MAX                  __UINT_FAST16_MAX__
#define     UINT_FAST16_WIDTH   __STDINT_WIDTH(UINT_FAST16)
typedef   __INT_LEAST16_TYPE__                 int_least16_t;
#define     INT_LEAST16_MIN                (~__INT_LEAST16_MAX__)
#define     INT_LEAST16_MAX                  __INT_LEAST16_MAX__
#define     INT_LEAST16_WIDTH   __STDINT_WIDTH(INT_LEAST16)
typedef  __UINT_LEAST16_TYPE__                uint_least16_t;
#define    UINT_LEAST16_MAX                 __UINT_LEAST16_MAX__
#define    UINT_LEAST16_WIDTH  __STDINT_WIDTH(UINT_LEAST16)

#ifdef          __INT24_TYPE__
typedef         __INT24_TYPE__                       int24_t;
#define           INT24_MIN                      (~__INT24_MAX__)
#define           INT24_MAX                        __INT24_MAX__
#define           INT24_WIDTH         __STDINT_WIDTH(INT24)
#define           INT24_C(C)           __STDINT_C(C, INT24)
typedef        __UINT24_TYPE__                      uint24_t;
#define          UINT24_MAX                       __UINT24_MAX__
#define          UINT24_WIDTH        __STDINT_WIDTH(UINT24)
#define          UINT24_C(C)          __STDINT_C(C, UINT24)
#endif        /*__INT24_TYPE_*/
# 69 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef         __INT32_TYPE__                       int32_t;
#define           INT32_MIN                      (~__INT32_MAX__)
#define           INT32_MAX                        __INT32_MAX__
#define           INT32_WIDTH         __STDINT_WIDTH(INT32)
#define           INT32_C(C)           __STDINT_C(C, INT32)
typedef        __UINT32_TYPE__                      uint32_t;
#define          UINT32_MAX                       __UINT32_MAX__
#define          UINT32_WIDTH        __STDINT_WIDTH(UINT32)
#define          UINT32_C(C)          __STDINT_C(C, UINT32)
typedef    __INT_FAST32_TYPE__                  int_fast32_t;
#define      INT_FAST32_MIN                 (~__INT_FAST32_MAX__)
#define      INT_FAST32_MAX                   __INT_FAST32_MAX__
#define      INT_FAST32_WIDTH    __STDINT_WIDTH(INT_FAST32)
typedef   __UINT_FAST32_TYPE__                 uint_fast32_t;
#define     UINT_FAST32_MAX                  __UINT_FAST32_MAX__
#define     UINT_FAST32_WIDTH   __STDINT_WIDTH(UINT_FAST32)
typedef   __INT_LEAST32_TYPE__                 int_least32_t;
#define     INT_LEAST32_MIN                (~__INT_LEAST32_MAX__)
#define     INT_LEAST32_MAX                  __INT_LEAST32_MAX__
#define     INT_LEAST32_WIDTH   __STDINT_WIDTH(INT_LEAST32)
typedef  __UINT_LEAST32_TYPE__                uint_least32_t;
#define    UINT_LEAST32_MAX                 __UINT_LEAST32_MAX__
#define    UINT_LEAST32_WIDTH  __STDINT_WIDTH(UINT_LEAST32)

#ifdef   __SIZEOF_INT48__
#define         __INT48_TYPE__              signed __int48
#define         __INT48_MAX__  ((__UINT48_TYPE__)(__UINT48_MAX__>>1))
typedef         __INT48_TYPE__                       int48_t;
#define           INT48_MIN                      (~__INT48_MAX__)
#define           INT48_MAX                        __INT48_MAX__
#define           INT48_WIDTH         __STDINT_WIDTH(INT48)
#define           INT48_C(C)                     ((__INT48_TYPE__)(INT64_C(C)))
#define        __UINT48_TYPE__            unsigned __int48
#define        __UINT48_MAX__                   ((__UINT48_TYPE__)~0)
typedef        __UINT48_TYPE__                      uint48_t;
#define          UINT48_MAX                       __UINT48_MAX__
#define          UINT48_WIDTH        __STDINT_WIDTH(UINT48)
#define          UINT48_C(C)                    ((__UINT48_TYPE__)(UINT64_C(C)))
#endif /*__SIZEOF_INT48__*/
# 109 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef         __INT64_TYPE__                       int64_t;
#define           INT64_MIN                      (~__INT64_MAX__)
#define           INT64_MAX                        __INT64_MAX__
#define           INT64_WIDTH         __STDINT_WIDTH(INT64)
#define           INT64_C(C)           __STDINT_C(C, INT64)
typedef        __UINT64_TYPE__                      uint64_t;
#define          UINT64_MAX                       __UINT64_MAX__
#define          UINT64_WIDTH        __STDINT_WIDTH(UINT64)
#define          UINT64_C(C)          __STDINT_C(C, UINT64)
typedef    __INT_FAST64_TYPE__                  int_fast64_t;
#define      INT_FAST64_MIN                 (~__INT_FAST64_MAX__)
#define      INT_FAST64_MAX                   __INT_FAST64_MAX__
#define      INT_FAST64_WIDTH    __STDINT_WIDTH(INT_FAST64)
typedef   __UINT_FAST64_TYPE__                 uint_fast64_t;
#define     UINT_FAST64_MAX                  __UINT_FAST64_MAX__
#define     UINT_FAST64_WIDTH   __STDINT_WIDTH(UINT_FAST64)
typedef   __INT_LEAST64_TYPE__                 int_least64_t;
#define     INT_LEAST64_MIN                (~__INT_LEAST64_MAX__)
#define     INT_LEAST64_MAX                  __INT_LEAST64_MAX__
#define     INT_LEAST64_WIDTH   __STDINT_WIDTH(INT_LEAST64)
typedef  __UINT_LEAST64_TYPE__                uint_least64_t;
#define    UINT_LEAST64_MAX                 __UINT_LEAST64_MAX__
#define    UINT_LEAST64_WIDTH  __STDINT_WIDTH(UINT_LEAST64)

#ifdef  __SIZEOF_INT128__
#define        __INT128_TYPE__             signed __int128
#define        __INT128_MAX__ ((__INT128_TYPE__)(__UINT128_MAX__>>1))
typedef        __INT128_TYPE__                      int128_t;
#define          INT128_MIN                     (~__INT128_MAX__)
#define          INT128_MAX                       __INT128_MAX__
#define          INT128_WIDTH        __STDINT_WIDTH(INT128)
#define       __UINT128_TYPE__           unsigned __int128
#define       __UINT128_MAX__                  ((__UINT128_TYPE__)~0)
typedef       __UINT128_TYPE__                     uint128_t;
#define         UINT128_MAX                      __UINT128_MAX__
#define         UINT128_WIDTH       __STDINT_WIDTH(UINT128)
#endif/*__SIZEOF_INT128__*/
# 147 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef        __INTMAX_TYPE__                      intmax_t;
#define          INTMAX_MIN                     (~__INTMAX_MAX__)
#define          INTMAX_MAX                       __INTMAX_MAX__
#define          INTMAX_WIDTH                     __INTMAX_WIDTH__
#define          INTMAX_C(C)          __STDINT_C(C, INTMAX)
typedef       __UINTMAX_TYPE__                     uintmax_t;
#define         UINTMAX_MAX                      __UINTMAX_MAX__
#define         UINTMAX_WIDTH                    __UINTMAX_WIDTH__
#define         UINTMAX_C(C)         __STDINT_C(C, UINTMAX)

typedef        __INTPTR_TYPE__                      intptr_t;
#define          INTPTR_MIN                     (~__INTPTR_MAX__)
#define          INTPTR_MAX                       __INTPTR_MAX__
#define          INTPTR_WIDTH                     __INTPTR_WIDTH__
typedef       __UINTPTR_TYPE__                     uintptr_t;
#define         UINTPTR_MAX                      __UINTPTR_MAX__
#define         UINTPTR_WIDTH                    __UINTPTR_WIDTH__

#define         PTRDIFF_MIN                    (~__PTRDIFF_MAX__)
#define         PTRDIFF_MAX                      __PTRDIFF_MAX__
#define         PTRDIFF_WIDTH                    __PTRDIFF_WIDTH__

#define            SIZE_MAX                         __SIZE_MAX__
#define            SIZE_WIDTH                       __SIZE_WIDTH__

#define            WINT_MIN                       (~__WINT_MAX__)
#define            WINT_MAX                         __WINT_MAX__
#define            WINT_WIDTH                       __WINT_WIDTH__

#ifndef _WCHAR_LIMITS_DEFINED
#define _WCHAR_LIMITS_DEFINED
#define           WCHAR_MIN                      (~__WCHAR_MAX__)
#define           WCHAR_MAX                        __WCHAR_MAX__
#define           WCHAR_WIDTH                      __WCHAR_WIDTH__
#endif
# 183 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#endif/*_STDINT_H*/
# 185 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#ifdef __cplusplus
}
#endif
# 189 "/home/smith/Agon/agondev/release/include/stdint.h" 3
# 3 "../runner/include/recording.h" 2
#if 0 /* expanded by -frewrite-includes */
#include <stddef.h>
#endif /* expanded by -frewrite-includes */
# 3 "../runner/include/recording.h"
# 1 "/home/smith/Agon/agondev/release/include/stddef.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#ifndef _STDDEF_H
#define _STDDEF_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/stddef.h" 3
# 9 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#define offsetof(type, member) __builtin_offsetof(type, member)

typedef __PTRDIFF_TYPE__ ptrdiff_t;

#ifndef _WCHAR_T_DEFINED
#define _WCHAR_T_DEFINED
#ifndef __cplusplus
typedef __WCHAR_TYPE__ wchar_t;
#endif /* __cplusplus */
# 19 "/home/smith/Agon/agondev/release/include/stddef.h" 3
#endif /* _WCHAR_T_DEFINED */
# 20 "/home/smith/Agon/agondev/release/include/stddef.h" 3

typedef struct {
    long long    __max_align_ll __attribute__((__aligned__(__alignof__(  long long))));
    long double  __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
#ifdef __FLOAT128__
    __float128 __max_align_f128 __attribute__((__aligned__(__alignof__( __float128))));
#endif
# 27 "/home/smith/Agon/agondev/release/include/stddef.h" 3
} max_align_t;

#endif /* _STDDEF_H */
# 30 "/home/smith/Agon/agondev/release/include/stddef.h" 3

#ifdef __cplusplus
}
#endif
# 34 "/home/smith/Agon/agondev/release/include/stddef.h" 3
# 4 "../runner/include/recording.h" 2
#if 0 /* expanded by -frewrite-includes */
#include <string.h>
#endif /* expanded by -frewrite-includes */
# 4 "../runner/include/recording.h"
# 1 "/home/smith/Agon/agondev/release/include/string.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/string.h" 3

#ifndef _STRING_H
#define _STRING_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/string.h" 3
# 9 "/home/smith/Agon/agondev/release/include/string.h" 3

__BEGIN_DECLS

extern void *memcpy(void *__restrict dest, const void *__restrict src,
                    size_t n) __attribute__((nonnull(1, 2)));

void *memmove(void *dest, const void *src, size_t n)
              __attribute__((nonnull(1, 2)));

void *memset(void *s, int c, size_t n) __attribute__((nonnull(1)));

int memcmp(const void *s1, const void *s2, size_t n)
          __attribute__((nonnull(1, 2)));

void *memchr(const void *s, int c, size_t n) __attribute__((nonnull(1)));

char *strcpy(char *__restrict dest, const char *__restrict src)
             __attribute__((nonnull(1, 2)));

char *strncpy(char *__restrict dest, const char *__restrict src, size_t n)
              __attribute__((nonnull(1, 2)));

char *stpcpy(char *__restrict dest, const char *__restrict src)
    __NOEXCEPT __attribute__((nonnull(1, 2)));

char *stpncpy(char *__restrict dest, const char *__restrict src, size_t n)
    __NOEXCEPT __attribute__((nonnull(1, 2)));

char *strcat(char *__restrict dest, const char *__restrict src)
             __attribute__((nonnull(1, 2)));

char *strncat(char *__restrict dest, const char *__restrict src, size_t n)
              __attribute__((nonnull(1, 2)));

char *strchr(const char *s, int c) __attribute__((nonnull(1)));

char *strrchr(const char *s, int c) __attribute__((nonnull(1)));

char *strchrnul(const char *s, int c)
    __NOEXCEPT __attribute__((nonnull(1))) __attribute__((__pure__));

char *strpbrk(const char *s, const char *accept) __attribute__((nonnull(1, 2)));

char *strstr(const char *haystack, const char *needle)
             __attribute__((nonnull(1, 2)));

char *strtok(char *__restrict s, const char *__restrict delim)
             __attribute__((nonnull(2)));

char *strdup(const char *s)
             __attribute__ ((__malloc__)) __attribute__((nonnull(1)));

char *strndup(const char *s, size_t n)
              __attribute__ ((__malloc__)) __attribute__((nonnull(1)));

size_t strcspn(const char *s, const char *reject)
               __attribute__((nonnull(1, 2)));

size_t strspn(const char *s, const char *accept)
              __attribute__((nonnull(1, 2)));

size_t strlen(const char *s)
              __attribute__((nonnull(1)));

size_t strnlen(const char *s, size_t maxlen)
               __attribute__((nonnull(1)));

int strcmp(const char *s1, const char *s2)
           __attribute__((nonnull(1, 2)));

int strncmp(const char *s1, const char *s2, size_t n)
            __attribute__((nonnull(1, 2)));

int strcasecmp(const char *s1, const char *s2)
               __attribute__((nonnull(1, 2)));

int strncasecmp(const char *s1, const char *s2, size_t n)
                __attribute__((nonnull(1, 2)));


__END_DECLS

#endif /* _STRING_H */
# 92 "/home/smith/Agon/agondev/release/include/string.h" 3

#ifdef __cplusplus
}
#endif
# 96 "/home/smith/Agon/agondev/release/include/string.h" 3
# 5 "../runner/include/recording.h" 2
namespace suite {
namespace wire {
inline void put16(uint8_t* p,uint16_t n) {p[0]=n;p[1]=n>>8;}
inline void put32(uint8_t* p,uint32_t n) {for(unsigned i=0;i<4;++i) p[i]=n>>(8*i);}
inline uint32_t get32(const uint8_t* p) {uint32_t n=0;for(unsigned i=0;i<4;++i)n|=uint32_t(p[i])<<(8*i);return n;}
inline uint32_t crc(const uint8_t* p,size_t n) {
 uint32_t c=UINT32_C(0xffffffff);while(n--) {c^=*p++;for(unsigned i=0;i<8;++i)c=(c>>1)^((c&1)?UINT32_C(0xedb88320):0);}return c^UINT32_C(0xffffffff);
}
// Typed constructors leave reserved bytes zero; strings are validated UTF-8.
inline bool utf8(const char* s,size_t n) {
 for(size_t i=0;i<n;) {uint8_t a=uint8_t(s[i++]);if(a<128)continue;
 unsigned k=a>=0xc2&&a<=0xdf?1:a>=0xe0&&a<=0xef?2:a>=0xf0&&a<=0xf4?3:0;
 if(!k||n-i<k)return false;uint8_t b=uint8_t(s[i]);
 if((a==0xe0&&b<0xa0)||(a==0xed&&b>=0xa0)||(a==0xf0&&b<0x90)||(a==0xf4&&b>=0x90))return false;
 while(k--)if((uint8_t(s[i++])&0xc0)!=0x80)return false;
 }return true;
}
struct Payload {
 uint8_t bytes[1024];uint16_t size;
 Payload():bytes{},size(0){}
 void init(uint16_t n) {memset(bytes,0,sizeof bytes);size=n;put16(bytes,1);}
 bool run_start(uint8_t backend,uint32_t count,const uint8_t* hashes) {if(backend<1||backend>2||!count)return false;init(136);bytes[2]=backend;put32(bytes+4,count);memcpy(bytes+8,hashes,128);return true;}
 bool case_start(uint16_t samples,const uint8_t* hashes) {if(!samples)return false;init(68);put16(bytes+2,samples);memcpy(bytes+4,hashes,64);return true;}
 bool observation(uint8_t kind,uint16_t sample,uint16_t chunk,uint16_t chunks,uint32_t id,const uint8_t* data,uint16_t n) {
  if(kind<1||kind>3||!chunks||chunk>=chunks||!id||n>1008||(kind==1&&(n!=96||chunk||chunks!=1)))return false;
  init(16+n);bytes[2]=kind;put16(bytes+4,sample);put16(bytes+6,chunk);put16(bytes+8,chunks);put16(bytes+10,n);put32(bytes+12,id);if(n)memcpy(bytes+16,data,n);return true;
 }
 bool case_end(uint8_t outcome,uint32_t assertions,uint32_t failed,uint32_t observations,const char* reason) {
  size_t n=strlen(reason);if(n>1004||!utf8(reason,n)||outcome<1||outcome>8||failed>assertions)return false;
  if(outcome==1&&(!assertions||failed||n))return false;
  if(outcome!=1&&!n)return false;if(outcome==2&&!failed)return false;
  if(outcome>=3&&outcome<=6&&(assertions||failed||(outcome>=4&&observations)))return false;
  init(20+n);bytes[2]=outcome;put32(bytes+4,assertions);put32(bytes+8,failed);put32(bytes+12,observations);put16(bytes+16,n);memcpy(bytes+20,reason,n);return true;
 }
 void error(uint8_t op,uint32_t status,uint32_t attempted,uint32_t confirmed) {init(16);bytes[2]=op;put32(bytes+4,status);put32(bytes+8,attempted);put32(bytes+12,confirmed);}
 void run_end(const uint32_t* counts,const uint8_t* plan) {init(68);for(unsigned i=0;i<8;++i)put32(bytes+4+4*i,counts[i]);memcpy(bytes+36,plan,32);}
};
inline uint16_t encode(uint8_t* out,uint8_t type,const uint8_t* run,uint32_t seq,uint32_t key,const Payload& p) {
 if(type<1||type>6||p.size<2||p.size>1024||!seq)return 0;
 memset(out,0,40);memcpy(out,"MSTR",4);out[4]=1;out[5]=type;put16(out+6,40);memcpy(out+8,run,16);put32(out+24,seq);put32(out+28,key);put32(out+32,p.size);memcpy(out+40,p.bytes,p.size);put32(out+40+p.size,crc(out,40+p.size));out[44+p.size]=0xa5;return 45+p.size;
}
}
struct Storage {
 void* context;
 size_t (*write)(void*,const uint8_t*,size_t,uint32_t* status);
 uint32_t (*sync)(void*);
 uint32_t (*close)(void*);
};
// Observer is a fault-injection seam after each individual SRAM byte store.
// Production uses nullptr. Interruption must never be caught and resumed in place.
struct Recorder {
 volatile uint8_t* ram;Storage io;uint8_t run_id[16],catalogue[32],plan[32];
 uint32_t next=1,confirmed=0,generation=0,current=0;uint16_t used=0;uint8_t state=1,slot=1;bool stopped=false;
 void (*stored)(void*,size_t)=nullptr;void* observer=nullptr;
 Recorder(volatile uint8_t* r,Storage s,const uint8_t* id,const uint8_t* cat,const uint8_t* pl):ram(r),io(s) {memcpy(run_id,id,16);memcpy(catalogue,cat,32);memcpy(plan,pl,32);}
 void store(size_t at,uint8_t value) {ram[at]=value;if(stored)stored(observer,at);}
 void publish_bytes(size_t at,const uint8_t* src,size_t n,size_t commit) {
  store(at+commit,0);for(size_t i=0;i<n;++i)if(i!=commit)store(at+i,src[i]);store(at+commit,0xa5);
 }
 bool publish() {
  if(generation==UINT32_MAX) {stopped=true;return false;}
  uint8_t b[128]={};memcpy(b,"MSTC",4);wire::put16(b+4,1);wire::put16(b+6,128);memcpy(b+8,run_id,16);
  wire::put32(b+24,++generation);wire::put32(b+28,next);wire::put32(b+32,confirmed);wire::put16(b+36,used);b[38]=state;
  wire::put32(b+40,current);memcpy(b+44,catalogue,32);memcpy(b+76,plan,32);wire::put32(b+120,wire::crc(b,120));b[124]=0xa5;
  slot^=1;publish_bytes(slot*128,b,128,124);return true;
 }
 bool begin() {
  uint8_t any=0;for(unsigned i=0;i<16;++i)any|=run_id[i];
  if(!any||!io.write||!io.sync||!io.close){stopped=true;return false;}
  // New run only, after collision-safe allocation; never recover by calling begin.
  store(124,0);store(252,0);for(size_t i=0xd00;i<0xe00;++i)store(i,0);
  return publish();
 }
 bool fail(uint8_t op,uint32_t status,uint32_t attempted) {
  if(stopped||state==6)return false;stopped=true;state=5;
  wire::Payload p;p.error(op,status,attempted,confirmed);uint8_t b[1069];
  // next is always reserved and nonzero: append refuses to consume UINT32_MAX.
  uint16_t n=wire::encode(b,5,run_id,next,current,p);publish_bytes(0xd00,b,n,n-1);publish();return false;
 }
 bool append(uint8_t type,const wire::Payload& p) {
  if(stopped||state==6)return false;
  if(next==UINT32_MAX)return fail(5,2,next);
  // Reserve enough generations for I/O confirmation and fatal publication.
  if(generation>UINT32_MAX-8)return fail(5,3,next);
  uint8_t b[1069];uint16_t n=wire::encode(b,type,run_id,next,current,p);
  if(!n)return fail(5,4,next);
  if(n>2048-used)return fail(4,0,next);
  publish_bytes(0x100+used,b,n,n-1);used+=n;++next;
  if(type==3)state=3;return publish();
 }
 bool checkpoint() {
  if(stopped||state==6)return false;if(!used)return true;
  state=4;if(!publish())return fail(5,3,next);
  // Volatile SRAM copied into normal RAM for the MOS ABI, outside capture window.
  uint8_t bytes[2048];for(uint16_t i=0;i<used;++i)bytes[i]=ram[0x100+i];
  uint32_t status=0;size_t wrote=io.write(io.context,bytes,used,&status);
  if(status||wrote!=used)return fail(1,status?status:UINT32_C(0xffffffff),next-1);
  status=io.sync(io.context);if(status)return fail(2,status,next-1);
  confirmed=next-1;used=0;state=current?2:1;
  // Both surviving slots must release the extent before any staging reuse.
  if(!publish()||!publish())return fail(5,3,next);
  return true;
 }
 bool start_case(uint32_t key,const wire::Payload& p) {
  if(stopped||state==6||current||!key)return false;current=key;state=2;return append(2,p)&&checkpoint();
 }
 bool finish_case(const wire::Payload& p) {
  if(stopped||!current)return false;
  if(!append(4,p)||!checkpoint())return false;current=0;state=1;return publish();
 }
 bool finish_run(const wire::Payload& p) {
  if(stopped||state==6||current)return false;if(!append(6,p)||!checkpoint())return false;
  uint32_t status=io.close(io.context);if(status)return fail(3,status,next-1);
  state=6;return publish();
 }
};
}
# 3 "./include/continuation.h" 2
// Resume only a clean same-boot command boundary; never an uncertain file tail.
inline bool restore_ready(suite::Recorder& r) {
 uint8_t b[2][128];int best=-1;
 for(unsigned s=0;s<2;++s){
  auto p=b[s];for(unsigned i=0;i<128;++i)p[i]=r.ram[s*128+i];
  if(memcmp(p,"MSTC\1\0\200\0",8)||p[124]!=0xa5||suite::wire::get32(p+120)!=suite::wire::crc(p,120))continue;
  if(memcmp(p+8,r.run_id,16)||memcmp(p+44,r.catalogue,32)||memcmp(p+76,r.plan,32))return false;
  if(p[39]||p[125]||p[126]||p[127]||!suite::wire::get32(p+24))return false;
  for(unsigned i=108;i<120;++i)if(p[i])return false;
  if(best>=0&&suite::wire::get32(p+24)==suite::wire::get32(b[best]+24)&&memcmp(p,b[best],128))return false;
  if(best<0||suite::wire::get32(p+24)>suite::wire::get32(b[best]+24))best=s;
 }
 if(best<0)return false;auto p=b[best];
 if(p[38]!=1||p[36]||p[37]||suite::wire::get32(p+40))return false;
 uint32_t next=suite::wire::get32(p+28),confirmed=suite::wire::get32(p+32);
 if(!next||confirmed==UINT32_MAX||next!=confirmed+1)return false;
 r.generation=suite::wire::get32(p+24);r.next=next;r.confirmed=confirmed;r.slot=best;return true;
}
# 5 "src/main.cpp" 2
#if 0 /* expanded by -frewrite-includes */
#include "capture.h"
#endif /* expanded by -frewrite-includes */
# 5 "src/main.cpp"
# 1 "../runner/include/capture.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "../runner/include/capture.h"
// Check before using the fixed SRAM window. This call changes registers.
extern "C" int capture_available();
// Assembly-only observation entry points: do not use C++ calls to observe raw
// caller registers, because its ABI/prologue changes the observation boundary.
// _capture_before writes 32 bytes at B7E900; _capture_after at B7E920.
// Both preserve primary registers/flags and return with balanced caller SP.
// Require ADL=1, MB=0, a valid writable stack (six bytes headroom: call + push),
// verified SRAM mapping, and no nested capture or concurrent user writer.
# 6 "src/main.cpp" 2
#if 0 /* expanded by -frewrite-includes */
#include "recorded_lifecycle.h"
#endif /* expanded by -frewrite-includes */
# 6 "src/main.cpp"
# 1 "../runner/include/recorded_lifecycle.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "../runner/include/recorded_lifecycle.h"
#if 0 /* expanded by -frewrite-includes */
#include "lifecycle.h"
#endif /* expanded by -frewrite-includes */
# 2 "../runner/include/recorded_lifecycle.h"
# 3 "../runner/include/recorded_lifecycle.h"
#if 0 /* expanded by -frewrite-includes */
#include "recording.h"
#endif /* expanded by -frewrite-includes */
# 3 "../runner/include/recorded_lifecycle.h"
# 4 "../runner/include/recorded_lifecycle.h"
namespace suite {
// Metadata/execution remain caller-owned; this bridge supplies durable boundaries.
struct RecordedLifecycle {
 Recorder& recorder;void* context;
 bool (*metadata)(void*,const Case&,wire::Payload&);
 Result (*execute_case)(void*,const Case&);
 bool (*cleanup_case)(void*,const Case&);
 uint32_t observations=0;
 RecordedLifecycle(Recorder& r,void* c,bool (*m)(void*,const Case&,wire::Payload&),Result (*e)(void*,const Case&),bool (*clean)(void*,const Case&)):
  recorder(r),context(c),metadata(m),execute_case(e),cleanup_case(clean){}
 bool observation(const wire::Payload& p) {
  if(p.size<16||p.bytes[6]||p.bytes[7]||p.bytes[8]!=1||p.bytes[9])return false;
  if(observations==UINT32_MAX)return recorder.fail(5,5,recorder.next);
  if(!recorder.current||!recorder.append(3,p)||!recorder.checkpoint())return false;
  // Call for completed logical observations only (v1 first integration: one chunk).
  ++observations;return true;
 }
 static bool start(void* ptr,const Case& c) {
  auto& s=*static_cast<RecordedLifecycle*>(ptr);wire::Payload p;s.observations=0;
  return s.metadata(s.context,c,p)&&s.recorder.start_case(c.key,p);
 }
 static Result execute(void* ptr,const Case& c) {auto& s=*static_cast<RecordedLifecycle*>(ptr);return s.execute_case(s.context,c);}
 static bool finish(void* ptr,const Case&,const Result& r) {
  auto& s=*static_cast<RecordedLifecycle*>(ptr);wire::Payload p;
  return p.case_end(static_cast<uint8_t>(r.outcome),r.assertions,r.failed,s.observations,r.reason?r.reason:"")&&s.recorder.finish_case(p);
 }
 static bool cleanup(void* ptr,const Case& c) {auto& s=*static_cast<RecordedLifecycle*>(ptr);return s.cleanup_case(s.context,c);}
 Hooks hooks() {return {this,start,execute,finish,cleanup};}
};
}
# 7 "src/main.cpp" 2
#if 0 /* expanded by -frewrite-includes */
#include "mos_storage.h"
#endif /* expanded by -frewrite-includes */
# 7 "src/main.cpp"
# 1 "../runner/include/mos_storage.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "../runner/include/mos_storage.h"
#if 0 /* expanded by -frewrite-includes */
#include <agon/mos.h>
#endif /* expanded by -frewrite-includes */
# 2 "../runner/include/mos_storage.h"
# 1 "/home/smith/Agon/agondev/release/include/agon/mos.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3

/*
 * Title:			AGON MOS - MOS C header interface
 * Author:			Jeroen Venema
 * Created:			15/10/2022
 * Last Updated:	12/03/2026
 * 
 * Modinfo:
 * 15/10/2022:		Added putch, getch
 * 22/10/2022:		Added waitvblank, mos_f* functions
 * 10/01/2023:      Added getsysvar_cursorX/Y functions, removed generic getsysvar8/16/24bit functions
 * 25/03/2023:      Added MOS 1.03 functions / sysvars
 * 16/04/2023:      Added MOS 1.03RC4 mos_fread / mos_fwrite / mos_flseek functions
 * 19/04/2023:		Added mos_getfil
 * 02/07/2023:      Added struct / union for RTC_DATA
 * 22/07/2023:      Added structure for SYSVAR
 * 18/11/2023:		Added mos_setkbvector, mos_getkbmap, mos_i2c_open, mos_i2c_close, mos_i2c_write, mos_i2c_read
 * 05/04/2024:		Added more mos sysvars, and expanded SYSVAR struct
 * 18/04/2025:      Added the remaining ffs_* functions as defined in MOS up to version 3.0
 *                  Changed RTC_DATA to SYSVAR_RTCDATA, added vdp_time_t struct
 * 05/11/2025:      Changed location/name to <agon/mos.h>
 * 11/11/2025:      Added mouse getsysvar getters
 * 12/03/2026:      Added FILINFO.attrib attribute bits
 */

#ifndef _MOS_H
#define _MOS_H
#if 0 /* expanded by -frewrite-includes */
#include <stdint.h>
#endif /* expanded by -frewrite-includes */
# 31 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
# 1 "/home/smith/Agon/agondev/release/include/stdint.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#ifndef _STDINT_H
#define _STDINT_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/stdint.h" 3
# 9 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef          __INT8_TYPE__                        int8_t;
#define            INT8_MIN                       (~__INT8_MAX__)
#define            INT8_MAX                         __INT8_MAX__
#define            INT8_WIDTH          __STDINT_WIDTH(INT8)
#define            INT8_C(C)            __STDINT_C(C, INT8)
typedef         __UINT8_TYPE__                       uint8_t;
#define           UINT8_MAX                        __UINT8_MAX__
#define           UINT8_WIDTH         __STDINT_WIDTH(UINT8)
#define           UINT8_C(C)           __STDINT_C(C, UINT8)
typedef     __INT_FAST8_TYPE__                   int_fast8_t;
#define       INT_FAST8_MIN                  (~__INT_FAST8_MAX__)
#define       INT_FAST8_MAX                    __INT_FAST8_MAX__
#define       INT_FAST8_WIDTH     __STDINT_WIDTH(INT_FAST8)
typedef    __UINT_FAST8_TYPE__                  uint_fast8_t;
#define      UINT_FAST8_MAX                   __UINT_FAST8_MAX__
#define      UINT_FAST8_WIDTH    __STDINT_WIDTH(UINT_FAST8)
typedef    __INT_LEAST8_TYPE__                  int_least8_t;
#define      INT_LEAST8_MIN                 (~__INT_LEAST8_MAX__)
#define      INT_LEAST8_MAX                   __INT_LEAST8_MAX__
#define      INT_LEAST8_WIDTH    __STDINT_WIDTH(INT_LEAST8)
typedef   __UINT_LEAST8_TYPE__                 uint_least8_t;
#define     UINT_LEAST8_MAX                  __UINT_LEAST8_MAX__
#define     UINT_LEAST8_WIDTH   __STDINT_WIDTH(UINT_LEAST8)

typedef         __INT16_TYPE__                       int16_t;
#define           INT16_MIN                      (~__INT16_MAX__)
#define           INT16_MAX                        __INT16_MAX__
#define           INT16_WIDTH         __STDINT_WIDTH(INT16)
#define           INT16_C(C)           __STDINT_C(C, INT16)
typedef        __UINT16_TYPE__                      uint16_t;
#define          UINT16_MAX                       __UINT16_MAX__
#define          UINT16_WIDTH        __STDINT_WIDTH(UINT16)
#define          UINT16_C(C)          __STDINT_C(C, UINT16)
typedef    __INT_FAST16_TYPE__                  int_fast16_t;
#define      INT_FAST16_MIN                 (~__INT_FAST16_MAX__)
#define      INT_FAST16_MAX                   __INT_FAST16_MAX__
#define      INT_FAST16_WIDTH    __STDINT_WIDTH(INT_FAST16)
typedef   __UINT_FAST16_TYPE__                 uint_fast16_t;
#define     UINT_FAST16_MAX                  __UINT_FAST16_MAX__
#define     UINT_FAST16_WIDTH   __STDINT_WIDTH(UINT_FAST16)
typedef   __INT_LEAST16_TYPE__                 int_least16_t;
#define     INT_LEAST16_MIN                (~__INT_LEAST16_MAX__)
#define     INT_LEAST16_MAX                  __INT_LEAST16_MAX__
#define     INT_LEAST16_WIDTH   __STDINT_WIDTH(INT_LEAST16)
typedef  __UINT_LEAST16_TYPE__                uint_least16_t;
#define    UINT_LEAST16_MAX                 __UINT_LEAST16_MAX__
#define    UINT_LEAST16_WIDTH  __STDINT_WIDTH(UINT_LEAST16)

#ifdef          __INT24_TYPE__
typedef         __INT24_TYPE__                       int24_t;
#define           INT24_MIN                      (~__INT24_MAX__)
#define           INT24_MAX                        __INT24_MAX__
#define           INT24_WIDTH         __STDINT_WIDTH(INT24)
#define           INT24_C(C)           __STDINT_C(C, INT24)
typedef        __UINT24_TYPE__                      uint24_t;
#define          UINT24_MAX                       __UINT24_MAX__
#define          UINT24_WIDTH        __STDINT_WIDTH(UINT24)
#define          UINT24_C(C)          __STDINT_C(C, UINT24)
#endif        /*__INT24_TYPE_*/
# 69 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef         __INT32_TYPE__                       int32_t;
#define           INT32_MIN                      (~__INT32_MAX__)
#define           INT32_MAX                        __INT32_MAX__
#define           INT32_WIDTH         __STDINT_WIDTH(INT32)
#define           INT32_C(C)           __STDINT_C(C, INT32)
typedef        __UINT32_TYPE__                      uint32_t;
#define          UINT32_MAX                       __UINT32_MAX__
#define          UINT32_WIDTH        __STDINT_WIDTH(UINT32)
#define          UINT32_C(C)          __STDINT_C(C, UINT32)
typedef    __INT_FAST32_TYPE__                  int_fast32_t;
#define      INT_FAST32_MIN                 (~__INT_FAST32_MAX__)
#define      INT_FAST32_MAX                   __INT_FAST32_MAX__
#define      INT_FAST32_WIDTH    __STDINT_WIDTH(INT_FAST32)
typedef   __UINT_FAST32_TYPE__                 uint_fast32_t;
#define     UINT_FAST32_MAX                  __UINT_FAST32_MAX__
#define     UINT_FAST32_WIDTH   __STDINT_WIDTH(UINT_FAST32)
typedef   __INT_LEAST32_TYPE__                 int_least32_t;
#define     INT_LEAST32_MIN                (~__INT_LEAST32_MAX__)
#define     INT_LEAST32_MAX                  __INT_LEAST32_MAX__
#define     INT_LEAST32_WIDTH   __STDINT_WIDTH(INT_LEAST32)
typedef  __UINT_LEAST32_TYPE__                uint_least32_t;
#define    UINT_LEAST32_MAX                 __UINT_LEAST32_MAX__
#define    UINT_LEAST32_WIDTH  __STDINT_WIDTH(UINT_LEAST32)

#ifdef   __SIZEOF_INT48__
#define         __INT48_TYPE__              signed __int48
#define         __INT48_MAX__  ((__UINT48_TYPE__)(__UINT48_MAX__>>1))
typedef         __INT48_TYPE__                       int48_t;
#define           INT48_MIN                      (~__INT48_MAX__)
#define           INT48_MAX                        __INT48_MAX__
#define           INT48_WIDTH         __STDINT_WIDTH(INT48)
#define           INT48_C(C)                     ((__INT48_TYPE__)(INT64_C(C)))
#define        __UINT48_TYPE__            unsigned __int48
#define        __UINT48_MAX__                   ((__UINT48_TYPE__)~0)
typedef        __UINT48_TYPE__                      uint48_t;
#define          UINT48_MAX                       __UINT48_MAX__
#define          UINT48_WIDTH        __STDINT_WIDTH(UINT48)
#define          UINT48_C(C)                    ((__UINT48_TYPE__)(UINT64_C(C)))
#endif /*__SIZEOF_INT48__*/
# 109 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef         __INT64_TYPE__                       int64_t;
#define           INT64_MIN                      (~__INT64_MAX__)
#define           INT64_MAX                        __INT64_MAX__
#define           INT64_WIDTH         __STDINT_WIDTH(INT64)
#define           INT64_C(C)           __STDINT_C(C, INT64)
typedef        __UINT64_TYPE__                      uint64_t;
#define          UINT64_MAX                       __UINT64_MAX__
#define          UINT64_WIDTH        __STDINT_WIDTH(UINT64)
#define          UINT64_C(C)          __STDINT_C(C, UINT64)
typedef    __INT_FAST64_TYPE__                  int_fast64_t;
#define      INT_FAST64_MIN                 (~__INT_FAST64_MAX__)
#define      INT_FAST64_MAX                   __INT_FAST64_MAX__
#define      INT_FAST64_WIDTH    __STDINT_WIDTH(INT_FAST64)
typedef   __UINT_FAST64_TYPE__                 uint_fast64_t;
#define     UINT_FAST64_MAX                  __UINT_FAST64_MAX__
#define     UINT_FAST64_WIDTH   __STDINT_WIDTH(UINT_FAST64)
typedef   __INT_LEAST64_TYPE__                 int_least64_t;
#define     INT_LEAST64_MIN                (~__INT_LEAST64_MAX__)
#define     INT_LEAST64_MAX                  __INT_LEAST64_MAX__
#define     INT_LEAST64_WIDTH   __STDINT_WIDTH(INT_LEAST64)
typedef  __UINT_LEAST64_TYPE__                uint_least64_t;
#define    UINT_LEAST64_MAX                 __UINT_LEAST64_MAX__
#define    UINT_LEAST64_WIDTH  __STDINT_WIDTH(UINT_LEAST64)

#ifdef  __SIZEOF_INT128__
#define        __INT128_TYPE__             signed __int128
#define        __INT128_MAX__ ((__INT128_TYPE__)(__UINT128_MAX__>>1))
typedef        __INT128_TYPE__                      int128_t;
#define          INT128_MIN                     (~__INT128_MAX__)
#define          INT128_MAX                       __INT128_MAX__
#define          INT128_WIDTH        __STDINT_WIDTH(INT128)
#define       __UINT128_TYPE__           unsigned __int128
#define       __UINT128_MAX__                  ((__UINT128_TYPE__)~0)
typedef       __UINT128_TYPE__                     uint128_t;
#define         UINT128_MAX                      __UINT128_MAX__
#define         UINT128_WIDTH       __STDINT_WIDTH(UINT128)
#endif/*__SIZEOF_INT128__*/
# 147 "/home/smith/Agon/agondev/release/include/stdint.h" 3

typedef        __INTMAX_TYPE__                      intmax_t;
#define          INTMAX_MIN                     (~__INTMAX_MAX__)
#define          INTMAX_MAX                       __INTMAX_MAX__
#define          INTMAX_WIDTH                     __INTMAX_WIDTH__
#define          INTMAX_C(C)          __STDINT_C(C, INTMAX)
typedef       __UINTMAX_TYPE__                     uintmax_t;
#define         UINTMAX_MAX                      __UINTMAX_MAX__
#define         UINTMAX_WIDTH                    __UINTMAX_WIDTH__
#define         UINTMAX_C(C)         __STDINT_C(C, UINTMAX)

typedef        __INTPTR_TYPE__                      intptr_t;
#define          INTPTR_MIN                     (~__INTPTR_MAX__)
#define          INTPTR_MAX                       __INTPTR_MAX__
#define          INTPTR_WIDTH                     __INTPTR_WIDTH__
typedef       __UINTPTR_TYPE__                     uintptr_t;
#define         UINTPTR_MAX                      __UINTPTR_MAX__
#define         UINTPTR_WIDTH                    __UINTPTR_WIDTH__

#define         PTRDIFF_MIN                    (~__PTRDIFF_MAX__)
#define         PTRDIFF_MAX                      __PTRDIFF_MAX__
#define         PTRDIFF_WIDTH                    __PTRDIFF_WIDTH__

#define            SIZE_MAX                         __SIZE_MAX__
#define            SIZE_WIDTH                       __SIZE_WIDTH__

#define            WINT_MIN                       (~__WINT_MAX__)
#define            WINT_MAX                         __WINT_MAX__
#define            WINT_WIDTH                       __WINT_WIDTH__

#ifndef _WCHAR_LIMITS_DEFINED
#define _WCHAR_LIMITS_DEFINED
#define           WCHAR_MIN                      (~__WCHAR_MAX__)
#define           WCHAR_MAX                        __WCHAR_MAX__
#define           WCHAR_WIDTH                      __WCHAR_WIDTH__
#endif
# 183 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#endif/*_STDINT_H*/
# 185 "/home/smith/Agon/agondev/release/include/stdint.h" 3

#ifdef __cplusplus
}
#endif
# 189 "/home/smith/Agon/agondev/release/include/stdint.h" 3
# 32 "/home/smith/Agon/agondev/release/include/agon/mos.h" 2 3

// FatFS Functional configurations as set during MOS compilation (see MOS ffconf.h)
#define FFCONF_DEF	86631	/* Revision ID */
#define FF_FS_READONLY	0
#define FF_FS_MINIMIZE	0
#define FF_USE_FIND		1
#define FF_USE_MKFS		0
#define FF_USE_FASTSEEK	0
#define FF_USE_EXPAND	0
#define FF_USE_CHMOD	0
#define FF_USE_LABEL	1
#define FF_USE_FORWARD	0
#define FF_USE_STRFUNC	1
#define FF_PRINT_LLI	0
#define FF_PRINT_FLOAT	0
#define FF_STRF_ENCODE	0
#define FF_CODE_PAGE	437
#define FF_USE_LFN		2
#define FF_MAX_LFN		255
#define FF_LFN_UNICODE	0
#define FF_LFN_BUF		255
#define FF_SFN_BUF		12
#define FF_FS_RPATH		2
#define FF_VOLUMES		1
#define FF_STR_VOLUME_ID	0
#define FF_VOLUME_STRS		"RAM","NAND","CF","SD","SD2","USB","USB2","USB3"
#define FF_MULTI_PARTITION	0
#define FF_MIN_SS		512
#define FF_MAX_SS		512
#define FF_LBA64		0
#define FF_MIN_GPT		0x10000000
#define FF_USE_TRIM		0
#define FF_FS_TINY		1
#define FF_FS_EXFAT		0
#define FF_FS_NORTC		0
#define FF_NORTC_MON	1
#define FF_NORTC_MDAY	1
#define FF_NORTC_YEAR	2020
#define FF_FS_NOFSINFO	0
#define FF_FS_LOCK		0
#define FF_FS_REENTRANT	0
#define FF_FS_TIMEOUT	1000
#define FF_SYNC_t		HANDLE

// File access modes - from mos.inc
#define FA_READ				    0x01
#define FA_WRITE			    0x02
#define FA_OPEN_EXISTING	    0x00
#define FA_CREATE_NEW		    0x04
#define FA_CREATE_ALWAYS	    0x08
#define FA_OPEN_ALWAYS		    0x10
#define FA_OPEN_APPEND		    0x30

/* File attribute bits for directory entry (FILINFO.fattrib) */
#define	AM_RDO	0x01	/* Read only */
#define	AM_HID	0x02	/* Hidden */
#define	AM_SYS	0x04	/* System */
#define AM_DIR	0x10	/* Directory */
#define AM_ARC	0x20	/* Archive */

// I2C frequency
#define I2C_SPEED_57600			0x01
#define I2C_SPEED_115200		0x02
#define I2C_SPEED_230400		0x03
// I2C return codes to caller
#define RET_OK			        0x00
#define RET_NORESPONSE	        0x01
#define RET_DATA_NACK	        0x02
#define RET_ARB_LOST	        0x04
#define RET_BUS_ERROR	        0x08

/* FatFS File function return code (FRESULT) */

typedef enum {
    FR_OK = 0,              /* (0) Succeeded */
    FR_DISK_ERR,            /* (1) A hard error occurred in the low level disk I/O layer */
    FR_INT_ERR,             /* (2) Assertion failed */
    FR_NOT_READY,           /* (3) The physical drive cannot work */
    FR_NO_FILE,             /* (4) Could not find the file */
    FR_NO_PATH,             /* (5) Could not find the path */
    FR_INVALID_NAME,        /* (6) The path name format is invalid */
    FR_DENIED,              /* (7) Access denied due to prohibited access or directory full */
    FR_EXIST,               /* (8) Access denied due to prohibited access */
    FR_INVALID_OBJECT,      /* (9) The file/directory object is invalid */
    FR_WRITE_PROTECTED,     /* (10) The physical drive is write protected */
    FR_INVALID_DRIVE,       /* (11) The logical drive number is invalid */
    FR_NOT_ENABLED,         /* (12) The volume has no work area */
    FR_NO_FILESYSTEM,       /* (13) There is no valid FAT volume */
    FR_MKFS_ABORTED,        /* (14) The f_mkfs() aborted due to any problem */
    FR_TIMEOUT,             /* (15) Could not get a grant to access the volume within defined period */
    FR_LOCKED,              /* (16) The operation is rejected according to the file sharing policy */
    FR_NOT_ENOUGH_CORE,     /* (17) LFN working buffer could not be allocated */
    FR_TOO_MANY_OPEN_FILES, /* (18) Number of open files > FF_FS_LOCK */
    FR_INVALID_PARAMETER    /* (19) Given parameter is invalid */
} FRESULT;

// Indexes into sysvar - from mos.inc
#define sysvar_time			    0x00    // 4: Clock timer in centiseconds (incremented by 2 every VBLANK)
#define sysvar_vdp_pflags	    0x04    // 1: Flags to indicate completion of VDP commands
#define sysvar_keyascii		    0x05    // 1: ASCII keycode, or 0 if no key is pressed
#define sysvar_keymods		    0x06    // 1: Keycode modifiers
#define sysvar_cursorX		    0x07    // 1: Cursor X position
#define sysvar_cursorY		    0x08    // 1: Cursor Y position
#define sysvar_scrchar		    0x09    // 1: Character read from screen
#define sysvar_scrpixel		    0x0A    // 3: Pixel data read from screen (R,B,G)
#define sysvar_audioChannel	    0x0D    // 1: Audio channel
#define syscar_audioSuccess	    0x0E    // 1: Audio channel note queued (0 = no, 1 = yes)
#define sysvar_scrWidth	        0x0F	// 2: Screen width in pixels
#define sysvar_scrHeight	    0x11	// 2: Screen height in pixels
#define sysvar_scrCols		    0x13	// 1: Screen columns in characters
#define sysvar_scrRows		    0x14	// 1: Screen rows in characters
#define sysvar_scrColours	    0x15	// 1: Number of colours displayed
#define sysvar_scrpixelIndex    0x16	// 1: Index of pixel data read from screen
#define sysvar_vkeycode	        0x17	// 1: Virtual key code from FabGL
#define sysvar_vkeydown			0x18	// 1: Virtual key state from FabGL (0=up, 1=down)
#define sysvar_vkeycount	    0x19	// 1: Incremented every time a key packet is received
#define sysvar_rtc		        0x1A	// 6: Real time clock data
#define sysvar_spare            0x20    // 2: Spare, previously used by rtc
#define sysvar_keydelay	        0x22	// 2: Keyboard repeat delay
#define sysvar_keyrate		    0x24	// 2: Keyboard repeat reat
#define sysvar_keyled		    0x26	// 1: Keyboard LED status
//TODO: for scrMode and below, we need to write getters
#define sysvar_scrMode			0x27	// 1: Screen mode
#define sysvar_rtcEnable		0x28	// 1: RTC enable flag (0: disabled, 1: use ESP32 RTC)
#define sysvar_mouseX			0x29	// 2: Mouse X position
#define sysvar_mouseY			0x2B	// 2: Mouse Y position
#define sysvar_mouseButtons		0x2D	// 1: Mouse button state
#define sysvar_mouseWheel		0x2E	// 1: Mouse wheel delta
#define sysvar_mouseXDelta		0x2F	// 2: Mouse X delta
#define sysvar_mouseYDelta		0x31	// 2: Mouse Y delta
#define sysvar_gp               0x37	// 1: General poll packet data

// Flags for the VDP protocol - sysvar_vdp_pflags
#define vdp_pflag_cursor        0x01
#define vdp_pflag_scrchar       0x02
#define vdp_pflag_point         0x04
#define vdp_pflag_audio         0x08
#define vdp_pflag_mode          0x10
#define vdp_pflag_rtc           0x20
#define vdp_pflag_mouse			0x40

// Stucture for accessing sysvar RTC data used for mos_getrc / mos_setrtc
typedef struct {
    uint8_t year;               // offset since 1980
    uint8_t month;              // (0-11)
    uint8_t day;                // (1-31)
    uint8_t hour;               // (0-23)
    uint8_t minute;             // (0-59)
    uint8_t second;             // (0-59)
} SYSVAR_RTCDATA;

// Structure used in returning mos_unpackrtc MOS 3.0+
typedef struct {
    uint16_t year;
    uint8_t  month;
    uint8_t  day;
    uint8_t  dayOfWeek;
    uint16_t dayOfYear;
    uint8_t  hour;
    uint8_t  minute;
    uint8_t  second;
} vdp_time_t;

// Structure for accesing SYSVAR

typedef struct {
    uint32_t time;
    uint8_t vdp_pflags;
    uint8_t keyascii;
    uint8_t keymods;
    uint8_t cursorX;
    uint8_t cursorY;
    uint8_t scrchar;
    union {
        uint24_t scrpixel;
        struct {
            uint8_t scrpixelR;
            uint8_t scrpixelB;
            uint8_t scrpixelG;
        };
    };
    uint8_t audioChannel;
    uint8_t audioSuccess;
    uint16_t scrWidth;
    uint16_t scrHeight;
    uint8_t scrCols;
    uint8_t scrRows;
    uint8_t scrColours;
    uint8_t scrpixelIndex;
    uint8_t vkeycode;
    uint8_t vkeydown;
    uint8_t vkeycount;
    SYSVAR_RTCDATA rtc;
    uint16_t spare;
    uint16_t keydelay;
    uint16_t keyrate;
    uint8_t keyled;
    uint8_t scrMode;
 	uint8_t rtcEnable;
	uint16_t mouseX;
	uint16_t mouseY;
	uint8_t mouseButtons;
	uint8_t mouseWheel;
	uint16_t mouseXDelta;
	uint16_t mouseYDelta;
} SYSVAR;

extern volatile SYSVAR *sys_vars;  // set at startup by crt0.s

// UART settings for open_UART1
typedef struct {
   int24_t baudRate ;				    //!< The baudrate to be used.
   uint8_t dataBits ;				        //!< The number of databits per character to be used.
   uint8_t stopBits ;				        //!< The number of stopbits to be used.
   uint8_t parity ;				        //!< The parity bit option to be used.
   uint8_t flowcontrol ;
   uint8_t eir ;
} UART ;

// File Object ID and allocation information (FFOBJID)
typedef struct {
	uint24_t*   fs;		    /* Pointer to the hosting volume of this object */
	uint16_t	id;		    /* Hosting volume mount ID */
	uint8_t	    attr;		/* Object attribute */
	uint8_t	    stat;		/* Object chain status (b1-0: =0:not contiguous, =2:contiguous, =3:fragmented in this session, b2:sub-directory stretched) */
	uint32_t	sclust;	    /* Object data start cluster (0:no cluster or root directory) */
	uint32_t	objsize;    /* Object size (valid when sclust != 0) */
} FFOBJID;

// File object structure (FIL)
typedef struct {
	FFOBJID	    obj;       /* Object identifier (must be the 1st member to detect invalid object pointer) */
	uint8_t	    flag;      /* File status flags */
	uint8_t	    err;       /* Abort flag (error code) */
	uint32_t	fptr;      /* File read/write pointer (Zeroed on file open) */
	uint32_t	clust;     /* Current cluster of fpter (invalid when fptr is 0) */
	uint32_t	sect;      /* Sector number appearing in buf[] (0:invalid) */
	uint32_t	dir_sect;  /* Sector number containing the directory entry (not used at exFAT) */ 
	uint24_t*	dir_ptr;   /* Pointer to the directory entry in the win[] (not used at exFAT) */
} FIL;

/* File information structure (FILINFO) */
typedef struct {
	uint32_t	fsize;			/* File size */
	uint16_t	fdate;			/* Modified date */
	uint16_t	ftime;			/* Modified time */
	uint8_t	    fattrib;		/* File attribute */
	char	    altname[13];	/* Alternative file name */
	char	    fname[256]; 	/* Primary file name */
} FILINFO;

/* Directory information structure (DIR) */
typedef struct {
	FFOBJID	    obj;			/* Object identifier */
	uint32_t	dptr;			/* Current read/write offset */
	uint32_t	clust;			/* Current cluster */
	uint32_t	sect;			/* Current sector (0:Read operation has terminated) */
	uint8_t*	dir;			/* Pointer to the directory item in the win[] */
	uint8_t	    fn[12];			/* SFN (in/out) {body[8],ext[3],status[1]} */
	const char* pat;		    /* Pointer to the name matching pattern */
} DIR;

/* Filesystem object structure (FATFS) */
typedef struct {
	uint8_t     fs_type;		/* Filesystem type (0:not mounted) */
	uint8_t	    pdrv;			/* Associated physical drive */
	uint8_t	    n_fats;			/* Number of FATs (1 or 2) */
	uint8_t	    wflag;			/* win[] flag (b0:dirty) */
	uint8_t	    fsi_flag;		/* FSINFO flags (b7:disabled, b0:dirty) */
	uint16_t	id;				/* Volume mount ID */
	uint16_t	n_rootdir;		/* Number of root directory entries (FAT12/16) */
	uint16_t	csize;			/* Cluster size [sectors] */
#if 0 /* disabled by -frewrite-includes */
#if FF_MAX_SS != FF_MIN_SS
#endif
#endif /* disabled by -frewrite-includes */
#if 0 /* evaluated by -frewrite-includes */
# 305 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
	uint16_t	ssize;			/* Sector size (512, 1024, 2048 or 4096) */
#endif
# 307 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
#if 0 /* disabled by -frewrite-includes */
#if FF_USE_LFN
#endif
#endif /* disabled by -frewrite-includes */
#if 1 /* evaluated by -frewrite-includes */
# 308 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
	uint16_t*	lfnbuf;			/* LFN working buffer */
#endif
# 310 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
#if 0 /* disabled by -frewrite-includes */
#if FF_FS_EXFAT
#endif
#endif /* disabled by -frewrite-includes */
#if 0 /* evaluated by -frewrite-includes */
# 311 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
	uint8_t*	dirbuf;			/* Directory entry block scratchpad buffer for exFAT */
#endif
# 313 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
#if 0 /* disabled by -frewrite-includes */
#if FF_FS_REENTRANT
#endif
#endif /* disabled by -frewrite-includes */
#if 0 /* evaluated by -frewrite-includes */
# 314 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
	FF_SYNC_t	sobj;		    /* Identifier of sync object */
#endif
# 316 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
#if 0 /* disabled by -frewrite-includes */
#if !FF_FS_READONLY
#endif
#endif /* disabled by -frewrite-includes */
#if 1 /* evaluated by -frewrite-includes */
# 317 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
	uint32_t	last_clst;		/* Last allocated cluster */
	uint32_t	free_clst;		/* Number of free clusters */
#endif
# 320 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
#if 0 /* disabled by -frewrite-includes */
#if FF_FS_RPATH
#endif
#endif /* disabled by -frewrite-includes */
#if 1 /* evaluated by -frewrite-includes */
# 321 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
	uint32_t	cdir;			/* Current directory start cluster (0:root) */
#if 0 /* disabled by -frewrite-includes */
#if FF_FS_EXFAT
#endif
#endif /* disabled by -frewrite-includes */
#if 0 /* evaluated by -frewrite-includes */
# 323 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
	uint32_t	cdc_scl;		/* Containing directory start cluster (invalid when cdir is 0) */
	uint32_t	cdc_size;		/* b31-b8:Size of containing directory, b7-b0: Chain status */
	uint32_t	cdc_ofs;		/* Offset in the containing directory (invalid when cdir is 0) */
#endif
# 327 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
#endif
# 328 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
	uint32_t	n_fatent;		/* Number of FAT entries (number of clusters + 2) */
	uint32_t	fsize;			/* Size of an FAT [sectors] */
	uint32_t	volbase;		/* Volume base sector */
	uint32_t	fatbase;		/* FAT base sector */
	uint32_t	dirbase;		/* Root directory base sector/cluster */
	uint32_t	database;		/* Data base sector */
#if 0 /* disabled by -frewrite-includes */
#if FF_FS_EXFAT
#endif
#endif /* disabled by -frewrite-includes */
#if 0 /* evaluated by -frewrite-includes */
# 335 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
	uint32_t	bitbase;		/* Allocation bitmap base sector */
#endif
# 337 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
	uint32_t	winsect;		/* Current sector appearing in the win[] */
	uint8_t	    win[FF_MAX_SS];	/* Disk access window for Directory, FAT (and file data at tiny cfg) */
} FATFS;

#ifdef __cplusplus
extern "C" {
#endif
# 344 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3

// Generic IO
extern int   putch(int a);
extern char  getch(void);
extern void  waitvblank(void);
extern void  mos_puts(const char *buffer, uint24_t size, char delimiter); // MOS RST18h with selectable delimiter character
extern void  mos_putstring(const char *string); // Uses optimal MOS RST18h as backend, but defaults to 0-delimited C-style string

// Get system variables
extern uint32_t getsysvar_time();
extern uint8_t  getsysvar_vdp_pflags();
extern uint8_t  getsysvar_keyascii();
extern uint8_t  getsysvar_keymods();
extern uint8_t  getsysvar_cursorX();
extern uint8_t  getsysvar_cursorY();
extern uint8_t  getsysvar_scrchar();
extern uint24_t getsysvar_scrpixel();
extern uint8_t  getsysvar_audioChannel();
extern uint8_t  getsysvar_audioSuccess();
extern uint16_t getsysvar_scrwidth();
extern uint16_t getsysvar_scrheight();
extern uint8_t  getsysvar_scrCols();
extern uint8_t  getsysvar_scrRows();
extern uint8_t  getsysvar_scrColours();
extern uint8_t  getsysvar_scrpixelIndex();
extern uint8_t  getsysvar_vkeycode();
extern uint8_t  getsysvar_vkeydown();
extern uint8_t  getsysvar_vkeycount();
extern volatile SYSVAR_RTCDATA* getsysvar_rtc();  // mos_getrtc() needs to be called to update the values
extern uint16_t getsysvar_keydelay();
extern uint16_t getsysvar_keyrate();
extern uint8_t  getsysvar_keyled();
extern uint8_t  getsysvar_scrMode();
extern uint16_t getsysvar_mouseX(void);
extern uint16_t getsysvar_mouseY(void);
extern uint8_t  getsysvar_mouseButtons(void);
extern int8_t   getsysvar_mouseWheel(void);
extern int16_t  getsysvar_mouseXDelta(void);
extern int16_t  getsysvar_mouseYDelta(void);

// MOS API calls - https://agonconsole8.github.io/agon-docs/MOS-API/ for details
extern uint8_t  mos_load(const char *filename, char * address, uint24_t maxsize);
extern uint8_t  mos_save(const char *filename, char * address, uint24_t nbytes);
extern uint8_t  mos_cd(const char *path);
extern uint8_t  mos_dir(const char *path);
extern uint8_t  mos_del(const char *filename);
extern uint8_t  mos_ren(const char *filename, const char *newname);
extern uint8_t  mos_copy(const char *source, const char *destination);
extern uint8_t  mos_mkdir(const char *path);
extern uint8_t* mos_sysvars(void);
extern uint8_t  mos_editline(char *buffer, uint24_t bufferlength, uint8_t clearbuffer);
extern uint8_t  mos_fopen(const char * filename, uint8_t mode);   // returns filehandle, or 0 on error
extern uint8_t  mos_fclose(uint8_t fh);					    // returns number of still open files
extern char	    mos_fgetc(uint8_t fh);					    // returns character from file, or 0 on error
extern void	    mos_fputc(uint8_t fh, char c);			    // writes character to file
extern uint8_t  mos_feof(uint8_t fh);					    // returns 1 if EOF, 0 otherwise
extern void     mos_getError(uint8_t code, char *buffer, uint24_t bufferlength);
extern uint8_t  mos_oscli(char *command, char **argv, uint24_t argc);
extern uint8_t  mos_getrtc(char *buffer);
extern void     mos_setrtc(uint8_t *timedata);
extern void*    mos_setintvector(uint8_t vector, void(*handler)(void));
extern uint8_t  mos_uopen(UART *settings);
extern void     mos_uclose(void);
extern int      mos_ugetc(void);                              // 0-255 valid character - >255 error
extern int      mos_ugetc_nb(void);                           // same as ugetc, but non-blocking. This function isn't available in MOS rom, but part of the agon library
extern uint8_t  mos_uputc(int a);                           // returns 0 if error
extern uint24_t mos_fread(uint8_t fh, char *buffer, uint24_t numbytes);
extern uint24_t mos_fwrite(uint8_t fh, char *buffer, uint24_t numbytes);
extern uint8_t  mos_flseek(uint8_t fh, uint32_t offset);
extern FIL*     mos_getfil(uint8_t fh);
extern void     mos_setkbvector(void(*handler)(void), uint8_t addresslength);   // length 0:24bit, 1:16bit
extern uint8_t* mos_getkbmap(void); // returns address of the keyboard map
extern void     mos_i2c_open(uint8_t frequency);
extern void     mos_i2c_close(void);
extern uint8_t  mos_i2c_write(uint8_t i2c_address, uint8_t size, unsigned char * buffer);
extern uint8_t  mos_i2c_read(uint8_t i2c_address, uint8_t size, unsigned char * buffer);
extern void     mos_unpackrtc(vdp_time_t *buffer, uint8_t flags); // MOS 3.0+
extern uint8_t  mos_flseek_p(uint8_t filehandle, uint32_t offset); // MOS 3.0+

// String functions
extern int8_t   mos_pmatch(const char *pattern, const char *string, uint8_t flags); // MOS 3.0+
extern void     mos_getargument(char **arg, char **argend, const char *source, uint24_t argnumber); // MOS 3.0+
extern uint8_t  mos_extractstring(char **result, char **next, const char *source, const char *dividers, uint8_t flags); // MOS 3.0+
extern uint8_t  mos_extractnumber(uint24_t *result, char **next, const char *source, const char *dividers, uint8_t flags); // MOS 3.0+
extern uint8_t  mos_escapestring(uint24_t *resultlength, const char *source, char *buffer, uint24_t bufferlength); // MOS 3.0+

// System variables and string translations
extern int      mos_setvarval(char * name, void * value, char ** actualName, uint8_t * type); // MOS 3.0+
extern int      mos_readvarval(char * namePattern, void * value, char ** actualName, int * length, uint8_t * typeFlag); // MOS 3.0+
extern uint8_t  mos_gsinit(const char *source, char **transinfo_ptr, uint8_t flags); // MOS 3.0+
extern uint8_t  mos_gsread(char *char_read, char **transinfo_ptr); // MOS 3.0+
extern int      mos_gstrans(char * source, char * dest, int destLen, int * read, uint8_t flags); // MOS 3.0+
extern int      mos_substituteargs(char * tpl, char * args, char * dest, int length, uint8_t flags); // MOS 3.0+

// File path functions
extern int      mos_resolvepath(char * filepath, char * resolvedPath, int * length, uint8_t * index, DIR * dir, uint8_t flags); // MOS 3.0+
extern int      mos_getdirforpath(char * srcPath, char * dir, int * length, uint8_t index); // MOS 3.0+
extern char*    mos_getleafname(const char *pathname); // MOS 3.0+
extern uint8_t  mos_isdirectory(const char *pathname); // MOS 3.0+
extern int      mos_getabsolutepath(char * path, char * resolved, int * length); // MOS 3.0+

// VDP protocol, and miscellaneous functions
extern uint8_t  mos_clearvdpflags(uint8_t bitmask); // MOS 3.0+
extern uint8_t  mos_waitforvdpflags(uint8_t bitmask); // MOS 3.0+

// Low-level SD card access
extern uint24_t sd_getunlockcode(void); // MOS 3.0+
extern uint8_t  sd_init(uint24_t unlockcode); // MOS 3.0+
extern uint8_t  sd_readblocks(uint32_t sector, uint8_t *buf, uint24_t count); // MOS 3.0+
extern uint8_t  sd_writeblocks(uint32_t sector, uint8_t *buf, uint24_t count); // MOS 3.0+

// MOS FatFS commands
extern uint8_t  ffs_fopen(FIL *fh, const char *filename, uint8_t mode); // MOS 1.03+, returns fresult
extern uint8_t  ffs_fclose(FIL *fh); // MOS 1.03+, returns fresult
extern uint24_t ffs_fread(FIL *fh, char *buffer, uint24_t numbytes); // MOS 1.03+, returns number of bytes read
extern uint24_t ffs_fwrite(FIL *fh, const char *buffer, uint24_t numbytes); // MOS 1.03+, returns number of bytes written
extern uint8_t  ffs_flseek(FIL *fh, uint32_t offset); // MOS 1.03+, returns fresult
extern uint8_t  ffs_ftruncate(FIL *fh); // MOS 2.3.0+, returns fresult
extern uint8_t  ffs_fsync(FIL *fh); // MOS 3.0+, returns fresult
extern uint8_t* ffs_fgets(FIL *fh, char *buffer, uint24_t buffersize); // MOS 3.0+, returns pointer to the target buffer, or NULL if an error occurred
extern uint24_t ffs_fputc(FIL *fh, char c); // MOS 3.0+, returns number of bytes written
extern uint24_t ffs_fputs(FIL *fh, const char *string); // MOS 3.0+, returns number of bytes written
extern int      ffs_fprintf (FIL* fp, const char* str, ...);
extern uint8_t  ffs_ftell(FIL *fh, uint32_t *result); // MOS 3.0+, returns fresult
extern uint8_t  ffs_feof(FIL *fh); // MOS 3.0+, returns 1 if at the end of the file, otherwise 0
extern uint8_t  ffs_fsize(FIL *fh, uint32_t *result); // MOS 3.0+, returns fresult
extern uint8_t  ffs_ferror(FIL *fh); // MOS 3.0+, returns fresult
extern uint8_t  ffs_dopen(DIR *dir_handle, const char * dir_path); // MOS 2.2.0+, returns fresult
extern uint8_t  ffs_dclose(DIR *dir_handle); // MOS 2.2.0+, returns fresult
extern uint8_t  ffs_dread(DIR *dir_handle, FILINFO *fil_handle); // MOS 2.2.0+, returns fresult
extern uint8_t  ffs_dfindfirst(DIR *dir_handle, FILINFO *fil_handle, const char *dirpath, const char *pattern); // MOS 3.0+, returns fresult
extern uint8_t  ffs_dfindnext(DIR *dir_handle, FILINFO *fil_handle); // MOS 3.0+, returns fresult
extern uint8_t  ffs_stat(FILINFO *fil_handle, const char *filename); // MOS 1.03+, returns fresult
extern uint8_t  ffs_unlink(const char *filepath); // MOS 3.0+, returns fresult
extern uint8_t  ffs_rename(const char *sourcefilepath, const char *destfilepath); // MOS 3.0+, returns fresult
extern uint8_t  ffs_mkdir(const char *dirname); // MOS 3.0+, returns fresult
extern uint8_t  ffs_chdir(const char *dirname); // MOS 3.0+, returns fresult
extern uint8_t  ffs_getcwd(char *dirpath, uint24_t bufferlength); // MOS 2.2.0+, returns fresult
extern uint8_t  ffs_mount(FATFS *fs, const char *volpath, uint8_t options); // MOS 3.0+, returns fresult
extern uint8_t  ffs_getfree(char *path, uint32_t *freeclusters, uint32_t *clustersize); // MOS 3.0+, returns fresult
extern uint8_t  ffs_getlabel(char *path, char *label, uint32_t *volserial); // MOS 3.0+, returns fresult
extern uint8_t  ffs_setlabel(const char *volumelabel); // MOS 3.0+, returns fresult
extern uint8_t  ffs_flseek_p(FIL *fh, uint32_t *offset); // MOS 3.0+, returns status code

//extern ffs_fforward(); - not implemented by MOS API
//extern ffs_expand(); - not implemented by MOS API
//extern ffs_chmod(); // not implemented by MOS API
//extern ffs_utime(); // not implemented by MOS API
//extern ffs_chdrive(); // not implemented by MOS API
//extern ffs_mkfs(); // not implemented by MOS API
//extern ffs_fdisk(); // not implemented by MOS API
//extern ffs_setcp(); // not implemented by MOS API

#ifdef __cplusplus
}
#endif
# 500 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3

#endif // _MOS_H
# 502 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3

#ifdef __cplusplus
}
#endif
# 506 "/home/smith/Agon/agondev/release/include/agon/mos.h" 3
# 3 "../runner/include/mos_storage.h" 2
#if 0 /* expanded by -frewrite-includes */
#include "recording.h"
#endif /* expanded by -frewrite-includes */
# 3 "../runner/include/mos_storage.h"
# 4 "../runner/include/mos_storage.h"
extern "C" uint24_t recording_write(FIL*,const char*,uint24_t,uint8_t*);
namespace suite {
struct MosStorage {
 FIL file={};bool opened=false;
 uint32_t open(const char* path) {uint8_t status=ffs_fopen(&file,path,FA_WRITE|FA_CREATE_NEW);opened=status==0;return status;}
 static size_t write(void* ctx,const uint8_t* b,size_t n,uint32_t* status) {
  auto& s=*static_cast<MosStorage*>(ctx);uint8_t result=0;
  size_t written=recording_write(&s.file,reinterpret_cast<const char*>(b),n,&result);
  *status=result;return written;
 }
 static uint32_t sync(void* ctx) {return ffs_fsync(&static_cast<MosStorage*>(ctx)->file);}
 static uint32_t close(void* ctx) {auto& s=*static_cast<MosStorage*>(ctx);uint32_t result=ffs_fclose(&s.file);if(!result)s.opened=false;return result;}
 Storage adapter() {return {this,write,sync,close};}
};
}
# 8 "src/main.cpp" 2
#if 0 /* expanded by -frewrite-includes */
#include <stdio.h>
#endif /* expanded by -frewrite-includes */
# 8 "src/main.cpp"
# 1 "/home/smith/Agon/agondev/release/include/stdio.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stdio.h" 3

#ifndef _STDIO_H
#define _STDIO_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/stdio.h" 3
# 1 "/home/smith/Agon/agondev/release/include/cdefs.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef _CDEFS_H
#define _CDEFS_H

#define __JOIN2(x, y)     x ## y
#define __JOIN3(x, y, z)  x ## y ## z
#define __CONCAT(x, y)    __JOIN2(x, y)
#define __TOSTRING(x)     #x

#define __STDINT_C(C, T)  __CONCAT(C, __##T##_C_SUFFIX__)
#define __STDINT_WIDTH(T) (sizeof(__##T##_TYPE__)*__CHAR_BIT__)

#ifndef __cplusplus
# define __BEGIN_DECLS
# define __END_DECLS
# define __NOEXCEPT     __attribute__((__nothrow__, __leaf__))
# define __IGNORE(expr) ((void)(expr))
#else /* __cplusplus */
# 22 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
# define __BEGIN_DECLS  extern "C" {
# define __END_DECLS    }
# define __NOEXCEPT     noexcept
# define __IGNORE(expr) (static_cast<void>(expr))
#endif /* __cplusplus */
# 27 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef NULL
# ifndef __cplusplus
#  define NULL ((void *)0)
# else /* __cplusplus */
# 32 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
#  define NULL 0
# endif /* __cplusplus */
# 34 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
#endif /* NULL */
# 35 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef SIZE_T_DEFINED
#define SIZE_T_DEFINED
typedef __SIZE_TYPE__ size_t;
#endif /* SIZE_T_DEFINED */
# 40 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#endif /* _CDEFS_H */
# 42 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifdef __cplusplus
}
#endif
# 46 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
# 9 "/home/smith/Agon/agondev/release/include/stdio.h" 2 3
#if 0 /* expanded by -frewrite-includes */
#include <stdarg.h>
#endif /* expanded by -frewrite-includes */
# 9 "/home/smith/Agon/agondev/release/include/stdio.h" 3
# 1 "/home/smith/Agon/agondev/release/include/stdarg.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stdarg.h" 3

#ifndef _STDARG_H
#define _STDARG_H

#ifndef __GNUC_VA_LIST
#define __GNUC_VA_LIST
typedef __builtin_va_list __gnuc_va_list;
#endif /* __GNUC_VA_LIST */
# 12 "/home/smith/Agon/agondev/release/include/stdarg.h" 3

#ifndef _VA_LIST
#define _VA_LIST
typedef __builtin_va_list va_list;
#endif /* _VA_LIST */
# 17 "/home/smith/Agon/agondev/release/include/stdarg.h" 3

#define va_start(ap, param)  __builtin_va_start(ap, param)
#define va_end(ap)           __builtin_va_end(ap)
#define va_arg(ap, type)     __builtin_va_arg(ap, type)
#define __va_copy(dest, src) __builtin_va_copy(dest, src)
#if 0 /* disabled by -frewrite-includes */
#if __STDC_VERSION__ >= 199901L || __cplusplus >= 201103L
#endif
#endif /* disabled by -frewrite-includes */
#if 1 /* evaluated by -frewrite-includes */
# 23 "/home/smith/Agon/agondev/release/include/stdarg.h" 3
# define va_copy(dest, src)   __builtin_va_copy(dest, src)
#endif /* __STDC_VERSION__ >= 199901L || __cplusplus >= 201103L */
# 25 "/home/smith/Agon/agondev/release/include/stdarg.h" 3

#endif /* _STDARG_H */
# 27 "/home/smith/Agon/agondev/release/include/stdarg.h" 3

#ifdef __cplusplus
}
#endif
# 31 "/home/smith/Agon/agondev/release/include/stdarg.h" 3
# 10 "/home/smith/Agon/agondev/release/include/stdio.h" 2 3

typedef struct
{
    unsigned char fhandle;              // storage for the MOS file handle
    unsigned char eof;
    unsigned char err;
    unsigned char text_mode;            // Text or binary mode (true if text mode)
    unsigned char unget_char;           // unget character
    unsigned char has_unget_char;       // unget_char may be a \0 pushback
} FILE;

// Agon MOS allows for 8 open files these will have indexes 0-7

#define FOPEN_MAX 8
#define FH_STDIN 128                    // This is the minimum can check if not real file
#define FH_STDOUT 129                   // by >= FH_STDIN
#define FH_STDERR 130

/* Original CE Toolchain definitions are not real pointers - but are assinged to
#define stdin  ((FILE*)1)
#define stdout ((FILE*)2)
#define stderr ((FILE*)3)
*/
extern FILE stdin[1];
extern FILE stdout[1];
extern FILE stderr[1];

#ifndef EOF
#define EOF (-1)
#endif
# 40 "/home/smith/Agon/agondev/release/include/stdio.h" 3

#ifndef SEEK_CUR
#define SEEK_CUR  1
#endif
# 44 "/home/smith/Agon/agondev/release/include/stdio.h" 3
#ifndef SEEK_END
#define SEEK_END  2
#endif
# 47 "/home/smith/Agon/agondev/release/include/stdio.h" 3
#ifndef SEEK_SET
#define SEEK_SET  0
#endif
# 50 "/home/smith/Agon/agondev/release/include/stdio.h" 3

__BEGIN_DECLS

FILE *fopen(const char *__restrict filename, const char *__restrict mode);

int fclose(FILE *stream);

int fflush(FILE *stream);

int ferror(FILE *stream);

int feof(FILE *stream);

//void clearerr(FILE *stream);

int fputs(const char *__restrict str, FILE *__restrict stream);

size_t fread(void *ptr, size_t size, size_t count, FILE *__restrict stream);

size_t fwrite(const void *__restrict ptr, size_t size, size_t count,
    FILE *__restrict stream);

long int ftell(FILE *stream) __attribute__((__warn_unused_result__));

int fseek(FILE *stream, long int offset, int origin);

int fgetc(FILE *stream);
#define getc(...) fgetc(__VA_ARGS__)

int fputc(int c, FILE *stream);
#define putc(...) fputc(__VA_ARGS__)

char *fgets(char *__restrict str, int num, FILE *__restrict stream);

int remove(const char *fname);

// Not part of stdio, but should have been
unsigned int fgetsize(FILE *file); // Return the size of an opened file

//void rewind(FILE *stream);

/* standard impls */
int getchar(void);

int putchar(int character);

int puts(const char *str);

int printf(const char *__restrict format, ...)
    __attribute__((format(__printf__, 1, 2)));

int vprintf(const char *__restrict format, va_list va)
    __attribute__((format(__printf__, 1, 0)));

int vsprintf(char *__restrict buffer, const char *__restrict format,
    va_list va)
    __attribute__((format(__printf__, 1, 0)));

int snprintf(char* buffer, size_t count, const char *__restrict format, ...)
    __attribute__((format(__printf__, 3, 4)));

int vsnprintf(char* buffer, size_t count, const char *__restrict format,
    va_list va)
    __attribute__((format(__printf__, 3, 0)));

int sprintf(char *__restrict buffer,
    const char *__restrict format, ...)
    __attribute__ ((format (__printf__, 2, 3)));

// Functions added to the CE Toolchain stdio library

int fprintf(FILE *stream, const char *__restrict format, ...)
    __attribute__((format(__printf__, 2, 3)));

int vfprintf(FILE *stream, const char *__restrict format, va_list va)
    __attribute__((format(__printf__, 2, 0)));

typedef size_t rsize_t;

char *gets_s( char *__restrict str, rsize_t n );
int scanf( const char *format, ...);
int sscanf( const char *s, const char *format, ...);
int fscanf( FILE *fp, const char *fmt,...);
FILE *freopen( const char *__restrict filename, const char *__restrict mode, FILE *stream );
int ungetc(int c, FILE *stream);


__END_DECLS

#endif /* _STDIO_H */
# 140 "/home/smith/Agon/agondev/release/include/stdio.h" 3

#ifdef __cplusplus
}
#endif
# 144 "/home/smith/Agon/agondev/release/include/stdio.h" 3
# 9 "src/main.cpp" 2
#if 0 /* expanded by -frewrite-includes */
#include <stdlib.h>
#endif /* expanded by -frewrite-includes */
# 9 "src/main.cpp"
# 1 "/home/smith/Agon/agondev/release/include/stdlib.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/stdlib.h" 3

#ifndef _STDLIB_H
#define _STDLIB_H

#if 0 /* expanded by -frewrite-includes */
#include <cdefs.h>
#endif /* expanded by -frewrite-includes */
# 8 "/home/smith/Agon/agondev/release/include/stdlib.h" 3
# 1 "/home/smith/Agon/agondev/release/include/cdefs.h" 1 3
#ifdef __cplusplus
extern "C" {
#endif
# 4 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef _CDEFS_H
#define _CDEFS_H

#define __JOIN2(x, y)     x ## y
#define __JOIN3(x, y, z)  x ## y ## z
#define __CONCAT(x, y)    __JOIN2(x, y)
#define __TOSTRING(x)     #x

#define __STDINT_C(C, T)  __CONCAT(C, __##T##_C_SUFFIX__)
#define __STDINT_WIDTH(T) (sizeof(__##T##_TYPE__)*__CHAR_BIT__)

#ifndef __cplusplus
# define __BEGIN_DECLS
# define __END_DECLS
# define __NOEXCEPT     __attribute__((__nothrow__, __leaf__))
# define __IGNORE(expr) ((void)(expr))
#else /* __cplusplus */
# 22 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
# define __BEGIN_DECLS  extern "C" {
# define __END_DECLS    }
# define __NOEXCEPT     noexcept
# define __IGNORE(expr) (static_cast<void>(expr))
#endif /* __cplusplus */
# 27 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef NULL
# ifndef __cplusplus
#  define NULL ((void *)0)
# else /* __cplusplus */
# 32 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
#  define NULL 0
# endif /* __cplusplus */
# 34 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
#endif /* NULL */
# 35 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifndef SIZE_T_DEFINED
#define SIZE_T_DEFINED
typedef __SIZE_TYPE__ size_t;
#endif /* SIZE_T_DEFINED */
# 40 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#endif /* _CDEFS_H */
# 42 "/home/smith/Agon/agondev/release/include/cdefs.h" 3

#ifdef __cplusplus
}
#endif
# 46 "/home/smith/Agon/agondev/release/include/cdefs.h" 3
# 9 "/home/smith/Agon/agondev/release/include/stdlib.h" 2 3

typedef struct {
  int quot;
  int rem;
} div_t;

typedef struct {
  long quot;
  long rem;
} ldiv_t;

typedef struct {
  long long rem;
  long long quot;
} lldiv_t;

typedef char __align;
union header {
  struct {
    union header *ptr;
    unsigned int size;
  } s;
  __align x;
};
typedef union header _HEADER;

#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1

#define RAND_MAX 8388607

#define HEADER _HEADER
#define allocp _allocp
#define NALLOC 50

__BEGIN_DECLS

void *calloc(size_t nmemb, size_t size) __attribute__((malloc));

void *malloc(size_t size) __attribute__((malloc));

void *realloc(void *ptr, size_t size) __attribute__((warn_unused_result));

void free(void *ptr) __NOEXCEPT;

double atof(const char *nptr) __attribute__((nonnull(1)));

int atoi(const char *nptr) __attribute__((nonnull(1)));

long atol(const char *nptr) __attribute__((nonnull(1)));

long long atoll(const char *nptr) __attribute__((nonnull(1)));

float strtof(const char *__restrict nptr,
             char **__restrict endptr) __attribute__((nonnull(1)));

double strtod(const char *__restrict nptr,
              char **__restrict endptr) __attribute__((nonnull(1)));

long strtol(const char *__restrict nptr,
            char **__restrict endptr, int base) __attribute__((nonnull(1)));

long long strtoll(const char *__restrict nptr,
                  char **__restrict endptr,
                  int base) __attribute__((nonnull(1)));

unsigned long strtoul(const char *__restrict nptr,
                      char **__restrict endptr, int base)
                      __attribute__((nonnull(1)));

unsigned long long strtoull(const char *__restrict nptr,
                            char **__restrict endptr, int base)
                            __attribute__((nonnull(1)));

void srand(unsigned int seed);

int rand(void);

void *bsearch(const void *key, const void *base, size_t nmemb, size_t size,
              int (*compar)(const void *, const void *))
              __attribute__((nonnull(1, 2, 5)));

void qsort(void *base, size_t nmemb, size_t size,
           int (*compar)(const void *, const void *))
           __attribute__((nonnull(1, 4)));

void abort(void) __NOEXCEPT __attribute__((noreturn));

int atexit(void (*)(void)) __NOEXCEPT;

int on_exit(void (*)(int, void *), void *) __NOEXCEPT;

void exit(int) __NOEXCEPT __attribute__((noreturn));

int at_quick_exit(void (*)(void)) __NOEXCEPT;

void quick_exit(int) __NOEXCEPT __attribute__((noreturn));

void _Exit(int) __NOEXCEPT __attribute__((noreturn));

int abs(int n);

long labs(long n);

long long llabs(long long n);

div_t div(int numer, int denom);

ldiv_t ldiv(long numer, long denom);

lldiv_t lldiv(long long numer, long long denom);

__END_DECLS

#endif /* _STDLIB_H */
# 124 "/home/smith/Agon/agondev/release/include/stdlib.h" 3

#ifdef __cplusplus
}
#endif
# 128 "/home/smith/Agon/agondev/release/include/stdlib.h" 3
# 10 "src/main.cpp" 2
using namespace suite;
extern "C" void startup_probe();
extern "C" void startup_command_done();
extern "C" uint8_t startup_sample,startup_kind;
extern "C" volatile uint8_t startup_status;
volatile uint8_t startup_status=255;
static volatile uint8_t* const ram=reinterpret_cast<volatile uint8_t*>(0xb7e000);
// Private invocation state occupies capture-reserved A00-CFF, not a wire record.
struct Session {uint8_t magic[4],id[16],hashes[128],script[32];uint8_t mask,index;uint32_t counts[8],length;char directory[64];uint32_t crc;};
static_assert(sizeof(Session)<768,"session SRAM reservation");
static Session session;
static char scratch[16384],script[8193];
static bool readfile(const char* path,void* data,size_t cap,size_t& n){FIL f={};if(ffs_fopen(&f,path,FA_READ))return false;uint32_t length=0;bool ok=!ffs_fsize(&f,&length)&&length<=cap;n=ok?ffs_fread(&f,static_cast<char*>(data),length):0;uint8_t err=ffs_ferror(&f),close=ffs_fclose(&f);return ok&&n==length&&!err&&!close;}
static bool savefile(const char* path,const void* data,size_t n){MosStorage f;if(f.open(path))return false;uint32_t status=0;bool ok=MosStorage::write(&f,static_cast<const uint8_t*>(data),n,&status)==n&&!status;if(ok)ok=!MosStorage::sync(&f);uint32_t close=MosStorage::close(&f);return ok&&!close;}
static bool hashfile(const char* path,uint8_t digest[32]){FIL f={};if(ffs_fopen(&f,path,FA_READ))return false;Sha256 h;char buf[512];while(!ffs_feof(&f)){size_t n=ffs_fread(&f,buf,sizeof buf);if(!n){ffs_fclose(&f);return false;}h.add(buf,n);}bool ok=!ffs_ferror(&f);ok=ffs_fclose(&f)==0&&ok;h.finish(digest);return ok;}
static bool copyfile(const char* source,const char* destination){FIL in={};if(ffs_fopen(&in,source,FA_READ))return false;MosStorage out;if(out.open(destination)){ffs_fclose(&in);return false;}char buf[512];bool ok=true;while(!ffs_feof(&in)){size_t n=ffs_fread(&in,buf,sizeof buf);uint32_t status=0;if(!n||MosStorage::write(&out,reinterpret_cast<uint8_t*>(buf),n,&status)!=n||status){ok=false;break;}}ok=!ffs_ferror(&in)&&ok;ok=ffs_fclose(&in)==0&&ok;if(ok)ok=!MosStorage::sync(&out);ok=MosStorage::close(&out)==0&&ok;return ok;}
static void path(char* dest,const char* name){snprintf(dest,128,"%s/%s",session.directory,name);}
static void remember(){memcpy(session.magic,"MSTS",4);session.crc=wire::crc(reinterpret_cast<const uint8_t*>(&session),offsetof(Session,crc));for(size_t i=0;i<sizeof session;++i)ram[0xa00+i]=reinterpret_cast<const uint8_t*>(&session)[i];}
static bool recall(){for(size_t i=0;i<sizeof session;++i)reinterpret_cast<uint8_t*>(&session)[i]=ram[0xa00+i];return !memcmp(session.magic,"MSTS",4)&&session.crc==wire::crc(reinterpret_cast<const uint8_t*>(&session),offsetof(Session,crc))&&session.directory[63]==0;}
static bool script_selection(Selection& selection,uint8_t digest[32]){size_t n=0;if(!readfile("/autoexec.txt",script,8192,n))return false;Sha256 h;h.add(script,n);h.finish(digest);script[n]=0;return parse_script(script,n,FUNCTIONS,selection);}
static bool allocation_intent();
static bool allocate(){uint8_t b[24];size_t n=0;if(!readfile("/mos-tests/install.bin",b,sizeof b,n)||n!=24||memcmp(b+20,"MSTI",4)||wire::get32(b+16)!=wire::crc(b,16))return false;
 uint64_t count=0;for(unsigned i=0;i<8;++i)count|=uint64_t(b[8+i])<<(8*i);if(count==UINT64_MAX)return false;++count;for(unsigned i=0;i<8;++i)b[8+i]=count>>(8*i);wire::put32(b+16,wire::crc(b,16));
 memcpy(session.id,b,16);if(!allocation_intent())return false;
 FIL f={};if(ffs_fopen(&f,"/mos-tests/install.bin",FA_WRITE))return false;uint8_t status=0;bool ok=recording_write(&f,reinterpret_cast<char*>(b),24,&status)==24&&!status;ok=!ffs_fsync(&f)&&ok;ok=ffs_fclose(&f)==0&&ok;if(!ok)return false;
 memcpy(session.id,b,16);char id[33];hex(b,16,id);snprintf(session.directory,sizeof session.directory,"/mos-tests/runs/%s",id);return ffs_mkdir(session.directory)==0;
}
static bool prepare_files(){
 const char* manifests[3]={"bundle.json","catalogue.json","target.json"};const unsigned offsets[3]={0,32,96};char from[128],to[128];
 for(unsigned i=0;i<3;++i){snprintf(from,sizeof from,"/mos-tests/%s",manifests[i]);if(!hashfile(from,session.hashes+offsets[i]))return false;path(to,manifests[i]);if(i==0&&!copyfile(from,to))return false;}
 if(memcmp(session.hashes+32,CATALOGUE_DIGEST,32))return false;
 size_t n=0;if(!readfile("/mos-tests/bundle.json",scratch,sizeof scratch-1,n))return false;scratch[n]=0;
 uint8_t list_hash[32];char list_hex[65];if(!hashfile("/mos-tests/files.lst",list_hash))return false;hex(list_hash,32,list_hex);if(!strstr(scratch,list_hex))return false;
 if(!readfile("/mos-tests/files.lst",scratch,sizeof scratch-1,n))return false;scratch[n]=0;char* line=scratch;
 while(*line){char* end=strchr(line,'\n');if(!end)return false;*end=0;char* space=strchr(line,' ');if(!space)return false;*space++=0;
  if(!*line||strlen(line)>80||strchr(line,'/')||strstr(line,"..")||strlen(space)!=64)return false;
  snprintf(from,sizeof from,"/mos-tests/%s",line);uint8_t digest[32];char observed[65];if(!hashfile(from,digest))return false;hex(digest,32,observed);if(strcmp(observed,space))return false;path(to,line);if(!copyfile(from,to))return false;line=end+1;
 }
 path(to,"files.lst");if(!copyfile("/mos-tests/files.lst",to))return false;
 snprintf(from,sizeof from,"/mos-tests/plan-%u.json",session.mask);if(!readfile(from,scratch,sizeof scratch-1,n))return false;scratch[n]=0;
 char marker[65];memset(marker,'@',64);marker[64]=0;char* at=strstr(scratch,marker);if(!at||strstr(at+64,marker))return false;char sh[65];hex(session.script,32,sh);memcpy(at,sh,64);
 Sha256 hash;hash.add(scratch,n);hash.finish(session.hashes+64);path(to,"plan.json");if(!savefile(to,scratch,n))return false;
 path(to,"selection-script.txt");if(!savefile(to,script,strlen(script)))return false;
 char id[33],h[4][65];hex(session.id,16,id);for(unsigned i=0;i<4;++i)hex(session.hashes+32*i,32,h[i]);
 int len=snprintf(scratch,sizeof scratch,"{\"schema\":1,\"run_id\":\"%s\",\"parent_run_id\":null,\"bundle_sha256\":\"%s\",\"catalogue_sha256\":\"%s\",\"plan_sha256\":\"%s\",\"target_sha256\":\"%s\"}\n",id,h[0],h[1],h[2],h[3]);path(to,"run.json");return len>0&&size_t(len)<sizeof scratch&&savefile(to,scratch,len);
}
struct Context {RecordedLifecycle* bridge;uint8_t fault;};
static bool metadata(void*,const Case& c,wire::Payload& p){return p.case_start(2,CASE_HASHES[c.key-1]);}
static Result execute(void* data,const Case& c){auto& context=*static_cast<Context*>(data);unsigned failed=0;
 for(unsigned sample=0;sample<2;++sample){startup_sample=sample;startup_kind=c.key==2;startup_probe();uint8_t pair[96]={};for(unsigned i=0;i<64;++i)pair[i]=ram[0x900+i];memset(pair+64,255,20);if(c.key==2)pair[64+13]=0x7f;
  bool okay=true;for(unsigned i=0;i<20;++i){uint8_t expected=pair[i]^((c.key==2&&i==13)?128:0);if(pair[32+i]!=expected)okay=false;}if(!okay)++failed;
  wire::Payload p;if(!p.observation(1,sample,0,1,1,pair,96)||!context.bridge->observation(p))return {Outcome::Error,0,0,"capture checkpoint failed"};
 }
 if(context.fault==1&&c.key==1)++failed;
 return failed?Result{Outcome::Failed,3,failed,"synthetic control did not match its expected register effect (or deliberate qualification failure)"}:Result{Outcome::Passed,2,0,""};
}
static bool cleanup(void*,const Case&){return true;}
#if 0 /* expanded by -frewrite-includes */
#include "recovery_target.h"
#endif /* expanded by -frewrite-includes */
# 67 "src/main.cpp"
# 1 "./include/recovery_target.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "./include/recovery_target.h"
#if 0 /* expanded by -frewrite-includes */
#include "recovery.h"
#endif /* expanded by -frewrite-includes */
# 2 "./include/recovery_target.h"
# 1 "./include/recovery.h" 1
#if 0 /* expanded by -frewrite-includes */
#pragma once
#endif /* expanded by -frewrite-includes */
# 2 "./include/recovery.h"
#if 0 /* expanded by -frewrite-includes */
#include "recording.h"
#endif /* expanded by -frewrite-includes */
# 2 "./include/recovery.h"
# 3 "./include/recovery.h"
namespace recovery {
using namespace suite;
inline uint16_t u16(const uint8_t* p){return p[0]|uint16_t(p[1])<<8;}
inline uint64_t u64(const uint8_t* p){uint64_t n=0;for(unsigned i=0;i<8;++i)n|=uint64_t(p[i])<<(8*i);return n;}
inline void put64(uint8_t* p,uint64_t n){for(unsigned i=0;i<8;++i)p[i]=n>>(8*i);}
inline bool zero(const uint8_t* p,size_t n){while(n--)if(*p++)return false;return true;}
enum Phase:uint8_t {IDLE,ALLOCATING,BETWEEN,CASE_INTENT,IN_CASE,CASE_DONE,FINALIZING,COMPLETE,DISPOSING,PARKED,ARMED};
struct Slot {
 uint8_t b[256]={};
 uint64_t generation()const{return u64(b+16);}
 uint64_t counter()const{return u64(b+140);}
 uint8_t phase()const{return b[120];}
 uint32_t sequence()const{return wire::get32(b+128);}
 uint64_t length()const{return u64(b+132);}
 void seal(){wire::put32(b+248,wire::crc(b,248));b[252]=0xa5;}
 bool valid()const{
  if(memcmp(b,"MSTJ",4)||u16(b+4)!=1||u16(b+6)!=256||!generation()||b[252]!=0xa5||
     wire::get32(b+248)!=wire::crc(b,248)||!zero(b+122,2)||!zero(b+180,68)||!zero(b+253,3)||
     phase()>ARMED||b[121]>3)return false;
  if(phase()==IDLE)return zero(b+24,224);
  return !zero(b+24,16)&&!memcmp(b+8,b+24,8)&&u64(b+32)==counter()&&counter();
 }
};
// Reader accepts W01 wire states, while the W02 executor rejects dispositions.
inline bool edge(uint8_t a,uint8_t b){
 return (a==IDLE&&(b==IDLE||b==ALLOCATING))||(a==COMPLETE&&b==ALLOCATING)||
 (a==ALLOCATING&&b==BETWEEN)||(a==BETWEEN&&(b==CASE_INTENT||b==FINALIZING))||
 (a==CASE_INTENT&&b==IN_CASE)||(a==IN_CASE&&b==CASE_DONE)||
 (a==CASE_DONE&&b==BETWEEN)||(a==FINALIZING&&b==COMPLETE)||
 (a!=IDLE&&a!=COMPLETE&&b==DISPOSING)||
 (a==DISPOSING&&(b==PARKED||b==ARMED))||(a==ARMED&&b==ALLOCATING);
}
inline bool pair(const Slot& a,const Slot& b,unsigned& selected){
 if(!a.valid()||!b.valid()||memcmp(a.b+8,b.b+8,8))return false;
 if(a.generation()==b.generation()){selected=0;return !memcmp(a.b,b.b,256);}
 selected=a.generation()>b.generation()?0:1;
 const Slot& old=selected? a:b;const Slot& now=selected?b:a;
 if(now.generation()-old.generation()!=1||!edge(old.phase(),now.phase()))return false;
 if(now.phase()==ALLOCATING){
  return old.counter()!=UINT64_MAX&&now.counter()==old.counter()+1&&
   !now.sequence()&&!now.length()&&zero(now.b+56,32)&&!wire::get32(now.b+124);
 }
 if(memcmp(old.b+24,now.b+24,16)||old.counter()!=now.counter())return false;
 if(now.sequence()<old.sequence()||now.length()<old.length())return false;
 if(old.phase()!=ALLOCATING&&now.phase()!=DISPOSING&&old.phase()!=DISPOSING&&
    memcmp(old.b+56,now.b+56,64))return false;
 return true;
}
// Streaming, deliberately restricted to the three qualified startup controls.
// More general record kinds remain a conservative unsupported-input error.
struct Records {
 uint8_t id[16],hashes[128],contracts[3][64];unsigned mask;
 uint32_t sequence=0,bytes=0,current=0,ended_mask=0,counts[8]={},observations=0;
 uint32_t failed_mask=0;bool begun=false,complete=false,difference=false;
 Records(const uint8_t* run,const uint8_t* h,const uint8_t c[3][64],unsigned m):mask(m){
  memcpy(id,run,16);memcpy(hashes,h,128);memcpy(contracts,c,192);
 }
 bool accept(const uint8_t* b,size_t n){
  if(n<47||n>1069||complete||memcmp(b,"MSTR",4)||b[4]!=1||u16(b+6)!=40||
   memcmp(b+8,id,16)||wire::get32(b+24)!=sequence+1||!zero(b+36,4)||
   wire::get32(b+32)+45!=n||b[n-1]!=0xa5||wire::get32(b+n-5)!=wire::crc(b,n-5))return false;
  const uint8_t* p=b+40;size_t len=n-45;uint32_t key=wire::get32(b+28);uint8_t type=b[5];
  if(u16(p)!=1)return false;
  if(type==1){
   if(begun||sequence||key||len!=136||p[3]||p[2]<1||p[2]>2||
      wire::get32(p+4)!=unsigned((mask&1)!=0)+unsigned((mask&2)!=0)+unsigned((mask&4)!=0)||
      memcmp(p+8,hashes,128))return false;
   begun=true;
  }else{
   if(!begun)return false;
   if(type==6){
    if(current||ended_mask!=mask||key||len!=68||!zero(p+2,2)||memcmp(p+36,hashes+64,32))return false;
    for(unsigned i=0;i<8;++i)if(wire::get32(p+4+4*i)!=counts[i])return false;
    complete=true;
   }else{
    if(key<1||key>3||!(mask&(1<<(key-1))))return false;
    if(type==2){
     unsigned next=1;while(next<=3&&(!(mask&(1<<(next-1)))||(ended_mask&(1<<(next-1)))))++next;
     if(current||key!=next||len!=68||u16(p+2)!=2||memcmp(p+4,contracts[key-1],64))return false;
     current=key;observations=0;difference=false;
    }else if(type==3){
     if(current!=key||key==3||observations>=2||len!=112||p[2]!=1||p[3]||
        u16(p+4)!=observations||u16(p+6)||u16(p+8)!=1||u16(p+10)!=96||wire::get32(p+12)!=1)return false;
     const uint8_t* before=p+16;const uint8_t* after=p+48;const uint8_t* preservation=p+80;
     for(unsigned i=0;i<32;++i){
      uint8_t expected=i<20?255:0;if(key==2&&i==13)expected=0x7f;
      if(preservation[i]!=expected)return false;
     }
     for(unsigned s=0;s<2;++s){const uint8_t* snap=s?after:before;
      if(u16(snap+26)!=0x3ff||!zero(snap+28,4)||snap[24]!=1||snap[25])return false;
     }
     for(unsigned i=0;i<26;++i)if((before[i]^after[i])&preservation[i])difference=true;
     ++observations;
    }else if(type==4){
     if(current!=key||len<20||p[3]||u16(p+18)||u16(p+16)!=len-20||wire::get32(p+12)!=observations)return false;
     uint8_t outcome=p[2];uint32_t assertions=wire::get32(p+4),failed=wire::get32(p+8);
     if(failed>assertions||memchr(p+20,0,len-20))return false;
     char reason[1005];if(len-20>1004)return false;memcpy(reason,p+20,len-20);reason[len-20]=0;
     if(!wire::utf8(reason,len-20))return false;
     if(key==3){if(outcome!=5||assertions||failed||observations||len==20)return false;}
     else if(observations!=2||((outcome!=1)&&(outcome!=2))||!assertions||
      (outcome==1&&(failed||difference||len!=20))||(outcome==2&&(!failed||len==20)))return false;
     ++counts[outcome-1];if(outcome==2)failed_mask|=1<<(key-1);ended_mask|=1<<(key-1);current=0;
    }else return false;
   }
  }
  ++sequence;bytes+=n;return true;
 }
};
}
# 3 "./include/recovery_target.h" 2
// Target adapter. Reuses the startup file/hash helpers and the qualified wire layer.
extern "C" { uint8_t recovery_diagnostic[64]={}; }
namespace recovery_target {
using namespace recovery;
static Slot slots[2];static unsigned chosen;static uint8_t allocation[24];
static char saved_script[8193],compare_text[16384],file_list[16384];
static uint32_t inspected_bytes=0;
static const char* const slot_paths[2]={"/mos-tests/recovery-a.bin","/mos-tests/recovery-b.bin"};
inline Slot& latest(){return slots[chosen];}
inline void diagnose(uint8_t code){
 recovery_diagnostic[0]=code;
 printf("INCOMPLETE: recovery gate stopped (reason %u, phase %u, case %lu). No test was authorized.\n",
  code,recovery_diagnostic[1],(unsigned long)wire::get32(recovery_diagnostic+4));
 unsigned failures=recovery_diagnostic[8];for(unsigned i=0;i<3;++i)if(failures&(1<<i))printf("FAILED: %s has a confirmed failure in retained evidence.\n",CASES[i].id);
}
inline bool load(){
 size_t n=0;
 if(!readfile(slot_paths[0],slots[0].b,256,n)||n!=256||
    !readfile(slot_paths[1],slots[1].b,256,n)||n!=256||!pair(slots[0],slots[1],chosen))return false;
 Slot& s=latest();recovery_diagnostic[1]=s.phase();memcpy(recovery_diagnostic+16,s.b+24,16);
 wire::put32(recovery_diagnostic+4,wire::get32(s.b+124));
 if(!readfile("/mos-tests/install.bin",allocation,24,n)||n!=24||memcmp(allocation+20,"MSTI",4)||
    wire::get32(allocation+16)!=wire::crc(allocation,16)||memcmp(allocation,s.b+8,8))return false;
 return true;
}
inline bool publish(uint8_t phase,uint32_t key,uint32_t sequence,uint32_t length){
 Slot next=latest();if(next.generation()==UINT64_MAX)return false;
 put64(next.b+16,next.generation()+1);next.b[120]=phase;wire::put32(next.b+124,key);
 wire::put32(next.b+128,sequence);put64(next.b+132,length);
 if(phase==ALLOCATING){
  memcpy(next.b+24,session.id,16);memset(next.b+40,0,48);
  memcpy(next.b+88,session.script,32);put64(next.b+140,u64(session.id+8));
 }else if(phase==BETWEEN)memcpy(next.b+56,session.hashes+64,32);
 next.seal();unsigned destination=chosen^1,selected=0;
 if(!pair(latest(),next,selected)||selected!=1)return false;
 FIL f={};if(ffs_fopen(&f,slot_paths[destination],FA_WRITE))return false;
 uint8_t status=0,zero_byte=0,commit=0xa5;
 bool ok=!ffs_flseek(&f,252)&&recording_write(&f,reinterpret_cast<char*>(&zero_byte),1,&status)==1&&!status&&!ffs_fsync(&f);
 next.b[252]=0;
 if(ok)ok=!ffs_flseek(&f,0)&&recording_write(&f,reinterpret_cast<char*>(next.b),256,&status)==256&&!status&&!ffs_fsync(&f);
 if(ok)ok=!ffs_flseek(&f,252)&&recording_write(&f,reinterpret_cast<char*>(&commit),1,&status)==1&&!status&&!ffs_fsync(&f);
 bool closed=ffs_fclose(&f)==0;next.b[252]=0xa5;
 Slot check;size_t n=0;
 if(!ok||!closed||!readfile(slot_paths[destination],check.b,256,n)||n!=256||memcmp(next.b,check.b,256))return false;
 slots[destination]=next;chosen=destination;return true;
}
inline bool digest_match(const char* pathname,const uint8_t* expected){
 uint8_t observed[32];return hashfile(pathname,observed)&&!memcmp(observed,expected,32);
}
inline bool bounded_hash(const char* pathname,uint8_t* digest){
 FILINFO info={};return !ffs_stat(&info,pathname)&&info.fsize<=16384&&hashfile(pathname,digest);
}
inline bool from_hex(const char* s,uint8_t* bytes,size_t n){
 if(strlen(s)!=n*2)return false;
 for(size_t i=0;i<n;++i){unsigned a=0,b=0;char x=s[i*2],y=s[i*2+1];
  if(x>='0'&&x<='9')a=x-'0';else if(x>='a'&&x<='f')a=x-'a'+10;else return false;
  if(y>='0'&&y<='9')b=y-'0';else if(y>='a'&&y<='f')b=y-'a'+10;else return false;
  bytes[i]=(a<<4)|b;
 }return true;
}
// Only canonical manifests produced by this same bundle are supported in W02.
// Exact template equality is stricter than accepting arbitrary equivalent JSON.
inline bool inspect_run(const char* directory,const uint8_t* id,bool& complete,uint32_t& seq,uint32_t& length){
 char pathname[160],source[160];uint8_t hashes[128],script_hash[32];size_t n=0;Selection selection;
 snprintf(pathname,sizeof pathname,"%s/selection-script.txt",directory);
 if(!readfile(pathname,saved_script,8192,n)||!parse_script(saved_script,n,FUNCTIONS,selection))return false;
 Sha256 sh;sh.add(saved_script,n);sh.finish(script_hash);
 const char* names[3]={"bundle.json","catalogue.json","target.json"};unsigned offsets[3]={0,32,96};
 for(unsigned i=0;i<3;++i){
  snprintf(source,sizeof source,"/mos-tests/%s",names[i]);snprintf(pathname,sizeof pathname,"%s/%s",directory,names[i]);
  if(!bounded_hash(source,hashes+offsets[i])||!digest_match(pathname,hashes+offsets[i]))return false;
 }
 if(memcmp(hashes+32,CATALOGUE_DIGEST,32))return false;
 snprintf(source,sizeof source,"/mos-tests/plan-%u.json",selection.mask);
 if(!readfile(source,compare_text,sizeof compare_text-1,n))return false;compare_text[n]=0;
 char marker[65],digest[65];memset(marker,'@',64);marker[64]=0;char* at=strstr(compare_text,marker);
 if(!at||strstr(at+64,marker))return false;hex(script_hash,32,digest);memcpy(at,digest,64);
 Sha256 plan;plan.add(compare_text,n);plan.finish(hashes+64);
 snprintf(pathname,sizeof pathname,"%s/plan.json",directory);if(!digest_match(pathname,hashes+64))return false;
 // The original bundle inventory is mandatory; inspect every artifact it names.
 uint8_t list_hash[32];if(!bounded_hash("/mos-tests/files.lst",list_hash))return false;
 snprintf(pathname,sizeof pathname,"%s/files.lst",directory);if(!digest_match(pathname,list_hash))return false;
 if(!readfile("/mos-tests/files.lst",file_list,sizeof file_list-1,n))return false;file_list[n]=0;
 char* line=file_list;while(*line){
  char* end=strchr(line,'\n');if(!end)return false;*end=0;char* space=strchr(line,' ');if(!space)return false;*space++=0;
  if(!*line||strlen(line)>80||strchr(line,'/')||strchr(line,'\\')||strstr(line,".."))return false;
  uint8_t expected[32];if(!from_hex(space,expected,32))return false;
  snprintf(pathname,sizeof pathname,"%s/%s",directory,line);if(!digest_match(pathname,expected))return false;line=end+1;
 }
 char run_id[33],h[4][65];hex(id,16,run_id);for(unsigned i=0;i<4;++i)hex(hashes+32*i,32,h[i]);
 int size=snprintf(compare_text,sizeof compare_text,"{\"schema\":1,\"run_id\":\"%s\",\"parent_run_id\":null,\"bundle_sha256\":\"%s\",\"catalogue_sha256\":\"%s\",\"plan_sha256\":\"%s\",\"target_sha256\":\"%s\"}\n",run_id,h[0],h[1],h[2],h[3]);
 if(size<0||size_t(size)>=sizeof compare_text)return false;Sha256 manifest;uint8_t expected_run[32];manifest.add(compare_text,size);manifest.finish(expected_run);
 snprintf(pathname,sizeof pathname,"%s/run.json",directory);if(!digest_match(pathname,expected_run))return false;
 // Reject unexplained directory entries, including orphan disposition material.
 DIR dir={};FILINFO entry={};if(ffs_dopen(&dir,directory))return false;bool entries_ok=true;unsigned entries=0;
 while(entries_ok){if(ffs_dread(&dir,&entry)){entries_ok=false;break;}if(!entry.fname[0])break;
  if(++entries>128||(entry.fattrib&0x10)){entries_ok=false;break;}
  bool known=false;const char* extras[]={"bundle.json","run.json","plan.json","selection-script.txt","results.bin","files.lst"};
  for(auto name:extras)if(!strcmp(entry.fname,name))known=true;
  // Inventory was split into nul-terminated name/hash pairs above.
  char* cursor=file_list;while(cursor<file_list+n){
   char* hash=cursor+strlen(cursor)+1;if(!strcmp(cursor,entry.fname))known=true;cursor=hash+strlen(hash)+1;
  }
  if(!known)entries_ok=false;
 }
 bool dirclosed=ffs_dclose(&dir)==0;if(!entries_ok||!dirclosed)return false;
 snprintf(pathname,sizeof pathname,"%s/results.bin",directory);FIL f={};if(ffs_fopen(&f,pathname,FA_READ))return false;
 uint32_t total=0;bool ok=!ffs_fsize(&f,&total)&&total<=1048576UL&&inspected_bytes<=67108864UL-total;inspected_bytes+=ok?total:0;
 Records records(id,hashes,CASE_HASHES,selection.mask);uint8_t envelope[1069];
 while(ok&&records.bytes<total){
  if(total-records.bytes<40||ffs_fread(&f,reinterpret_cast<char*>(envelope),40)!=40){ok=false;break;}
  uint32_t payload=wire::get32(envelope+32);
  if(payload<2||payload>1024||total-records.bytes<45+payload||
     ffs_fread(&f,reinterpret_cast<char*>(envelope+40),payload+5)!=payload+5||
     (envelope[5]==1&&envelope[42]!=BACKEND)||!records.accept(envelope,payload+45)){ok=false;break;}
 }
 bool fileclosed=ffs_fclose(&f)==0;complete=ok&&fileclosed&&records.complete;seq=records.sequence;length=records.bytes;
 if(!memcmp(id,latest().b+24,16)){
  recovery_diagnostic[8]=records.failed_mask;wire::put32(recovery_diagnostic+4,records.current);
  if(memcmp(hashes+64,latest().b+56,32)||memcmp(script_hash,latest().b+88,32)||
     latest().sequence()>seq||latest().length()>length)ok=false;
 }
 return ok&&fileclosed;
}
inline bool gate(){
 memset(recovery_diagnostic,0,64);recovery_diagnostic[1]=255;inspected_bytes=0;
 if(!load()){diagnose(1);return false;}
 Slot& s=latest();
 // W03 states/receipts and parent-linked runs are deliberately unsupported.
 if(s.b[121]||!zero(s.b+40,16)||!zero(s.b+148,32)||s.phase()>=DISPOSING){diagnose(7);return false;}
 uint64_t count=u64(allocation+8);if(count>4096){diagnose(8);return false;}
 if(s.counter()!=count){diagnose(3);return false;}
 // Verify names/count once; deterministic paths below establish no missing counter.
 DIR d={};FILINFO e={};if(ffs_dopen(&d,"/mos-tests/runs")){diagnose(6);return false;}
 unsigned found=0;bool okay=true;
 while(okay){if(ffs_dread(&d,&e)){okay=false;break;}if(!e.fname[0])break;uint8_t id[16];
  if(++found>4096||!(e.fattrib&0x10)||!from_hex(e.fname,id,16)||memcmp(id,allocation,8)||!u64(id+8)||u64(id+8)>count)okay=false;
 }
 bool closed=ffs_dclose(&d)==0;if(!okay||!closed||found!=count){diagnose(3);return false;}
 // A receipts directory is not provisioned in W02. Any presence needs W03 support.
 DIR receipts={};uint8_t rs=ffs_dopen(&receipts,"/mos-tests/recovery");
 if(!rs){ffs_dclose(&receipts);diagnose(7);return false;}
 if(rs!=4&&rs!=5){diagnose(6);return false;}
 for(uint64_t i=1;i<=count;++i){uint8_t id[16];memcpy(id,allocation,8);put64(id+8,i);char text[33],directory[80];hex(id,16,text);snprintf(directory,sizeof directory,"/mos-tests/runs/%s",text);
  bool complete=false;uint32_t seq=0,length=0;
  if(!inspect_run(directory,id,complete,seq,length)){diagnose(4);return false;}
  if(!complete){diagnose(5);return false;}
  if(i==count&&(s.sequence()!=seq||s.length()!=length)){diagnose(5);return false;}
 }
 if((count==0&&s.phase()!=IDLE)||(count>0&&s.phase()!=COMPLETE)){diagnose(2);return false;}
 recovery_diagnostic[0]=0;return true;
}
inline bool same_boot(){
 if(!load())return false;
 Slot& s=latest();
 return s.phase()==BETWEEN&&!s.b[121]&&zero(s.b+40,16)&&zero(s.b+148,32)&&
 !memcmp(s.b+24,session.id,16)&&!memcmp(s.b+56,session.hashes+64,32)&&
 !memcmp(s.b+88,session.script,32)&&s.length()==session.length&&s.counter()==u64(allocation+8);
}
inline bool position(RecordedLifecycle& bridge,uint8_t phase,uint32_t key){
 uint32_t size=0;MosStorage* storage=static_cast<MosStorage*>(bridge.recorder.io.context);
 return !ffs_fsize(&storage->file,&size)&&publish(phase,key,bridge.recorder.confirmed,size);
}
inline bool case_start(void* data,const Case& c){
 auto& b=*static_cast<RecordedLifecycle*>(data);
 return position(b,CASE_INTENT,c.key)&&RecordedLifecycle::start(data,c)&&position(b,IN_CASE,c.key);
}
inline bool case_finish(void* data,const Case& c,const Result& result){
 return RecordedLifecycle::finish(data,c,result)&&position(*static_cast<RecordedLifecycle*>(data),CASE_DONE,c.key);
}
}

# 68 "src/main.cpp" 2
static bool allocation_intent(){return recovery_target::publish(recovery::ALLOCATING,0,0,0);}
static int command(int argc,char** argv){if(argc<2||!capture_available())return 19;
 Selection selection;uint8_t script_hash[32];if(!script_selection(selection,script_hash))return 20;
 bool begin=strcmp(argv[1],"begin")==0;
 if(begin){if(argc!=2)return 21;if(!recovery_target::gate())return 41;memset(&session,0,sizeof session);session.mask=selection.mask;memcpy(session.script,script_hash,32);if(!allocate()||!prepare_files())return 22;
  MosStorage disk;char file[128];path(file,"results.bin");if(disk.open(file))return 23;Recorder r(ram,disk.adapter(),session.id,session.hashes+32,session.hashes+64);wire::Payload p;
  if(!r.begin()||!p.run_start(BACKEND,selection.count,session.hashes)||!r.append(1,p)||!r.checkpoint())return 24;
  uint32_t length=0;if(ffs_fsize(&disk.file,&length)||MosStorage::close(&disk)){r.fail(3,1,r.next-1);return 25;}session.length=length;if(!recovery_target::publish(recovery::BETWEEN,0,r.confirmed,length))return 42;remember();
  uint8_t fault=0;size_t fault_size=0;if(!readfile("/mos-tests/fault.bin",&fault,1,fault_size)||fault_size!=1)return 38;
  // Explicit qualification-only artifact: change a comment after plan persistence.
  if(fault==3){FIL change={};if(ffs_fopen(&change,"/autoexec.txt",FA_WRITE)||ffs_flseek(&change,2))return 39;uint8_t error=0;bool ok=recording_write(&change,"X",1,&error)==1&&!error;ok=ffs_fsync(&change)==0&&ok;ok=ffs_fclose(&change)==0&&ok;if(!ok)return 40;}
  printf("STARTED: %u synthetic tests; results in %s\n",selection.count,session.directory);return 0;
 }
 if(!recall()||session.mask!=selection.mask||memcmp(session.script,script_hash,32))return 26;
 if(!recovery_target::same_boot()){recovery_target::diagnose(9);return 43;}
 bool final=strcmp(argv[1],"finalize")==0;unsigned index=3;
 if(final){if(argc!=2||session.index!=selection.count)return 27;}
 else {if(argc!=3||strcmp(argv[1],"function"))return 28;for(unsigned i=0;i<3;++i)if(!strcmp(argv[2],FUNCTIONS[i]))index=i;if(session.index>=selection.count||index!=selection.order[session.index])return 29;}
 MosStorage disk;Recorder r(ram,disk.adapter(),session.id,session.hashes+32,session.hashes+64);if(!restore_ready(r))return 30;char file[128];path(file,"results.bin");
 if(ffs_fopen(&disk.file,file,FA_WRITE))return 31;disk.opened=true;uint32_t length=0;if(ffs_fsize(&disk.file,&length)||length!=session.length||ffs_flseek(&disk.file,length)){r.fail(5,6,r.next);return 32;}
 if(final){if(!recovery_target::publish(recovery::FINALIZING,0,r.confirmed,session.length))return 42;wire::Payload p;p.run_end(session.counts,session.hashes+64);if(!r.finish_run(p))return 33;FILINFO info={};if(ffs_stat(&info,file)||!recovery_target::publish(recovery::COMPLETE,0,r.confirmed,info.fsize))return 42;memset(session.magic,0,4);for(unsigned i=0;i<4;++i)ram[0xa00+i]=0;printf("COMPLETE: %lu passed, %lu failed, %lu unsupported. Decode saved evidence for the final report.\n",(unsigned long)session.counts[0],(unsigned long)session.counts[1],(unsigned long)session.counts[4]);return 0;}
 uint8_t fault=0;size_t size=0;if(!readfile("/mos-tests/fault.bin",&fault,1,size)||size!=1)return 34;
 if(fault==2){r.fail(5,7,r.next);return 35;}
 Context context{nullptr,fault};RecordedLifecycle bridge(r,&context,metadata,execute,cleanup);context.bridge=&bridge;const Case* chosen[]={&CASES[index]};auto hooks=bridge.hooks();hooks.start=recovery_target::case_start;hooks.finish=recovery_target::case_finish;auto totals=run(chosen,1,1,hooks);if(!totals.complete)return 36;
 for(unsigned i=0;i<8;++i)session.counts[i]+=totals.counts[i];++session.index;
 if(ffs_fsize(&disk.file,&length)||MosStorage::close(&disk)){r.fail(3,1,r.next-1);return 37;}session.length=length;if(!recovery_target::publish(recovery::BETWEEN,0,r.confirmed,length))return 42;remember();
 const char* outcome=totals.counts[0]?"PASSED":totals.counts[1]?"FAILED":"UNSUPPORTED";
 printf("%s: %s - %s\n",outcome,CASES[index].id,totals.counts[0]?(index==1?"changed only the expected IX upper bit in both samples":"preserved primary registers in both samples"):totals.counts[1]?"recorded a synthetic discrepancy; continuing selected groups":"required UART fixture is unavailable");return 0;
}
int main(int argc,char** argv){int result=command(argc,argv);startup_status=result;if(result)printf("ERROR: startup runner stopped with status %d; incomplete evidence is not a pass.\n",result);startup_command_done();return result;}
