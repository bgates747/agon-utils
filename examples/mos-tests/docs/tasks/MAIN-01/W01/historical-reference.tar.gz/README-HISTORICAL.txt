HISTORICAL EVIDENCE ONLY. Not current API guidance. Check target version and upstream contracts first. Do not extract into maintained directories.
