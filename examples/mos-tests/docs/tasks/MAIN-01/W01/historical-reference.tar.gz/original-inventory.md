# MOS API inventory — MOS 3.0.2 Arthur

## Summary

This is the W01 inventory of the pinned public MOS interface, not a coverage
or execution report. It includes named RST 08 selectors, unsupported slots,
RST services, and the C-function lookup surface. Contracts below are attributed
to pinned documentation; source findings are separately labelled. W02 will
turn these entries into cases and observations. No firmware changes are made.

## Baseline and scope

1. MOS source: `v3.0.2`, commit `8336409351ee5314e02801a7b72a4f1bb5282519`; read-only `/home/smith/Agon/agon-mos`.
2. Documentation: commit `f9806bd3cbff6ed5d1c08bef1d51fed11764b86b` in read-only `/home/smith/Agon/agon-docs`. This is a separately pinned living documentation revision, not assumed release-matched.
3. Binary SHA-256: `d564243283972690933a4554296ad6202ca4ef54572279533a942960846bebae`.
   Map SHA-256: `d69e60bbce61a7b4b3eef318ba395f11c4e1a5b585755755113992dc94edcb86`.
   These match SETUP-01. A matching release identity is not a byte-identical local rebuild claim.
4. Scope includes MOS entry points and the data layouts they expose. VDP wire
   protocols, shell-command grammar, BBC BASIC language semantics and AgonDev
   library helpers are dependencies, not extra MOS selectors. `mos_oscli` remains
   in scope as an API; testing every shell command is a separate expansion.
5. ADL with MB=0 is the initial execution baseline. Classic Z80/MB pointer
   promotion is part of the documented interface and is retained for later
   coverage decisions, not silently declared tested. C-function lookup is ADL-only.
6. Source/document snapshots, hashes and a machine-readable register are in
   [W01](tasks/MAIN-01/W01/README.md). Upstream repositories were not changed.

## Entry and ABI rules

1. Documentation and MOSCALL specify `LD A, selector; RST.LIS 08h`. Do not infer
   general compatibility from the RST.LIL output smoke check. Keep call mode and
   MB value explicit in each future fixture.
2. `HL(U)` denotes a pointer whose high byte may be supplied by MB in classic
   mode. ADL callers supply a complete 24-bit pointer with MB=0. Per-function
   conversion matters, especially FIL pointers returned from MOS-managed memory.
3. Only listed outputs/preservation are contract assertions. Unspecified flags
   and registers are observations, not promises. Stack restoration is distinct
   from values legitimately returned in registers. Interrupt/callback lifetimes
   and blocking calls require separate fixture handling in W02/W03.
4. Status is usually A=0 on success, but not universally: character reads,
   predicates, pattern ordering, I2C and raw SD have different result domains.
   FatFS status codes 0–19 are followed by MOS codes 20–26. The pinned status
   table is retained below. No promise that each call can produce every code.
5. Modern 32-bit values use valid four-byte storage passed by pointer. Legacy
   seek APIs use split registers. C-call arguments are right-to-left, padded to
   multiples of three bytes, and removed by the caller; byte returns use A,
   integer/pointer returns HL. Verify exact prototypes before an AgonDev call.

## RST services

| Entry | Inputs / result | Scope |
| --- | --- | --- |
| 00 | Reset eZ80; no ordinary return contract | Destructive control service; isolated future case |
| 08 | A selects API; other registers below | Dispatcher and all 256 selector values accounted for |
| 10 | A byte to VDP transport | Entry-byte observation differs from rendered output |
| 18 | HL stream; BC 16-bit length, or zero with A delimiter; E receives entry A; HL advances | Two modes; source tests B/C, not BCU; MOS 1.03+ |
| 38 | Crash report; processor/stack state consumed | MOS 2.3+; isolated crash-path observation |
| 20/28/30 | Source contains bare RET | Not advertised public services; excluded from functional inventory |

RST 18 documented A-on-return in length mode conflicts with the source's final
`LD A,B; OR C` (zero at completion). Preserve this as a contract discrepancy.

## Source findings and unresolved contracts

1. LOAD/SAVE comments claim carry-clear for no room, but wrappers execute SCF
   unconditionally. Use returned status for the documented error domain; retain
   carry as a discrepancy, not an inferred success flag.
2. getfunction documentation's final paragraph says out-of-range returns 20;
   source returns 19. Nonzero flags also return 19; MB nonzero returns 20.
   Slots 03/04 return success with NULL. Never call those NULL pointers.
3. ffs_setlabel calls f_setlabel, then falls through to ffs_setcp's unsupported
   handler (A=HL=23). This is a source-observed defect candidate, not a new
   runtime-confirmed bug or authorization to fix firmware.
4. ffs_feof source comment names FILINFO; the helper consumes FIL. Treat FIL
   as the required object; do not allocate FILINFO based on that comment.
5. C-function SD_readBlocks prose calls count bytes; source advances a sector
   and a 512-byte buffer per count. Count is blocks. Raw access must use a
   disposable image, separate from active filesystem tests.
6. The general documentation says old MOS versions "do support" unknown-call
   detection while immediately warning of unexpected results. Do not extrapolate
   this pinned release's A=23 behavior to old firmware from that sentence.
7. Named symbols do not imply implementation. Stub entries below return
   A=HL=23 through the pinned unsupported handler. Version claims in the
   documentation are retained as claims, not verified historical release tests.
8. Structure layouts, buffer lifetimes, callback constraints and unspecified
   register effects must remain explicit in case design. Source inspection is
   not exhaustive path verification; resolve any remaining ambiguity before
   selecting an assertion. MOS-01 is parked; !boot.obey stays populated.

## Named RST 08 inventory

100 named selectors; 10 are stubs in this source.

| Selector | Name | Source disposition | Contract |
| --- | --- | --- | --- |
| 00 | `mos_getkey` | implemented | [details](#api-00) |
| 01 | `mos_load` | implemented | [details](#api-01) |
| 02 | `mos_save` | implemented | [details](#api-02) |
| 03 | `mos_cd` | implemented | [details](#api-03) |
| 04 | `mos_dir` | implemented | [details](#api-04) |
| 05 | `mos_del` | implemented | [details](#api-05) |
| 06 | `mos_ren` | implemented | [details](#api-06) |
| 07 | `mos_mkdir` | implemented | [details](#api-07) |
| 08 | `mos_sysvars` | implemented | [details](#api-08) |
| 09 | `mos_editline` | implemented | [details](#api-09) |
| 0A | `mos_fopen` | implemented | [details](#api-0a) |
| 0B | `mos_fclose` | implemented | [details](#api-0b) |
| 0C | `mos_fgetc` | implemented | [details](#api-0c) |
| 0D | `mos_fputc` | implemented | [details](#api-0d) |
| 0E | `mos_feof` | implemented | [details](#api-0e) |
| 0F | `mos_getError` | implemented | [details](#api-0f) |
| 10 | `mos_oscli` | implemented | [details](#api-10) |
| 11 | `mos_copy` | implemented | [details](#api-11) |
| 12 | `mos_getrtc` | implemented | [details](#api-12) |
| 13 | `mos_setrtc` | implemented | [details](#api-13) |
| 14 | `mos_setintvector` | implemented | [details](#api-14) |
| 15 | `mos_uopen` | implemented | [details](#api-15) |
| 16 | `mos_uclose` | implemented | [details](#api-16) |
| 17 | `mos_ugetc` | implemented | [details](#api-17) |
| 18 | `mos_uputc` | implemented | [details](#api-18) |
| 19 | `mos_getfil` | implemented | [details](#api-19) |
| 1A | `mos_fread` | implemented | [details](#api-1a) |
| 1B | `mos_fwrite` | implemented | [details](#api-1b) |
| 1C | `mos_flseek` | implemented | [details](#api-1c) |
| 1D | `mos_setkbvector` | implemented | [details](#api-1d) |
| 1E | `mos_getkbmap` | implemented | [details](#api-1e) |
| 1F | `mos_i2c_open` | implemented | [details](#api-1f) |
| 20 | `mos_i2c_close` | implemented | [details](#api-20) |
| 21 | `mos_i2c_write` | implemented | [details](#api-21) |
| 22 | `mos_i2c_read` | implemented | [details](#api-22) |
| 23 | `mos_unpackrtc` | implemented | [details](#api-23) |
| 24 | `mos_flseek_p` | implemented | [details](#api-24) |
| 28 | `mos_pmatch` | implemented | [details](#api-28) |
| 29 | `mos_getargument` | implemented | [details](#api-29) |
| 2A | `mos_extractstring` | implemented | [details](#api-2a) |
| 2B | `mos_extractnumber` | implemented | [details](#api-2b) |
| 2C | `mos_escapestring` | implemented | [details](#api-2c) |
| 30 | `mos_setvarval` | implemented | [details](#api-30) |
| 31 | `mos_readvarval` | implemented | [details](#api-31) |
| 32 | `mos_gsinit` | implemented | [details](#api-32) |
| 33 | `mos_gsread` | implemented | [details](#api-33) |
| 34 | `mos_gstrans` | implemented | [details](#api-34) |
| 35 | `mos_substituteargs` | implemented | [details](#api-35) |
| 36 | `mos_evaluateexpression` | stub | [details](#api-36) |
| 38 | `mos_resolvepath` | implemented | [details](#api-38) |
| 39 | `mos_getdirforpath` | implemented | [details](#api-39) |
| 3A | `mos_getleafname` | implemented | [details](#api-3a) |
| 3B | `mos_isdirectory` | implemented | [details](#api-3b) |
| 3C | `mos_getabsolutepath` | implemented | [details](#api-3c) |
| 40 | `mos_clearvdpflags` | implemented | [details](#api-40) |
| 41 | `mos_waitforvdpflags` | implemented | [details](#api-41) |
| 50 | `mos_getfunction` | implemented | [details](#api-50) |
| 70 | `sd_getunlockcode` | implemented | [details](#api-70) |
| 71 | `sd_init` | implemented | [details](#api-71) |
| 72 | `sd_readblocks` | implemented | [details](#api-72) |
| 73 | `sd_writeblocks` | implemented | [details](#api-73) |
| 80 | `ffs_fopen` | implemented | [details](#api-80) |
| 81 | `ffs_fclose` | implemented | [details](#api-81) |
| 82 | `ffs_fread` | implemented | [details](#api-82) |
| 83 | `ffs_fwrite` | implemented | [details](#api-83) |
| 84 | `ffs_flseek` | implemented | [details](#api-84) |
| 85 | `ffs_ftruncate` | implemented | [details](#api-85) |
| 86 | `ffs_fsync` | implemented | [details](#api-86) |
| 87 | `ffs_fforward` | stub | [details](#api-87) |
| 88 | `ffs_fexpand` | stub | [details](#api-88) |
| 89 | `ffs_fgets` | implemented | [details](#api-89) |
| 8A | `ffs_fputc` | implemented | [details](#api-8a) |
| 8B | `ffs_fputs` | implemented | [details](#api-8b) |
| 8C | `ffs_fprintf` | stub | [details](#api-8c) |
| 8D | `ffs_ftell` | implemented | [details](#api-8d) |
| 8E | `ffs_feof` | implemented | [details](#api-8e) |
| 8F | `ffs_fsize` | implemented | [details](#api-8f) |
| 90 | `ffs_ferror` | implemented | [details](#api-90) |
| 91 | `ffs_dopen` | implemented | [details](#api-91) |
| 92 | `ffs_dclose` | implemented | [details](#api-92) |
| 93 | `ffs_dread` | implemented | [details](#api-93) |
| 94 | `ffs_dfindfirst` | implemented | [details](#api-94) |
| 95 | `ffs_dfindnext` | implemented | [details](#api-95) |
| 96 | `ffs_stat` | implemented | [details](#api-96) |
| 97 | `ffs_unlink` | implemented | [details](#api-97) |
| 98 | `ffs_rename` | implemented | [details](#api-98) |
| 99 | `ffs_chmod` | stub | [details](#api-99) |
| 9A | `ffs_utime` | stub | [details](#api-9a) |
| 9B | `ffs_mkdir` | implemented | [details](#api-9b) |
| 9C | `ffs_chdir` | implemented | [details](#api-9c) |
| 9D | `ffs_chdrive` | stub | [details](#api-9d) |
| 9E | `ffs_getcwd` | implemented | [details](#api-9e) |
| 9F | `ffs_mount` | implemented | [details](#api-9f) |
| A0 | `ffs_mkfs` | stub | [details](#api-a0) |
| A1 | `ffs_fdisk` | stub | [details](#api-a1) |
| A2 | `ffs_getfree` | implemented | [details](#api-a2) |
| A3 | `ffs_getlabel` | implemented | [details](#api-a3) |
| A4 | `ffs_setlabel` | implemented | [details](#api-a4) |
| A5 | `ffs_setcp` | stub | [details](#api-a5) |
| A6 | `ffs_flseek_p` | implemented | [details](#api-a6) |

All unnamed selectors (156) dispatch to the unsupported handler, either via explicit table slots or the range check above A6. The JSON register preserves all 00–A6 table entries; A7–FF are out of range. These are dispatcher cases, not invented function names.

## Per-selector contracts

The following contract text is extracted from the pinned project documentation,
with examples omitted. It preserves inputs, returns, register preservation,
flags, modes, buffer requirements, version notes and documented side effects.
It is documentation evidence, subject to the source findings above. A missing
restriction or preservation statement means unspecified, not unrestricted.

<a id="api-00"></a>

### 00 — mos_getkey

Source: [mos_api_getkey](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L356); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L164).

Read a keypress from the VDP

Parameters: None

Returns:

- `A`: The keycode of the character pressed

NB: This is a blocking function. This routine will wait and only return once a key is pressed.

<a id="api-01"></a>

### 01 — mos_load

Source: [mos_api_load](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L376); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L176).

Load a file from SD card

Parameters:

- `HL(U)`: Address of filename (zero terminated)
- `DE(U)`: Address at which to load
- `BC(U)`: Maximum allowed size (bytes)

Preserves: `HL(U)`, `DE(U)`, `BC(U)`

Returns:

- `A`: Status code
- `F`: Carry reset if no room for file, otherwise set

<a id="api-02"></a>

### 02 — mos_save

Source: [mos_api_save](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L406); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L193).

Save a file to SD card

Parameters:

- `HL(U)`: Address of filename (zero terminated)
- `DE(U)`: Address to save from
- `BC(U)`: Number of bytes to save

Preserves: `HL(U)`, `DE(U)`, `BC(U)`

Returns:

- `A`: Status code
- `F`: Carry set

<a id="api-03"></a>

### 03 — mos_cd

Source: [mos_api_cd](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L433); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L210).

Change current directory on the SD card

Parameters:

- `HL(U)`: Address of directory path (zero terminated)

Preserves: `HL(U)`

Returns:

- `A`: Status code

<a id="api-04"></a>

### 04 — mos_dir

Source: [mos_api_dir](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L453); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L224).

List SD card folder contents to screen.

This is a simple directory listing command that will list the contents of the current directory to the screen.  More advanced directory listing functionality for applications to use is available via the [FatFS commands API](https://agonplatform.github.io/agon-docs/mos/API/#fatfs-commands).

Parameters:

- `HL(U)`: Address of directory path (zero terminated)

Preserves: `HL(U)`

Returns:

- `A`: Status code

<a id="api-05"></a>

### 05 — mos_del

Source: [mos_api_del](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L473); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L240).

Delete a file or folder from the SD card

Parameters:

- `HL(U)`: Address of filepath (zero terminated)

Preserves: `HL(U)`

Returns:

- `A`: Status code

<a id="api-06"></a>

### 06 — mos_ren

Source: [mos_api_ren](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L494); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L254).

Rename a file on the SD card

Parameters:

- `HL(U)`: Address of source filepath string (zero terminated)
- `DE(U)`: Address of destination filepath string (zero terminated)

Preserves: `HL(U)`, `DE(U)`

Returns:

- `A`: Status code

As of MOS 3.0 the `mos_ren` API can support the use of wildcards in the source filepath leaf name.  This allows you to rename multiple files at once.  The destination filepath must point to a directory in this case.  Destination paths cannot include wildcards.

<a id="api-07"></a>

### 07 — mos_mkdir

Source: [mos_api_mkdir](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L543); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L271).

Make a folder on the SD card

Parameters:

- `HL(U)`: Address of path (zero terminated)

Preserves: `HL(U)`

Returns:

- `A`: Status code

<a id="api-08"></a>

### 08 — mos_sysvars

Source: [mos_api_sysvars](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L562); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L285).

Fetch a pointer to the [system state variables](https://agonplatform.github.io/agon-docs/mos/API/#sysvars)

NB as this returns a pointer in `IXU`, and is therefore difficult to use from C code, as of MOS 3.0 an alternative way to access the sysvars address is available via a C function obtainable from the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Parameters: None

Returns:

- `IXU`: Pointer to the MOS SysVars area (this is always 24 bit)

<a id="api-09"></a>

### 09 — mos_editline

Source: [mos_api_editline](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L572); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L297).

Invoke the line editor

Parameters:

- `HL(U)`: Address of the buffer
- `BC(U)`: Buffer length
- `E`: Flags to control editor behaviour

Preserves: `HL(U)`, `BC(U)`, `DE(U)`

Returns:

- `A`: Key that was used to exit the input loop (CR=13, ESC=27)

Editor behaviour flags are as follows:

| Bit | Description |
| --- | ----------- |
| 0   | When set, buffer will be cleared before use |
| 1   | When set, tab-completion for MOS commands and files is enabled * |
| 2   | When set, hotkeys are _disabled_ * |
| 3   | When set, input history will be _disabled_ * |
| 4-7 | Reserved for future use (for future compatibility, ensure these are set to zero) |

\* Support for editor control flags was added in MOS 2.2.0.  Prior to this the only documented values for `E` were 0 and 1 to indicate whether the buffer should be cleared.

<a id="api-0a"></a>

### 0A — mos_fopen

Source: [mos_api_fopen](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L596); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L325).

Get a file handle

Parameters:

- `HL(U)`: Address of filename (zero terminated)
- `C`: File open mode

Preserves: `HL(U)`, `BC(U)`, `DE(U)`, `IX(U)`, `IY(U)`

Returns:

- `A`: File handle, or 0 if couldn't open

Please note that whilst this API has always been documented as requiring a zero-terminated string for the filename, this was not actually _strictly_ true.  It actually interpreted any control character (0-31) as a termination character.  MOS 3.0.0 changed this behaviour to be a strict zero-terminated string, but it was found that several keywords in BBC BASIC (`OPENIN`, `OPENOUT` and `OPENUP`) were failing to work because they were sending a carriage-return (13) as their termination character.  MOS 3.0.1 has been changed to support control-character termination again, thus fixing compatibility with BBC BASIC.  You are, however, strongly advised to use zero-terminated strings in your code, as relying on control character termination can cause other issues.

#### File open modes

The mode is a number that indicates rules as to how the file will be opened.  Several different modes are available, and these values can be combined using a bitwise OR operation.  The values supported are inherited from FatFS, and are as follows:

| Mode | FatFS constant | Description |
| ---- | -------------- | ----------- |
| 0x01 | `FA_READ`	| Open file for reading |
| 0x02 | `FA_WRITE`	| Open file for writing.  Combine with `FA_READ` for read/write access |
| 0x00 | `FA_OPEN_EXISTING`	| Open file if it exists, fail if it doesn't |
| 0x04 | `FA_CREATE_NEW`	| Create a new file, fail if it already exists |
| 0x08 | `FA_CREATE_ALWAYS`	| Create a new file.  If the file already exists it will be truncated and overwritten |
| 0x10 | `FA_OPEN_ALWAYS`	| Open file if it exists, create it if it doesn't |
| 0x30 | `FA_OPEN_APPEND`	| Same as `FA_OPEN_ALWAYS`, except the read/write pointer will be set to the end of the file |

You may note that the "open existing" mode has a value of zero.  Setting either, or both, of the "create" options will override this.

NB: If you open the file using `mos_fopen`, you must close it using `mos_fclose`, not `ffs_api_fclose`

<a id="api-0b"></a>

### 0B — mos_fclose

Source: [mos_api_fclose](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L631); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L360).

Close a file handle

Parameters:

- `C`: File handle, or 0 to close all open files

Preserves: `HL(U)`, `BC(U)`, `DE(U)`, `IX(U)`, `IY(U)`

Returns:

- `A`: Number of files still open

<a id="api-0c"></a>

### 0C — mos_fgetc

Source: [mos_api_fgetc](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L658); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L374).

Get a character from an open file

Parameters:

- `C`: File handle

Preserves: `HL(U)`, `BC(U)`, `DE(U)`, `IX(U)`, `IY(U)`

Returns:

- `A`: Character read
- `F`: C set if last character in file, otherwise NC (MOS 1.04 or greater)

<a id="api-0d"></a>

### 0D — mos_fputc

Source: [mos_api_fputc](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L683); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L389).

Write a character to an open file

Parameters:

- `C`: File handle
- `B`: Character to write

Preserves: `HL(U)`, `BC(U)`, `DE(U)`, `IX(U)`, `IY(U)`

Returns:

None

<a id="api-0e"></a>

### 0E — mos_feof

Source: [mos_api_feof](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L712); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L404).

Check for end of file

Parameters:

- `C`: File handle

Preserves: `HL(U)`, `BC(U)`, `DE(U)`, `IX(U)`, `IY(U)`

Returns:

- `A`: 1 if at end of file, otherwise 0

<a id="api-0f"></a>

### 0F — mos_getError

Source: [mos_api_getError](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L736); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L418).

Translates a status code into a human-readable message.

Parameters:

- `E`: The status code
- `HL(U)`: Address of buffer to copy message into
- `BC(U)`: Size of buffer

Preserves: `DE(U)`, `HL(U)`, `BC(U)`

Returns:

None

<a id="api-10"></a>

### 10 — mos_oscli

Source: [mos_api_oscli](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L758); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L434).

Execute a MOS command

Parameters:

- `HL(U)`: Pointer the the MOS command string

Preserves: `HL(U)`

Returns:

- `A`: Status code

NB previously documentation for this command was incorrect, as it documented additional parameters in `DE(U)` and `BC(U)`.  These registers are not currently used.

<a id="api-11"></a>

### 11 — mos_copy

Source: [mos_api_copy](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L519); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L450).

Copy a file on the SD card

Parameters:

- `HL(U)`: Address of source filepath string (zero terminated)
- `DE(U)`: Address of destination filepath string (zero terminated)

Preserves: `HL(U)`, `BC(U)`, `DE(U)`, `IX(U)`, `IY(U)`

Returns:

- `A`: Status code

NB: Requires MOS 1.03 or greater

Please note that this API only supports copying files; it does not support copying directories.

As of MOS 3.0, the `mos_copy` API supports the use of wildcards in the source filepath leaf name.  This allows you to copy multiple files at once.  The destination filepath must point to a directory in this case.  Destination paths cannot include wildcards.

<a id="api-12"></a>

### 12 — mos_getrtc

Source: [mos_api_getrtc](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L775); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L471).

Get a time string from the RTC (Requires MOS 1.03 or above)

Parameters:

- `HL(U)`: Pointer to a buffer to copy the string to (at least 32 bytes)

Preserves: `HL(U)`

Returns:

- `A`: Length of time string

<a id="api-13"></a>

### 13 — mos_setrtc

Source: [mos_api_setrtc](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L803); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L485).

Set the RTC (Requires MOS 1.03 or above)

Parameters:

- `HL(U)`: Pointer to a 6-byte buffer with the time data in



Preserves: `HL(U)`

Returns:

None

<a id="api-14"></a>

### 14 — mos_setintvector

Source: [mos_api_setintvector](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L820); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L508).

Set an interrupt vector (Requires MOS 1.03 or above)

Parameters:

- `E`: Interrupt vector number to set
- `HLU`: Address of new interrupt vector (24-bit pointer)

Preserves: `HLU`, `DEU`

Returns:

- `HL(U)`: Address of the previous interrupt vector (24-bit pointer)

<a id="api-15"></a>

### 15 — mos_uopen

Source: [mos_api_uopen](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L962); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L523).

Open UART1 (Requires MOS 1.03 or above)

To handle the received interrupts, you will need to assign a handler to UART1's interrupt vector (0x1A).

NB as this API uses a pointer in `IX(U)`, and is therefore difficult to use from C code, as of MOS 3.0 th underlying function this API uses is available via a C function accessible using the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Parameters:

- `IX(U)`: Pointer to a UART struct



Preserves: `HL(U)`

Returns:

- `A`: Error code (always 0)

Please note that before MOS 3.0 the return value from this API was not always `0` owing to a bug in how the return value was handled.  This has been fixed in MOS 3.0 and later.

<a id="api-16"></a>

### 16 — mos_uclose

Source: [mos_api_uclose](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L973); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L557).

Close UART1 (Requires MOS 1.03 or above)

<a id="api-17"></a>

### 17 — mos_ugetc

Source: [mos_api_ugetc](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#LNone); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L561).

Read a character from UART1 (Requires MOS 1.03 or above)

Returns:

- `A`: The character read
- `F`: C if successful, NC if the UART is closed

NB: If UART1 is open, this is a blocking function which means this routine will wait and only return once a character is received.

<a id="api-18"></a>

### 18 — mos_uputc

Source: [mos_api_uputc](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L989); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L572).

Write a character to UART1 (Requires MOS 1.03 or above)

Parameters:

- `C`: The character to write

Returns:

- `F`: C if successful, NC if the UART is closed

<a id="api-19"></a>

### 19 — mos_getfil

Source: [mos_api_getfil](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L997); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L584).

Get a pointer to a `FIL` structure in MOS (Requires MOS 1.03 or above)

This call is useful if you wish to use the FatFS API directly, but need to pass a `FIL` structure to a FatFS API call.

Parameters:

- `C`: File handle

Preserves: `BC(U)`

Returns:

- `HLU`: 24-bit pointer to a `FIL` structure (in MOS RAM)

<a id="api-1a"></a>

### 1A — mos_fread

Source: [mos_api_fread](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1009); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L600).

Read a block of data from a file (Requires MOS 1.03 or above)

Parameters:

- `C`: File handle
- `HLU`: Pointer to a buffer to read the data into
- `DEU`: Number of bytes to read

Preserves: `HL(U)`, `BC(U)`

Returns:

- `DEU`: Number of bytes read

<a id="api-1b"></a>

### 1B — mos_fwrite

Source: [mos_api_fwrite](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1030); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L616).

Write a block of data to a file (Requires MOS 1.03 or above)

Parameters:

- `C`: File handle
- `HLU`: Pointer to a buffer that contains the data to write
- `DEU`: Number of bytes to write out

Preserves: `HL(U)`, `BC(U)`

Returns:

- `DEU`: Number of bytes written

<a id="api-1c"></a>

### 1C — mos_flseek

Source: [mos_api_flseek](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1051); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L632).

Move the read/write pointer in a file (Requires MOS 1.03 or above)

NB this API is deprecated and kept for compatibility reasons.  You are advised to use the [`mos_flseek_p`](https://agonplatform.github.io/agon-docs/mos/API/#0x24-mos_flseek_p) API instead.  As this API requires a full 24-bit value to be provided in the `HLU` register it is not directly compatible with programs written to run in Z80 mode.

This API can be used to expand the size of a file, although you should note that the file data in the expanded part will be undefined.

Please note that on MOS releases prior to MOS 3.0, the status code returned in the `A` register will be incorrect.

Parameters:

- `C`: File handle
- `HLU`: Least significant 3 bytes of the offset from the start of the file
- `E`: Most significant byte of the offset (set to 0 for files < 16MB)

Preserves: `HL(U)`, `BC(U)`, `DE(U)`

Returns:

- `A`: Status code

<a id="api-1d"></a>

### 1D — mos_setkbvector

Source: [mos_api_setkbvector](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L834); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L654).

Allows user programs to access VDP keyboard packets without overriding the entire uart0 interrupt handler.
The user program registered, will be called during the uart0 interrupt handler, being passed the address of the full VDP keyboard packet.

Parameters:

- `C`: Address length in HL (0 = 24bit, 1 = 16bit). If 1 then set the top byte of HLU (callback address) to MB (for ADL=0 callers)
- `HL(U)`: Callback address of user program to register, or 0 to clear any previously registered vector

Returns: Nothing upon registration. The user program can expect the full VDP packet address in DE(24-bit) upon entry.

Be sure to clear the kbvector before your program exits (call mos_setkbvector again with HL=0).

[example code](https://github.com/tomm/toms-agon-experiments/blob/main/custom_kbvector_demo/custom_kbvector_demo.asm) that registers a custom handler.

<a id="api-1e"></a>

### 1E — mos_getkbmap

Source: [mos_api_getkbmap](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L851); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L670).

Fetch a pointer to the virtual keyboard map (Requires MOS 1.04 RC2 or above)

NB as this returns a pointer in IXU, and is therefore difficult to use from C code, as of MOS 3.0 an alternative way to access the keyboard bitmap address is available via a C function obtainable from the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Parameters: None

Returns:

- `IXU`: Pointer to the keyboard bitmap (this is always 24 bit)

<a id="api-1f"></a>

### 1F — mos_i2c_open

Source: [mos_api_i2c_open](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L857); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L682).

Open the I2C bus as Master (Requires MOS 1.04 RC3 or above)

Parameters:

- `C`: Frequency ID (1: 57600, 2: 115200, 3: 230400)

Preserves: `HL(U)`, `BC(U)`, `DE(U)`, `IX(U)`, `IY(U)`

Returns: None

<a id="api-20"></a>

### 20 — mos_i2c_close

Source: [mos_api_i2c_close](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L878); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L694).

Close the I2C bus (Requires MOS 1.04 RC3 or above)

Parameters: None

Preserves: `HL(U)`, `BC(U)`, `DE(U)`, `IX(U)`, `IY(U)`

Returns: None

<a id="api-21"></a>

### 21 — mos_i2c_write

Source: [mos_api_i2c_write](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L898); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L704).

Write a block of bytes to the I2C bus (Requires MOS 1.04 RC3 or above)

Parameters:

- `C`: I2C Address
- `B`: Number of bytes to write (maximum 32)
- `HL(U)`: Pointer to a buffer to read the bytes from

Preserves: `HL(U)`, `DE(U)`, `IX(U)`, `IY(U)`

Returns:

- `A`: Status
	- `0`: OK
	- `1`: No response from I2C slave
	- `2`: Data NACK
	- `4`: Bus arbitration lost
	- `8`: Bus error

<a id="api-22"></a>

### 22 — mos_i2c_read

Source: [mos_api_i2c_read](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L927); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L725).

Read a block of bytes from the I2C bus (Requires MOS 1.04 RC3 or above)

Parameters:

- `C`: I2C Address
- `B`: Number of bytes to read (maximum 32)
- `HL(U)`: Pointer to a buffer to write the bytes to

Preserves: `HL(U)`, `DE(U)`, `IX(U)`, `IY(U)`

Returns:

- `A`: Status
	- `0`: OK
	- `1`: No response from I2C slave
	- `2`: Data NACK
	- `4`: Bus arbitration lost
	- `8`: Bus error

<a id="api-23"></a>

### 23 — mos_unpackrtc

Source: [mos_api_unpackrtc](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L790); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L746).

Unpack the RTC (Real-Time Clock) data into a buffer (Requires MOS 3.0 or above)

Parameters:

- `HL(U)`: Pointer to a buffer to copy the RTC data to
- `C`: Flags

The buffer should be at least 10 bytes long.

Flags are a bit-field to enable various different options.  Currently the following bits are supported:

- bit 0 = refresh RTC sysvar before unpacking
- bit 1 = refresh RTC sysvar after unpacking

The RTC data sysvar is updated by sending a command to the VDP to request the current time, and MOS will store the response in the [RTC system state information area](https://agonplatform.github.io/agon-docs/mos/API/#sysvar_rtc).  If you set bit 0, this API call will send the command to the VDP to request updated RTC data and wait for the response before unpacking the data.  When you set bit 1, the command will be sent after the data has been unpacked, and the API will return without waiting for the response.

If you do not want to refresh the RTC data stored in MOS, set the flags to 0.  You should note that if you do this the data may be stale or, if no request has been sent to the VDP at all for RTC information, be invalid.

NB you should not set either refresh flag if you are in the middle of sending a command to the VDP, as that will both cause the update command to not be understood by the VDP, and will cause your command to fail or produce unexpected results.

Preserves: `HL(U)`, `BC(U)`

Returns:

Data returned in the buffer at `HL(U)` will be in the following order, with 16-bit values stored in little-endian order:

<a id="api-24"></a>

### 24 — mos_flseek_p

Source: [mos_api_flseek_p](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1066); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L785).

Move the read/write offset pointer in a file (Requires MOS 3.0 or above)

This API can be used to expand the size of a file, although you should note that the file data in the expanded part will be undefined.

Whilst the [`mos_flseek`](https://agonplatform.github.io/agon-docs/mos/API/#0x1c-mos_flseek) API can essentially perform the same function as this API, this is the preferred API to use for moving the current read/write pointer offset within a file.  As it accepts a pointer to the 32-bit offset value, it is compatible with both Z80-mode and ADL-mode code.

Parameters:

- `C`: File handle
- `HL(U)`: Pointer to a 32-bit value for the desired new offset from the start of the file

Preserves: `HL(U)`, `BC(U)`

Returns:

- `A`: Status code

<a id="api-28"></a>

### 28 — mos_pmatch

Source: [mos_api_pmatch](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1084); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L812).

Pattern matching function, with support for various flags to control how the comparison is made.

This exposes the pattern matching function that MOS 3.0 uses internally for matching commands and filenames.

Parameters:

- `HL(U)`: Address of pattern (zero terminated)
- `DE(U)`: Address at string to compare against pattern (zero terminated)
- `C`: Flags

The flags are a bit-field to enable various different pattern matching options

| Bit | Description |
| --- | ----------- |
| 0   | Case insensitive |
| 1   | Disable star (`*`) wildcard matching |
| 2   | Disable hash (`#`) wildcard matching |
| 3   | "Dot as star" mode (treats `.` at the end of pattern as a star, used in MOS for matching abbreviated commands) |
| 4   | "Begins with" mode (only matches if the string starts with the pattern) |
| 5   | "Up to space" mode (only matches up to the first space in the pattern) |

Preserves: `HL(U)`, `DE(U)` and `BC(U)`

Returns:

- `A`: Status
    - `0` if pattern matches
	- Positive number if string does not match, and is logically sorted after the pattern
	- Negative number if string does not match, and is logically sorted before the pattern

<a id="api-29"></a>

### 29 — mos_getargument

Source: [mos_api_getargument](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1108); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L844).

Extract a (numbered) argument from a string

Parameters:

- `HL(U)`: Pointer to source string
- `BC(U)`: Argument number

Returns:

- `HL(U)`: Address of the argument or zero if not found
- `DE(U)`: Address of the argument end (next character after the argument)

Preserves: `BC(U)`

<a id="api-2a"></a>

### 2A — mos_extractstring

Source: [mos_api_extractstring](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1136); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L860).

Extract a string, using a given divider.

Parameters:

- `HL(U)`: Pointer to a zero-terminated source string to extract from
- `DE(U)`: Pointer to string for divider matching, or `0` for default (space)
- `C`: Flags. Depending on flags, the result string will be zero terminated or not

The flags are a bit-field to enable various different options

| Bit | Description |
| --- | ----------- |
| 0   | Zero terminate the result string |
| 1   | Omit skipping of divider characters at beginning of source string |
| 2   | Disable matching of double-quotes |
| 3   | Include double-quotes in results string |

If string extraction is matching double-quotes and an end quote is not found, a status code of `25` (Bad string) will be returned.  If it is not possible to extract a result, a status code of `19` (Invalid parameter) will be returned.

Returns:

- `A`: status code (`0` = OK, `19` = Invalid parameter, `25` = Bad string)
- `HL(U)`: Address of the result string
- `DE(U)`: Address of next character after end of result string

Preserves: `BC(U)`

<a id="api-2b"></a>

### 2B — mos_extractnumber

Source: [mos_api_extractnumber](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1176); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L889).

Extract a number, using given divider.  Various number formats are supported - for more information see notes on numbers interpreted by the [MOS CLI](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./Star-Commands.md)

Parameters:

- `HL(U)`: Pointer to a zero-terminated source string to extract from
- `DE(U)`: Pointer to string for divider matching, or 0 for default (space)
- `C`: Flags

The flags are a bit-field to enable various different options

| Bit | Description |
| --- | ----------- |
| 0   | Decimal numbers only |
| 1   | Positive numbers only |
| 2   | Allow `h` suffix to indicate hexadecimal numbers |

If the source string does not contain a valid number, in accordance with the flags, a status code of `19` (Invalid parameter) will be returned.

Returns:

- `A`: status code (`0` = OK, `19` = Invalid parameter)
- `HL(U)`: Number extracted
- `DE(U)`: Address of next character after end of number

Preserves: `BC(U)`

<a id="api-2c"></a>

### 2C — mos_escapestring

Source: [mos_api_escapestring](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1221); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L917).

"Escape" a string for display, converting control characters to be pipe-prefixed

Parameters:

- `HL(U)`: Pointer to source string
- `DE(U)`: Pointer to destination buffer (optional)
- `BC(U)`: Length of destination buffer

If no destination buffer is provided (i.e. `DE` is zero), the function will return the length of the escaped string.

If the destination buffer is too short then a status code of `22` (Out of memory) will be returned, and as much of the source string that could be converted will be copied to the destination buffer.

Returns:

- `A`: Status code
- `BC(U)`: Length of escaped string

<a id="api-30"></a>

### 30 — mos_setvarval

Source: [mos_api_setvarval](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1256); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L944).

Set, update, replace or remove a [System Variable](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./System-Variables.md)

Parameters:

- `HL(U)`: Pointer to variable name (zero-terminated string, can include wildcards)
- `IX(U)`: Variable value (number, or pointer to zero-terminated string)
- `IY(U)`: Pointer to variable name (0 for first call)
- `C`: Variable type, or -1 (255) to delete the variable

If the name used includes a wildcard, then the first matching variable will be set.  Subsequent calls can be made to set the next variable that matches the pattern, so long as you preserve `IY(U)` between calls.

Variable types supported are:

| Type | Description |
| ---- | ----------- |
| 0    | String (Will be run through GSTrans before storing) |
| 1    | Number (a 24-bit integer value) |
| 2    | Macro (A string that will be GSTrans'd each time it is used) |
| 3	   | "Expanded" (Expression that will be evaluated before stored) |
| 4    | Literal string (GSTrans will not be called before storage) |

NB at the time of writing the expression engine has yet to be written in MOS 3 so type 3 support is limited to either a number or a string to indicate a variable name to copy as a string type.

If either a type of 3 or 4 is used then the variable type used for storage of the variable will be either a string or a number.

Internally MOS also supports "Code" type variables, which are used for several things, such as exposing date/time information.  If such a variable variable supports being set then you can call the "set" functions of these variables by using the String type with a matching name.  You cannot remove a "Code" type variable using this function.

NB as this API requires a pointer in `IX(U)`, and is therefore difficult to use from C code, the underlying C function this API uses can be accessed using the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Returns:

- `A`: Status code
- `C`: Actual variable type
- `IY(U)`: Pointer to actual variable name (for next call)

Other registers will be preserved.

<a id="api-31"></a>

### 31 — mos_readvarval

Source: [mos_api_readvarval](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1300); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L983).

Read a variable value

Parameters:

- `HL(U)`: Pointer to variable name (can include wildcards)
- `DE(U)`: Length of buffer to store the value
- `IX(U)`: Pointer to buffer to store the value (null/0 to read length only)
- `IY(U)`: Pointer to variable name (0 for first call)
- `C`: Flags (3 = expand value into string - other values will be ignored)

If the name includes a wildcard then the first matching variable will be read.  Subsequent calls can be made to read the next value that matches the pattern, so long as you preserve `IY(U)` between calls.

Please note that whilst numeric variables are set using [`mos_setvarval`](https://agonplatform.github.io/agon-docs/mos/API/#0x30-mos_setvarval) by providing their value directly in a register, when reading a numeric variable the value will be returned in the buffer pointed to by `IX(U)`.  That buffer must be at least 3 bytes long, unless the "flag" value is set to `3`, in which case it must be large enough to contain a string representation of the number in decimal.

NB as this API requires a pointer in `IX(U)`, and is therefore difficult to use from C code, the underlying C function this API uses can be accessed using the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Returns:

- `A`: Status code
- `C`: Actual variable type
- `DE(U)`: Length of variable value
- `IY(U)`: Pointer to variable name (for next call)

<a id="api-32"></a>

### 32 — mos_gsinit

Source: [mos_api_gsinit](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1346); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1008).

Initialises a GSTrans operation.

GSTrans is a process of taking a source string and translating it, replacing any variables referenced, and converting any control codes into raw control bytes.  The [`echo` command](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./Star-Commands.md#echo) in MOS is an example of a command that uses the GSTrans process, and the documentation for that command contains a more complete description of how the source string will be interpreted.

The process of translating a string is a two-step process.  The first step is to call `mos_gsinit` to initialise the process, and the second step is to repeatedly call `mos_gsread` to actually perform the translation, fetching one character at a time until the whole string has been translated, and a zero character is read.

Various options are available to control how the translation process operates, and these are set using the flags parameter.  By default, the translation process will continue until the end of the source string is reached.  It is possible to instead translate only up to the first space.  The process also supports detecting double-quotes to surround a string, in which case a request to terminate at a space will be ignored if the space is inside the double-quotes.  (It should be noted that the `echo` command sets this flag.)  Finally by default the process will translate characters preceeded by a `|` character as control codes, as explained in the documentation for the [`echo` command](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./Star-Commands.md#echo).  If you wish to disable this behaviour then you can set the "no pipe" flag.

Parameters:

- `HL(U)`: Pointer to source buffer to translate
- `DE(U)`: Address of pointer used to store trans info
- `C`: Flags

`DE(U)` must point to an address that will be used to store a (3-byte) pointer to an information block used by the GSTrans process.  It should be noted that failing to complete the GSTrans process can result in a memory leak.

The flags are a bit-field with options to control how the translation process operates.  Their meanings are as follows:

| Bit | Description |
| --- | ----------- |
| 0   | Terminate at first space character in source buffer |
| 1   | No pipe (do not treat `|` as a control code) |
| 2   | Do not treat double-quotes `"` as markers surrounding a string |
| 3-6 | Reserved for future use (for future compatibility, ensure these are set to zero) |
| 7   | No tracking (do not automatically track memory used by GSTrans) |

It should be noted that failing to complete translation of a string will result in some memory inside MOS remaining set aside to store the GSTrans process information.  This memory will either be freed when the GSTrans process is completed, or a new call to `mos_gsinit` is made.  If the "No tracking" flag is set however then MOS will not track the memory being used, and it will not be freed on a subsequent call to `mos_gsinit` - you must complete the process of reading through the string to free the memory, or you will cause a memory leak inside MOS.

In general you should not use the "No tracking" flag unless you have a need to perform two or more gstrans operations simultaneously.

Returns:

- `A`: Status code

<a id="api-33"></a>

### 33 — mos_gsread

Source: [mos_api_gsread](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1369); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1044).

Perform a GSTrans "read" operation.

When the final character of the translated string has been read, this function will return a null character (`0`) to indicate the end of the string.

Parameters:

- `DE(U)`: Address of pointer used to store trans info (same pointer as used with gsInit)

Returns:

- `A`: Status code (`0` = Success, various other values may indicate an invalid GSTrans string)
- `C`: Character read.  This will be `0` if the end of the string has been reached.

<a id="api-34"></a>

### 34 — mos_gstrans

Source: [mos_api_gstrans](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1396); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1059).

Perform a complete GSTrans operation from source into dest buffer

Parameters:

- `HL(U)`: Pointer to source buffer
- `IX(U)`: Pointer to destination buffer (can be null to just count size)
- `DE(U)`: Length of destination buffer
- `C`: Flags

If the destination buffer given for this command is less than the size required for the translated string, then the API call will succeed, but the translated string will be truncated to fit in the buffer.

The flags here are identical those used with `mos_gsinit`, with the exception that the "No tracking" flag will be ignored.

NB as this API requires a pointer in `IX(U)`, and is therefore difficult to use from C code, the underlying C function this API uses can be accessed using the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Returns:

- `A`: Status code
- `BC(U)`: Calculated total length of translated string

<a id="api-35"></a>

### 35 — mos_substituteargs

Source: [mos_api_substituteargs](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1434); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1081).

Substitute arguments into a string from template

Parameters:

- `HL(U)`: Pointer to template string
- `IX(U)`: Pointer to arguments string
- `DE(U)`: Length of destination buffer
- `IY(U)`: Pointer to destination buffer (can be null to just count size)
- `C`: Flags

The only flag currently supported is bit 0, which when set indicates that the "rest" arguments (i.e. those not explicitly used in the template) should be omitted from the destination string.  When this bit is clear they will be automatically appended.

NB as this API requires a pointer in `IX(U)`, and is therefore difficult to use from C code, the underlying C function this API uses can be accessed using the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Returns:

- `BC(U)`: Calculated length of destination string

<a id="api-36"></a>

### 36 — mos_evaluateexpression

Source: [mos_api_not_implemented](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L347); **stub**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1101).

As of MOS 3.0 this function has not yet been implemented.  Support for this function is planned for a future release.

<a id="api-38"></a>

### 38 — mos_resolvepath

Source: [mos_api_resolvepath](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1475); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1113).

Resolves a path, creating a new resolved path string that expands [system variables](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./System-Variables.md), and also replaces [prefixes](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./System-Variables.md#path-variables) and leafnames with actual values.  System variables will be expanded first, and then the prefix and leafname will be resolved.  The result is a fully resolved path that can be used with the FatFS API calls.

If the leafname contains wildcards then the first matching file will be returned.  Please note that this will be the first match found in a directory, and owing to how directories are managed this may not be the first alphabetical match.  Subsequent calls can be made to find the next matching file, so long as you provide a pointer to an empty directory object to persist between calls, and preserve the `C` register between calls too.

NB path resolution does not support resolving paths that contain wildcards in the directory part of the path.  If you need to do this then you should gradually build the path up by calling `mos_resolvepath` multiple times to resolve the path up to each wildcard, using flags to filter for results that are a directory matching the wildcard until the directory part of the path is fully resolved.  You can then call `mos_resolvepath` again with different flags to resolve the leafname part of the path.

Parameters:

- `HL(U)`: Pointer to the path to resolve (zero terminated)
- `IX(U)`: Pointer to destination buffer to store the resolved path (optional - set to zero for length count only)
- `DE(U)`: Length of the destination buffer
- `IY(U)`: Pointer to a directory object to persist between calls (optional, set to zero to omit)
- `B`: Flags
- `C`: Index of the resolved path (zero for first call)

Path resolution will resolve prefixes in files paths, which are a string followed by a colon character, such as `Library:`.  The string must match up with a corresponding system variable, in this example the variable would be named `Library$Path`.  Prefixes are not case-sensitive, so `library:`, `Library:` and `LIBRARY:` would all match in this example.  Such path variables can contain multiple values separated by commas.  The "index" argument in the `C` register is used to work out which prefix to use when there are multiple matches, and must be set to zero on a first call.

If you are resolving for a file that does not exist, the path will be resolved to the first matching directory, returning a "no file" (`4` status code).  If no matching directory can be found the path will not be resolved, and a "no path" (`5` status code) will be returned, and the returned path will be empty.  If the path is resolved successfully to an existing file the status code will be `0`.

The `flags` argument is a bit-field used to indicate which files are valid to be returned.  These bits are used to filter the results based on the file attributes, which are inherited from the file system (FatFS).  If you wish to always return all results you should set the flags to `0`.  The bits are as follows:

| Bit | FatFS constant | Description |
| --- | -------------- | ----------- |
| 0 | `AM_RDO` | Read only |
| 1 | `AM_HID` | Hidden |
| 2 | `AM_SYS` | System |
| 3 | n/a | Reserved/Unused - set to zero |
| 4 | `AM_DIR` | Directory |
| 5 | `AM_ARC` | Archive |
| 6 | n/a | Set to disable system variable expansion |
| 7 | n/a | Include/exclude in results |

System variable expansion passes the source path through the [GSTrans](https://agonplatform.github.io/agon-docs/mos/API/#0x34-mos_gstrans) process, replacing any system variables used in the path with their values.  If you have already performed this step then you can set bit 6 to disable the expansion.

Bit 7 is used to indicate how to apply the attributes to filter results.  When it is set, any result must include _all_ of the attributes set.  When it is clear, the result will not include any of the attributes set.  This can be used, for example, to filter out hidden or system files, or alternatively to only include results that are directories.

NB any attributes that are not set in the `flags` argument will be ignored, so if you perform a search with a flags value of `0x06`, which will filter out hidden and system files, your results may include items that have their directory, read-only, and/or archive bits set.  Similarly a search with a flags value of `0x90` will only include directories, but those directories could have any of the other attributes set.

If you wish to further filter results you should pass in a `DIR` object in `IY(U)` to persist between calls, and use the [`ffs_stat`](https://agonplatform.github.io/agon-docs/mos/API/#0x96-ffs_stat) API call to get a `FILINFO` object where you can check the full attributes of the the returned result (stored in the `fattrib` field).  If the results do not match your requirements you can then call `mos_resolvepath` again to find the next matching file.

If the leafname in your path contains wildcards then the first matching file will be returned.  If you wish to find the next matching file then you should provide a pointer to an empty directory object in `IY(U)` with your first call, and use the same object with subsequent calls (also using the same `C` register value).  If you do not include a pointer to a directory object then only the first matching file within a single directory will be returned.

Besides finding filecard matches, the other main use for this API is to resolve a path so that it can be used with [FatFS API calls](https://agonplatform.github.io/agon-docs/mos/API/#fatfs-commands).  This step is needed to ensure that the path is fully resolved, as the FatFS API calls do not support using path prefixes or system variables.  Attempting to use an unresolved path with a fatfs API call may either fail or produce unexpected results.

It is not necessary to use this API call to resolve paths for use with the MOS-native API calls, as those will all automatically resolve paths for you.

NB as this API requires a pointer in `IX(U)`, and is therefore difficult to use from C code, the underlying C function this API uses can be accessed using the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Returns:

- `A`: Status code (`0` = Success, `22` = Out of memory, `5` = No path, `4` = No file)
- `C`: Index of the resolved path (for next call)
- `DE(U)`: Length of the resolved path

If this is called with a null pointer in `IX(U)` then the maximum possible length of of all possible resolved paths will be returned in `DE(U)`.  This is useful if you wish to allocate a buffer for the resolved path, but do not know how long it will be.

A result of `5` indicates that no matching directory could be found in the filing system.  A result of `4` indicates that a matching directory was found, but no matching file for that directory.

A result of `22` indicates that either the resolved path was too long for the buffer provided, or that there was an error allocating memory whilst searching for a matching path.

<a id="api-39"></a>

### 39 — mos_getdirforpath

Source: [mos_api_getdirectoryforpath](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1534); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1175).

Get the directory for a given path.

This function works with strings only - it resolves path prefixes for the given index, but does not check whether the path actually points to a valid file or directory.  The index is used which prefix to use when the path prefix variable contains multiple options.

The returned path will be the directory part of the path, and will not include the leafname.

Parameters:

- `HL(U)`: Pointer to the path to get the directory for
- `IX(U)`: Pointer to the buffer to store the directory in (optional - omit for count only)
- `DE(U)`: Length of the buffer
- `C`: Search index

NB as this API requires a pointer in `IX(U)`, and is therefore difficult to use from C code, the underlying C function this API uses can be accessed using the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Returns:

- `A`: Status code
- `DE(U)`: Length of the directory path

<a id="api-3a"></a>

### 3A — mos_getleafname

Source: [mos_api_getfilepathleafname](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1566); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1197).

Get the leafname for a given path.

This is a utility function that will scan a file path string and return a pointer within that string to the leafname.  The leafname is the last part of a file path, and may refer to a file or a directory.  This call does not check whether the path actually points to a valid file or directory, and it does not resolve any path prefixes.  It should be noted that a leafname may be empty if the path is empty or ends with a `/` or `:` character.

If the path does not contain a valid leafname then the function will return a pointer to the end of the string.

Parameters:

- `HL(U)`: Pointer to the path to get the leafname from

Returns:

- `HL(U)`: Pointer to the leafname

<a id="api-3b"></a>

### 3B — mos_isdirectory

Source: [mos_api_isdirectory](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1582); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1213).

Checks if a given path points to a directory

NB this call only works with fully resolved paths, and as such does not perform path prefix resolution.  You may therefore need to use [`mos_getdirforpath`](https://agonplatform.github.io/agon-docs/mos/API/#0x39-mos_getdirforpath) or [`mos_resolvepath`](https://agonplatform.github.io/agon-docs/mos/API/#0x38-mos_resolvepath) first.

Parameters:

- `HL(U)`: Pointer to the path to check

Returns:

- `A`: Status code (`0` = Success, `5` = No path)

<a id="api-3c"></a>

### 3C — mos_getabsolutepath

Source: [mos_api_getabsolutepath](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1607); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1228).

Get the absolute version of a (relative) path

NB currently as of MOS 3.0, unlike similar API calls above, this API does not support being called with a null pointer to count the length of the resolved path, and does not return the length.  If called with a null pointer from ADL mode, the API will return a status code of `19` (Invalid parameter).  Calling with a null pointer from Z80 mode code is not currently supported/checked and may cause unexpected results or crashes.  This will likely change in a future MOS release.

Parameters:

- `HL(U)`: Pointer to the path to get the absolute version of
- `IX(U)`: Pointer to the buffer to store the absolute path in
- `DE(U)`: Length of the buffer

NB as this API requires a pointer in `IX(U)`, and is therefore difficult to use from C code, the underlying C function this API uses can be accessed using the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Returns:

- `A`: Status code

If the buffer is too short for the resolved path then a status code of `22` (Out of memory) will be returned.  Path resolution problems may result in status codes of `5` (No path) or `4` (No file).

<a id="api-40"></a>

### 40 — mos_clearvdpflags

Source: [mos_api_clear_vdp_flags](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1630); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1256).

Clears [VDP protocol status flags](https://agonplatform.github.io/agon-docs/mos/API/#VDP-pflags-vdpflags) from the `sysvar_vpd_pflags` [sysvar](https://agonplatform.github.io/agon-docs/mos/API/#sysvars).

Bits in this status value will be set when various different VDP Protocol message packet types are received by MOS from the VDP.  Such packets may be sent for user-initiated actions, such as pressing a key on the keyboard, or moving the mouse, or for system-initiated actions, such as a VDU command being sent to the VDP.  Please note that in general use these bits are not automatically cleared, so if you wish to detect a response from the VDP to a VDU command your program sends it is important to clear out the corresponding protocol flags before sending the command.  You can then use the [`mos_waitforvdpflags`](https://agonplatform.github.io/agon-docs/mos/API/#0x41-mos_waitforvdpflags) API call to wait for the VDP to respond, and check the status of the flags in `sysvar_vpd_pflags` to see if the command was successful.

Further information on the VDP protocol and the flag bits can be found in the [VDP Protocol documentation](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/../vdp/System-Commands.md#vdp-serial-protocol).

Parameters:

- `C`: Bitmask of flags to clear

Returns:

- `A`: New VDP flags

<a id="api-41"></a>

### 41 — mos_waitforvdpflags

Source: [mos_api_wait_vdp_flags](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1644); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1272).

Waits for corresponding [VDP protocol status flags](https://agonplatform.github.io/agon-docs/mos/API/#VDP-pflags-vdpflags) to be set in the `sysvar_vpd_pflags` [sysvar](https://agonplatform.github.io/agon-docs/mos/API/#sysvars).

Typically your program should first clear whichever protocol flag you are interested in detecting, using the [`mos_clearvdpflags`](https://agonplatform.github.io/agon-docs/mos/API/#0x40-mos_clearvdpflags) API call.  Once you have done that, you should send a VDU command to the VDP for which you are expecting a response, and then use this API call to wait for that response to be received.

MOS contains inbuilt support for handling VDP protocol messages.  Typically on receipt of a message a flag will be set in the `sysvar_vpd_pflags` variable, and also other corresponding [sysvars](https://agonplatform.github.io/agon-docs/mos/API/#sysvars) will be updated from the contents of the message.

This API call will wait for approximately 1 second for the VDP to respond, which should be more than enough time for any VDU command to be processed.  If the VDP does not respond within this time, the API call will return with a status code of `15` (Timeout).  If the VDP does respond, the API call will return with a status code of `0` (Success).

Parameters:

- `C`: Bitmask of flags to wait for

Returns:

- `A`: Status code (`0` = Success, `15` = Timeout)

<a id="api-50"></a>

### 50 — mos_getfunction

Source: [mos_api_getfunction](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2306); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1290).

This API call will return a pointer to a function that follows the Zilog eZ80 C calling convention.  As these are 24-bit pointers, and passing arguments needs to be done using the 24-bit stack pointer (`SPL`), this API call is not usable by programs running in Z80 mode.

Information on the C calling convention can be found [here](https://github.com/pcawte/AgDev?tab=readme-ov-file#c-calling-conventions-for-interfacing-with-asm-applications)

Parameters:

- `C`: Flags (must be `0` in MOS 3.0)
- `B`: Function number

Returns:

- `A`: Status code (`0` = Success, `19` = Invalid parameter, `20` = Invalid command)
- `HLU`: Pointer to function (or `0` if the request was invalid invalid)

If this API is called from Z80 mode code, then it will return a status code of `20` (Invalid command) as this API is only supported in ADL mode.

This API includes a flags byte which must be set to zero in MOS 3.0.  This is reserved for future use to allow for additional functionality to be added in future versions of MOS.  If flags are set to anything other than `0` then the API will return a status code of `19` (Invalid parameter).

Similarly, if the function number passed to this API is higher than the highest available function, then the API will return a status code of `20` (Invalid command).

Full details of the functions available through this API, and more information about how to use them, can be found in the documentation about [C Functions](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./C-Functions.md)

<a id="api-70"></a>

### 70 — sd_getunlockcode

Source: [sd_api_getunlockcode](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2224); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1324).

This API call is used to obtain the unlock code needed to use the low-level SD card APIs.  The unlock code is a randomly generated 24-bit value, created the first time this API is called.

Parameters:

- `HL(U)`: Pointer to a 24-bit value to store the unlock code

Returns:

Nothing

<a id="api-71"></a>

### 71 — sd_init

Source: [sd_api_init](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2234); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1336).

Initialises the SD card support system.  MOS automatically calls this when it mounts an SD card.  If you are writing support for an operating system you may need to call this to restart the SD card system if the SD card is removed and reinserted.

Parameters:

- `HL(U)`: Pointer to the unlock code (24-bit value) as fetched by the [`sd_getunlockcode`](https://agonplatform.github.io/agon-docs/mos/API/#0x70-sd_getunlockcode) API call

Returns:

- `A`: Status code
    - `0` = Success/Ready
	- `1` = Error
	- `2` = Locked (incorrect unlock code provided, or no lock code yet set)

<a id="api-72"></a>

### 72 — sd_readblocks

Source: [sd_api_readblocks](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2247); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1351).

Read raw blocks from the SD card.

Parameters:
- `HL(U)`: Pointer to a 32-bit sector number, followed by the 24-bit unlock code
- `DE(U)`: Pointer to a buffer to store the read data
- `BC`: Number of blocks to read (16-bit value)

Returns:

- `A`: Status code
    - `0` = Success/Ready
	- `1` = Error
	- `2` = Locked (incorrect unlock code provided, or no lock code yet set)

<a id="api-73"></a>

### 73 — sd_writeblocks

Source: [sd_api_writeblocks](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2268); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1367).

Writes raw blocks to the SD card.

Parameters:

- `HL(U)`: Pointer to a 32-bit sector number, followed by the 24-bit unlock code
- `DE(U)`: Pointer to a buffer containing the data to write
- `BC`: Number of blocks to write (16-bit value)

Returns:

- `A`: Status code
	- `0` = Success/Ready
	- `1` = Error
	- `2` = Locked (incorrect unlock code provided, or no lock code yet set)

<a id="api-80"></a>

### 80 — ffs_fopen

Source: [ffs_api_fopen](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1657); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1400).

Open a file (Available from MOS 1.03)

Parameters:

- `HL(U)`: Pointer to an empty `FIL` structure
- `DE(U)`: Pointer to a C (zero-terminated) filename string
- `C`: File open mode

The file open mode on this API is a bit-field that is identical to the [mode used](https://agonplatform.github.io/agon-docs/mos/API/#file-open-modes) in the [`mos_fopen`](https://agonplatform.github.io/agon-docs/mos/API/#0x0a-mos_fopen) API call.

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`, `DE(U)`, `C`

Example:

<a id="api-81"></a>

### 81 — ffs_fclose

Source: [ffs_api_fclose](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1677); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1439).

Close a file (Available from MOS 1.03)

Parameters:

- `HL(U)`: Pointer to a `FIL` structure

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`

See [`ffs_fopen`](https://agonplatform.github.io/agon-docs/mos/API/#0x80-ffs_fopen) for an example.

NB: you should not use this call to close a file that had been opened using [`mos_fopen`](https://agonplatform.github.io/agon-docs/mos/API/#0x0a-mos_fopen), as doing so will mean that MOS will be reserving an file handle for a file that has been closed.

<a id="api-82"></a>

### 82 — ffs_fread

Source: [ffs_api_fread](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1692); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1457).

Read from a file (Available from MOS 1.03)

Parameters:

- `HL(U)`: Pointer to a `FIL` structure
- `DE(U)`: Pointer to a buffer to store the data in
- `BC(U)`: Number of bytes to read (typically the size of the buffer)

Returns:

- `A`: `FRESULT`
- `BC(U)`: Number of bytes read

Preserves: `HL(U)`, `DE(U)`

See ffs_fopen for an example

<a id="api-83"></a>

### 83 — ffs_fwrite

Source: [ffs_api_fwrite](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1720); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1476).

Write to a file (Available from MOS 1.03)

Parameters:

- `HL(U)`: Pointer to a `FIL` structure
- `DE(U)`: Pointer to a buffer to read the data from
- `BC(U)`: Number of bytes to write (typically the size of the buffer)

Returns:

- `A`: `FRESULT`
- `BC(U)`: Number of bytes written

Preserves: `HL(U)`, `DE(U)`

Example:

<a id="api-84"></a>

### 84 — ffs_flseek

Source: [ffs_api_flseek](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1747); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1512).

Move the read/write pointer in a file (Available from MOS 1.03)

NB this API is deprecated and kept for compatibility reasons.  You are advised to use the [`ffs_flseek_p`](https://agonplatform.github.io/agon-docs/mos/API/#0xa6-ffs_flseek_p) API instead.  As this API requires a full 24-bit value to be provided in the `DE(U)` register it is not directly compatible with programs written to run in Z80 mode.

This API call can also be used to expand the file size, by moving the pointer to a location beyond the current end of the file.  It should be noted that the extra allocated disk space will not be cleared, so the data in the new space will be undefined.

Parameters:

- `HL(U)`: Pointer to a `FIL` structure
- `DE(U)`: Least significant 3 bytes of the offset from the start of the file
- `C`: Most significant byte of the offset (set to 0 for files < 16MB)

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`, `DE(U)`, `BC(U)`

<a id="api-85"></a>

### 85 — ffs_ftruncate

Source: [ffs_api_ftruncate](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1763); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1532).

Truncate a file to the current file pointer offset (Available from MOS 2.3.0)

To truncate to a specified size you will need to use [`ffs_flseek_p`](https://agonplatform.github.io/agon-docs/mos/API/#0xa6-ffs_flseek_p) to move the file pointer to the desired location before calling `ffs_ftruncate`.

Parameters:

- `HL(U)`: Pointer to a `FIL` structure

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`

<a id="api-86"></a>

### 86 — ffs_fsync

Source: [ffs_api_fsync](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1775); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1548).

Flushes cached information of a writing file

When writing to a file, file data may be cached in memory until the file is closed.  This function will flush the cache to the SD card, ensuring that all data has been written.  This can be useful to minimise the risks of data loss in the event of a power failure, SD card removal, or other unexpected shutdown.

Please note that MOS 3.0 does not currently cache writes to the SD card.  This API call is provided in case we do add caching in the future.  You may still wish to use this call to ensure that data is guaranteed to be written to the SD card in the event that a future version of MOS adds caching support.  Calling this API on systems that do not support caching will have no effect and be harmless.

Parameters:

- `HL(U)`: Pointer to a `FIL` structure

Returns:

- `A`: `FRESULT`

<a id="api-87"></a>

### 87 — ffs_fforward

Source: [ffs_api_fforward](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1783); **stub**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1564).

This API is not implemented, as the FatFS `f_forward` function is not supported by the current configuration of the FatFS library used in MOS.

The documented purpose of the `f_forward` function is to read file data and forward it to a "data streaming device" (a callback function).  It is unlikely that this feature would be enabled in the future as we do not have a clear use-case for it, and similar functionality can be achieved by other means.

Returns:

- `A`: `23` (Not implemented)

<a id="api-88"></a>

### 88 — ffs_fexpand

Source: [ffs_api_fexpand](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1785); **stub**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1574).

This API is not implemented, as the FatFS `f_expand` function is not supported by the current configuration of the FatFS library used in MOS.

The purpose of the `f_expand` function is to expand a file allocating a contiguous data area to the file.  Files can be expanded using the [`ffs_flseek`](https://agonplatform.github.io/agon-docs/mos/API/#0x84-ffs_flseek) API, although this will not guarantee that the data area is contiguous.  It is unlikely that this API will be implemented in the future, as on an SD card there is little advantage to be had in allocating a contiguous data area for a file.

Returns:

- `A`: `23` (Not implemented)

<a id="api-89"></a>

### 89 — ffs_fgets

Source: [ffs_api_fgets](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1795); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1584).

Reads a string from a file

Reads characters into a buffer until a newline `\n` character is reached, the end of file encountered, or the buffer is filled.  The string read will be zero terminated.

It should be noted that this API does not return a status code in the `A` register.

Parameters:

- `HL(U)`: Pointer to a `FIL` structure
- `DE(U)`: Pointer to a buffer to store the string in
- `BC(U)`: Buffer size

Returns:

- `DE(U)`: Pointer to the target buffer, or NULL if an error occurred

Preserves: `HL(U)`, `BC(U)`

<a id="api-8a"></a>

### 8A — ffs_fputc

Source: [ffs_api_fputc](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1816); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1604).

Writes a single character to a file

It should be noted that this API does not return a status code in the `A` register.

Parameters:

- `HL(U)`: Pointer to a `FIL` structure
- `C`: Character to write

Returns:

- `BC(U)`: Number of bytes written

Preserves: `HL(U)`

<a id="api-8b"></a>

### 8B — ffs_fputs

Source: [ffs_api_fputs](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1831); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1621).

Writes a zero-terminated string to a file.  The termination character will not be written to the file.

It should be noted that this API does not return a status code in the `A` register.

Parameters:

- `HL(U)`: Pointer to a `FIL` structure
- `DE(U)`: Pointer to a zero-terminated string

Returns:

- `BC(U)`: Number of bytes written

Preserves: `HL(U)`, `DE(U)`

<a id="api-8c"></a>

### 8C — ffs_fprintf

Source: [ffs_api_fprintf](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1844); **stub**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1638).

Whilst our configuration of FatFS does support the `f_printf` function, we do not currently support it in the MOS API.  This is because the function accepts a variable number of arguments, and it is not clear how this could be implemented in a way that is consistent with the rest of the APIs that MOS supports.

The `f_printf` function is made available via the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API call.  It can therefore be used from any (ADL mode) code that complies with the Zilog eZ80 C calling convention.  This API is not available in Z80 mode code.

<a id="api-8d"></a>

### 8D — ffs_ftell

Source: [ffs_api_ftell](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1854); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1644).

Get the current read/write offset pointer of a file

Parameters:

- `HL(U)`: Pointer to a `FIL` structure
- `DE(U)`: Pointer to a 4-byte buffer to store the returned 32-bit offset in

Returns:

- `A`: `FRESULT` (`0` = Success, or `19` = Invalid parameter)

Preserves: `HL(U)`, `DE(U)`

<a id="api-8e"></a>

### 8E — ffs_feof

Source: [ffs_api_feof](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1871); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1659).

Detect end of file

Please note that whilst this API has been present since MOS 1.03 its implementation had an error which meant that it would return the value of the `L` register passed in as a parameter, rather than the correct value.  This was fixed in MOS 3.0.

Parameters:

- `HL(U)`: Pointer to a `FIL` structure

Returns:

- `A`: 1 if at the end of the file, otherwise 0

Preserves: `HL(U)`

<a id="api-8f"></a>

### 8F — ffs_fsize

Source: [ffs_api_fsize](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1884); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1675).

Get the size of a file

Parameters:

- `HL(U)`: Pointer to a `FIL` structure
- `DE(U)`: Pointer to a 4-byte buffer to store the returned 32-bit file size in

Returns:

- `A`: `FRESULT` (`0` = Success, or `19` = Invalid parameter)

Preserves: `HL(U)`

<a id="api-90"></a>

### 90 — ffs_ferror

Source: [ffs_api_ferror](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1901); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1690).

Tests for an error on a file

Returns a non-zero value if a hard error has returned, otherwise will return a status of `0` (OK).

Parameters:

- `HL(U)`: Pointer to a `FIL` structure

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`

<a id="api-91"></a>

### 91 — ffs_dopen

Source: [ffs_api_dopen](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1912); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1706).

Open a directory (Available from MOS 2.2.0)

Parameters:

- `HL(U)`: Pointer to a blank `DIR` structure
- `DE(U)`: Pointer to a C (zero-terminated) directory path string

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`, `DE(U)`

<a id="api-92"></a>

### 92 — ffs_dclose

Source: [ffs_api_dclose](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1930); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1721).

Close a directory (Available from MOS 2.2.0)

Parameters:

- `HL(U)`: Pointer to a `DIR` structure

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`

<a id="api-93"></a>

### 93 — ffs_dread

Source: [ffs_api_dread](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1946); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1735).

Read next directory entry into a `FILINFO` data structure (Available from MOS 2.2.0)

Parameters:

- `HL(U)`: Pointer to a `DIR` structure
- `DE(U)`: Pointer to a `FILINFO` structure

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`, `DE(U)`

<a id="api-94"></a>

### 94 — ffs_dfindfirst

Source: [ffs_api_dfindfirst](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1968); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1750).

Searches a directory for a matching item

Parameters:

- `HL(U)`: Pointer to a blank `DIR` struct
- `DE(U)`: Pointer to a blank `FILINFO` struct
- `BC(U)`: Pointer to directory path string
- `IX(U)`: Pointer to matching pattern string

The directory path provided in `BC(U)` must be a fully resolved path, and the matching pattern in `IX(U)` should be a zero-terminated string.  The matching pattern can include wildcards, such as `*` and `?`, and will be used to match against the directory entries.  Subsequent entries can be found using [`ffs_dfindnext`](https://agonplatform.github.io/agon-docs/mos/API/#0x95-ffs_dfindnext) passing in the same `DIR` structures as passed to this call, and the pattern string must also be preserved.

If a matching file is found, the `FILINFO` structure will be populated with information about the file.

NB as this API requires a pointer in `IX(U)`, and is therefore difficult to use from C code, the underlying C function this API uses can be accessed using the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API.

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`, `DE(U)`, `BC(U)`, `IX(U)`

<a id="api-95"></a>

### 95 — ffs_dfindnext

Source: [ffs_api_dfindnext](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L1993); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1773).

Find next matching item in a directory

This API call is used to find the next matching item in a directory after a successful call to [`ffs_dfindfirst`](https://agonplatform.github.io/agon-docs/mos/API/#0x94-ffs_dfindfirst).  It will return the next matching file or directory in the same way as `ffs_dfindfirst`, but will not require the path and pattern strings to be passed in again.  Please note that whilst it is not a parameter for this API, the pattern string passed to `ffs_dfindfirst` must be preserved, as it will be used to match against the directory entries.

Parameters:

- `HL(U)`: Pointer to a `DIR` structure, as set up by [`ffs_dfindfirst`](https://agonplatform.github.io/agon-docs/mos/API/#0x94-ffs_dfindfirst)
- `DE(U)`: Pointer to a `FILINFO` structure

NB for completeness/convenience as the [`ffs_dfindfirst`](https://agonplatform.github.io/agon-docs/mos/API/#0x94-ffs_dfindfirst) API is available as a C function via the [`mos_getfunction`](https://agonplatform.github.io/agon-docs/mos/API/#0x50-mos_getfunction) API, this API is also available as a C function.

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`, `DE(U)`

<a id="api-96"></a>

### 96 — ffs_stat

Source: [ffs_api_stat](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2011); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1792).

Get file information (Available from MOS 1.03)

Parameters:

- `HL(U)`: Pointer to a `FILINFO` structure
- `DE(U)`: Pointer to a C (zero-terminated) filename string

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`, `DE(U)`

Example:

<a id="api-97"></a>

### 97 — ffs_unlink

Source: [ffs_api_unlink](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2029); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1820).

Removes ("unlinks") a file or sub-directory from the volume (Requires MOS 3.0 or above)

Parameters:

- `HL(U)`: Pointer to a zero-terminated file path string

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`

<a id="api-98"></a>

### 98 — ffs_rename

Source: [ffs_api_rename](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2044); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1834).

Rename and/or move a file or sub-directory

This is a raw rename function that does not perform any path resolution, and does not support wildcards.  For more sophisticated behaviour you should use the [`mos_ren` API](https://agonplatform.github.io/agon-docs/mos/API/#0x06-mos_ren) instead.

Parameters:

- `HL(U)`: Pointer to a zero-terminated source file path string
- `DE(U)`: Pointer to a zero-terminated destination file path string

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`, `DE(U)`

<a id="api-99"></a>

### 99 — ffs_chmod

Source: [ffs_api_chmod](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2058); **stub**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1851).

This API is not implemented, as the FatFS `f_chmod` function is not supported by the current configuration of the FatFS library used in MOS.

The purpose of the `f_chmod` function is to change the attributes set against a file or directory.  A future version of MOS may include support for this API.

Returns:

- `A`: `23` (Not implemented)

<a id="api-9a"></a>

### 9A — ffs_utime

Source: [ffs_api_utime](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2060); **stub**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1861).

This API is not implemented, as the FatFS `f_utime` function is not supported by the current configuration of the FatFS library used in MOS.

The purpose of the `f_utime` function is to change the timestamp of a file or directory.  A future version of MOS may include support for this API.

Returns:

- `A`: `23` (Not implemented)

<a id="api-9b"></a>

### 9B — ffs_mkdir

Source: [ffs_api_mkdir](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2068); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1871).

Creates a new directory

Parameters:

- `HL(U)`: Pointer to a zero-terminated directory name string

Returns:

- `A`: `FRESULT`

<a id="api-9c"></a>

### 9C — ffs_chdir

Source: [ffs_api_chdir](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2082); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1883).

Change the current working directory

It is strongly recommended to use the [`mos_cd` API](https://agonplatform.github.io/agon-docs/mos/API/#0x03-mos_cd) API call instead of this one, as it will automatically resolve the path for you.  Using this API may result in MOS not understand the current working directory until a call to `mos_cd` is made or a version of the [`CD` command](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./Star-Commands.md#cd) is run.

Parameters:

- `HL(U)`: Pointer to a zero-terminated directory name string

Returns:

- `A`: `FRESULT`

<a id="api-9d"></a>

### 9D — ffs_chdrive

Source: [ffs_api_chdrive](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2091); **stub**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1897).

This API is not implemented, as no Agon platform computer currently supports multiple drives.

<a id="api-9e"></a>

### 9E — ffs_getcwd

Source: [ffs_api_getcwd](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2099); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1901).

Get the current working directory (Available from MOS 2.2.0)

Parameters:

- `HL(U)`: Pointer to a buffer to store the directory path in
- `BC(U)`: Maximum length of the buffer

Returns:

- `A`: `FRESULT`

Preserves: `HL(U)`, `BC(U)`

<a id="api-9f"></a>

### 9F — ffs_mount

Source: [ffs_api_mount](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2120); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1916).

Mounts a volume/SD card

Whilst this API has documented parameters, as the current hardware configurations of Agon machines do not support multiple volumes or drives all of the parameters will be ignored.  They are documented here for completeness, and to allow for future expansion of the API in case a future Agon model is released that does support multiple SD cards.  For future compatibility you are advised to set all parameters to zero.

Parameters:

- `HL(U)`: Pointer to a blank FATFS `FATFS` structure (set to zero)
- `DE(U)`: Pointer to a zero-terminated volume path string (set to zero)
- `C`: Options byte (set to zero)

Returns:

- `A`: `FRESULT`

<a id="api-a0"></a>

### A0 — ffs_mkfs

Source: [ffs_api_mkfs](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2123); **stub**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1932).

This API is not implemented, as the FatFS `f_mkfs` function is not supported by the current configuration of the FatFS library used in MOS.

Returns:

- `A`: `23` (Not implemented)

<a id="api-a1"></a>

### A1 — ffs_fdisk

Source: [ffs_api_fdisk](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2125); **stub**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1940).

This API is not implemented, as the FatFS `f_fdisk` function is not supported by the current configuration of the FatFS library used in MOS.

Returns

- `A`: `23` (Not implemented)

<a id="api-a2"></a>

### A2 — ffs_getfree

Source: [ffs_api_getfree](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2137); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1948).

Get free space information on a volume

Please note that this call does not directly return the number of free bytes on the volume, but instead returns the number of free clusters and the size of each cluster.  The number of free bytes can be calculated by multiplying these two values together.

Parameters:

- `HL(U)`: Pointer to a path string (ideally caller should set this to zero)
- `DE(U)`: Pointer to a block of memory to store number of free clusters, 32-bit value
- `BC(U)`: Pointer to a block of memory to store cluster size, 32-bit value

Returns:

- `A`: `FRESULT`

Whilst this API will let you pass in a pointer to a path in the `HL(U)` register, you are recommended to set this to `0`, as the way that MOS uses FatFS means that the path is not needed, and the call will likely fail if any path other than an empty string is provided.  This API call also differs slightly from the underlying `f_getfree` function which does not directly return the cluster size, but instead returns a pointer to the `FATFS` structure for the volume, which will contain the cluster size.  As the `FATFS` structure is sensitive to the FatFS configuration and may change in future versions of MOS, we have chosen to return the cluster size directly instead.

<a id="api-a3"></a>

### A3 — ffs_getlabel

Source: [ffs_api_getlabel](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2164); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1966).

Gets the label of a volume

- `HL(U)`: Pointer to a path string (ideally caller should set this to zero)
- `DE(U)`: Pointer to a buffer to store the label in (for safety and future proofing this should be 23 bytes long)
- `BC(U)`: Pointer to a block of memory to store the 32-bit volume serial number

Returns:

- `A`: `FRESULT`

As with the [`ffs_getfree` API](https://agonplatform.github.io/agon-docs/mos/API/#0xa2-ffs_getfree) you should set the `HL(U)` parameter to `0`, as the way that MOS uses FatFS means that the path is not needed, and the call will likely fail if any path other than an empty string is provided.

It should be noted that this API call does not include a parameter for the size of the buffer to store the label in.  If your buffer is not large enough any memory after the label may be overwritten.  As of MOS 3.0 the maximum size of a volume label is 12 bytes (11 characters plus a zero terminator), however for future proofing you are advised to ensure your buffer is 23 bytes long.  The reason for this is that in the future we may enable support for discs using the exFAT filing system, which supports longer volume labels.

<a id="api-a4"></a>

### A4 — ffs_setlabel

Source: [ffs_api_setlabel](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2190); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1982).

Sets the label of a volume

Please note that the label string must be a valid FAT volume label, which basically means that it must be 11 characters or less.  Setting a label to an empty string will remove the label.

Owing to how filing systems work some labels may be rejected, and characters may be converted to upper-case.  The `f_setlabel` function that this API calls will attempt to look for a "drive prefix" in the label to specify a drive number, but owing to how we use FatFS in MOS this will not work.  As such you should not include a drive prefix in the label.

Parameters:

- `HL(U)`: Pointer to a zero-terminated volume label string

Returns:

- `A`: `FRESULT`

<a id="api-a5"></a>

### A5 — ffs_setcp

Source: [ffs_api_setcp](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2196); **stub**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L1998).

This API is not implemented, as the FatFS `f_setcp` function is not supported by the current configuration of the FatFS library used in MOS.

The purpose of `f_setcp` is to set the active code page for file paths, and this is not available as our FatFS configuration is restricted to a single code page.  Adding this feature would greatly expand the size of FatFS, and consequently also MOS, which would almost certainly exceed the available flash space on the eZ80.  As such it is highly unlikely that this API will be implemented in the future.

Returns:

- `A`: `23` (Not implemented)

<a id="api-a6"></a>

### A6 — ffs_flseek_p

Source: [ffs_api_flseek_p](https://github.com/AgonPlatform/agon-mos/blob/8336409351ee5314e02801a7b72a4f1bb5282519/src/mos_api.asm#L2205); **implemented**. Documentation: [pinned section](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/API.md#L2008).

Move the read/write offset pointer in a file

This API can be used to expand the size of a file, although you should note that the file data in the expanded part will be undefined.

Whilst the [`ffs_flseek`](https://agonplatform.github.io/agon-docs/mos/API/#0x84-ffs_flseek) API can essentially perform the same function as this API, this is the preferred API to use for moving the current read/write pointer offset within a file.  As it accepts a pointer to the 32-bit offset value, it is compatible with both Z80-mode and ADL-mode code.

Parameters:

- `HL(U)`: Pointer to a `FIL` structure
- `DE(U)`: Pointer to a 32-bit value for the desired new offset from the start of the file

Preserves: `HL(U)`, `BC(U)`

Returns:

- `A`: Status code

## C-function selectors through mos_getfunction

The B-selector namespace is separate from A/RST 08. All 18 slots are retained.
Functions 03 and 04 are reserved NULL entries. The remainder are source-present;
lookup does not prove an AgonDev prototype or call site is correct.

| B | Target |
| --- | --- |
| 00 | `_SD_init` |
| 01 | `_SD_readBlocks` |
| 02 | `_SD_writeBlocks` |
| 03 | `0` |
| 04 | `0` |
| 05 | `_f_printf` |
| 06 | `_f_findfirst` |
| 07 | `_f_findnext` |
| 08 | `_open_UART1` |
| 09 | `_setVarVal` |
| 0A | `_readVarVal` |
| 0B | `_gsTrans` |
| 0C | `_substituteArgs` |
| 0D | `_resolvePath` |
| 0E | `_getDirectoryForPath` |
| 0F | `_resolveRelativePath` |
| 10 | `func_getsysvars` |
| 11 | `func_getkbmap` |

The following prototypes and contracts are pinned documentation extracts; the
SD count discrepancy above applies.

### 0x00 - `BYTE	SD_init();`

Initialises the low-level SD card handling system

### 0x01 - `BYTE	SD_readBlocks(DWORD sector, BYTE *buf, WORD count);`

Read raw sector data from SD card.

`DWORD` is a 32-bit value, `WORD` is a 16-bit value, and `BYTE` is an 8-bit value.  The `buf` pointer is a pointer to a buffer of data that will be filled with the data read from the SD card.  The `count` parameter indicates how many bytes to read from the SD card.

### 0x02 - `BYTE	SD_writeBlocks(DWORD sector, BYTE *buf, WORD count);`

Write raw sector data to SD card.

This function works in a similar way to the `SD_readBlocks` function.  The `buf` pointer here is a pointer to the buffer of data used to write to the SD card.

### 0x03 - n/a

Calling `mos_getfunction` asking for this function number will succeed, but return a `NULL` pointer.

Reserved for potential future `SD_status` function

### 0x04 - n/a

Calling `mos_getfunction` asking for this function number will succeed, but return a `NULL` pointer.

Reserved for potential future `SD_ioctl` function

### 0x05 - `int	f_printf (FIL* fp, const TCHAR* str, ...);`

The FatFS `f_printf` function.  This function is documented in the [FatFS documentation](http://elm-chan.org/fsw/ff/doc/printf.html).

### 0x06 - `FRESULT	f_findfirst (DIR* dp, FILINFO* fno, const TCHAR* path, const TCHAR* pattern);`

The FatFS `f_findfirst` function, equivalent to the [`ffs_dfindfirst`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x94-ffs_dfindfirst) API call.  This function is documemented in the [FatFS documentation](http://elm-chan.org/fsw/ff/doc/findfirst.html).

Please note that for C functions, an `FRESULT` is an `int` type, and therefore will be returned in the `HLU` register.  This differs from the MOS APIs for FatFS which returns an 8-bit `FRESULT` value.  The return values however are otherwise identical.

### 0x07 - `FRESULT	f_findnext (DIR* dp, FILINFO* fno);`

The FatFS `f_findnext` function, equivalent to the [`ffd_dfindnext`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x95-ffs_dfindnext) API call.  This function is documemented in the [FatFS documentation](http://elm-chan.org/fsw/ff/doc/findnext.html).

As with the `f_findfirst` function, an `FRESULT` is an `int` type, and will be returned in the `HLU` register.

### 0x08 - `BYTE	open_UART1(UART * pUART);`

Equivalent to the [`mos_uopen`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x15-mos_uopen) API call.  Please refer to the API documentation for details of the `UART` structure.

### 0x09 - `int		setVarVal(char * name, void * value, char ** actualName, BYTE * type);`

The underlying function the [`mos_setvarval`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x30-mos_setvarval) API call uses.  Please see the API documentation for information about variable names and types.

Please note that the way this function works differs slightly from the API; the API handles creating pointers for some arguments, and getting the values from them to return in registers.

The parameters are as follows:
- `name` is the name of the variable to set.  As with the API, if this name is a pattern the first matched name will be set, unless an `actualName` pointer has been provided.
- `value` is a pointer to the value to be set, or if setting a number type variable this will be the actual number to set.
- `actualName` is a pointer to a pointer to a string.  Providing this pointer is optional, but if it is set then on first call the pointer it points to should be set to `NULL`.  After the function has been called, the pointer will be set to the actual name string of the variable that has been set.  Please note that it is important to not adjust that string in any way.  If you have used a pattern in the `name` parameter, and have provided an `actualName` pointer, then subsequent calls to this function will set the next variable that matches the pattern, and the `actualName` pointer will be updated accordingly.
- `type` is a pointer to a `BYTE` for the variable type to be set.  This is required.  This value will be updated after the function has been called to reflect the actual type of the variable that has been set; please note that varible types 3 and 4 ("expanded" and "literal string") will be replaced with either "string" or "number" as appropriate.

The return value is a [MOS status code](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#status-codes), which will be in the `HLU` register.

### 0x0A - `int		readVarVal(char * namePattern, void * value, char ** actualName, int * length, BYTE * typeFlag);`

The underlying function the [`mos_readvarval`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x31-mos_readvarval) API call uses.

This function is very similar to the `setVarVal` function, and it's arguments work in a very similar way.  These are the differences:

- `value` can be `null` to measure the length of a variable, but otherwise must always point to a buffer into which the variable value will be read/copied.  This is in contrast to the `setVarVal` function which will accept a raw number as the value to be set for "number" type variables.
- a pointer to a 24-bit `length` value is required.  On entry, this indicates the length of the `value` buffer, if one has been provided.  If a matching variable is found, this value will always be updated to reflect the full length of the variable that has been read, or will be `0` if no variable was found.
- the `typeFlag` pointer is required.  On entry, if the value this points to is `3` then the variable being read will be "expanded" before it is returned.  This means that if the variable being read is a "macro" type, the returned string will be the expanded string with variables referenced in the macro replaced with their values.  If the variable being read is a "number", then it will be converted into a string.  On return, this value will be set to the underlying type of the variable that has been read, if a variable was found.

The return value from this function is a [MOS status code](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#status-codes), which will be in the `HLU` register.  If a `value` buffer was provided, and the variable was found, then the value will be copied into that buffer.  If the buffer was not large enough to hold the variable then as much of the variable as will fit will be copied into the buffer, the `length` will reflect the total length of the variable (which will be more than was copied) and the function will return an "out of memory" status code.

### 0x0B - `int		gsTrans(char * source, char * dest, int destLen, int * read, BYTE flags);`

The underlying function the [`mos_gstrans`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x34-mos_gstrans) API call uses.

The "GSTrans" functionality in MOS is used to translate a source string that may include references to [system variables](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./System-Variables.md) into a new string with those variables expanded.  It can also convert other special character sequences into non-printable characters.  Guidance on this can be found in the documentation for the [`echo`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./Star-Commands.md#echo) star command.

The arguments to this function are as follows:

- `source` is a pointer to the source "template" string to be translated
- `dest` is a pointer to the destination buffer where the translated string will be written.  If this is set to `NULL` then the function will not write to the buffer, but will still calculate the length of the translated string.
- `destLen` is the size of the destination buffer, if one is provided
- `read` is a pointer to an integer to store the number of translated characters read from source
- `flags` is a set of flags that control how the translation is performed.  These flags are described in the [`mos_gsinit`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x32-mos_gsinit) API documentation.

The `source` and `read` pointers are both always required.  The `dest` pointer is optional, but if provided it cannot be the same as the `source` pointer.

The GSTrans process essentially performs a call to the [`mos_gsinit`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x32-mos_gsinit) API and then calls [`mos_gsread`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x33-mos_gsread) until it reaches the end of the source string.

This function returns a [MOS status code](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#status-codes), which will be in the `HLU` register.  Various return values are possible, and may indicate that the source string was not valid, or various other errors.

### 0x0C - `int	substituteArgs(char * template, char * args, char * dest, int length, BYTE flags);`

The underlying function the [`mos_substituteargs`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x35-mos_substituteargs) API call uses to perform [argument substitution](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./Argument-Substitution.md).

This function works in a very similar manner to its corresponding API call.  For information on the arguments to this function, please see the API documentation.

The return value from this function is the total length of the substituted string.  If a destination buffer was provided that was not large enough to hold the entire substituted string then the function will fill the buffer with as much of the substituted string as will fit.

### 0x0D - `int	resolvePath(char * filepath, char * resolvedPath, int * length, BYTE * index, DIR * dir, BYTE flags);`

The underlying function the [`mos_resolvepath`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x38-mos_resolvepath) API call uses.

The `resolvePath` function resolves a file path.  The primary use for this function is to take a MOS-style file path that may include a [path prefix](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./System-Variables.md#path-variables) or use other [system variables](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./System-Variables.md) and to resolve it into a full path that can be used by the underlying file system, i.e. the [FatFS APIs](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#fatfs-commands).  It can also be used to find files within a directory that match a given pattern.

The arguments to this function are as follows:

- `filepath` is a pointer to the file path string that is to be resolved
- `resolvedPath` is a pointer to the buffer where the resolved path will be written.  If this is set to `NULL` then the function will calculate the length of the resolved path.
- `length` is a pointer to an integer that on entry indicates the size of the `resolvedPath` buffer.  On exit, this will be set to the length of the resolved path.
- `index` is a pointer to a `BYTE` that is used to keep track of which version of a path prefix is being used.  This is used when resolving paths that use a prefix where the corresponding system variable contains multiple values.  If the `index` pointer is set to `NULL` then only the first matching path will be returned.  You can use this to manually iterate through the available prefixes.
- `dir` is a pointer to a `DIR` object.  This is optional, but if it is not provided then the function can only return the first matching path.  If a `DIR` object is provided, then repeated calls to this function can be used to find all matching paths.  This is useful for finding files that match a given pattern.
- `flags` is a set of flags that control how the path is resolved.  These flags are described in the [`mos_resolvepath`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x38-mos_resolvepath) API documentation.

This function will return a [MOS status code](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#status-codes), in the `HLU` register.  For more guidance on possible return values, please see the API documentation for the [`mos_resolvepath`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x38-mos_resolvepath) API call.

### 0x0E - `int getDirectoryForPath(char * srcPath, char * dir, int * length, BYTE index);`

The underlying function the [`mos_getdirforpath`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x39-mos_getdirforpath) API call uses.

This function will return the directory for a given file path, omitting the leaf name.

The arguments to this function are as follows:

- `srcPath` is a pointer to the file path string that is to be resolved
- `dir` is a pointer to the buffer where the resolved path will be written.  If this is set to `NULL` then the function will calculate the length of the resolved path.
- `length` is a pointer to an integer that on entry indicates the size of the `dir` buffer.  On exit, this will be set to the length of the resolved path.
- `index` is used to determine which version of a path prefix is used

This function is purely a string manupulation function.  It does not perform any filing system operations,

This function returns a [MOS status code](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#status-codes), in the `HLU` register.  If the path contains a prefix that is not recognised, or if the prefix was recognised but the `index` value is out of range, then the function will return a "no path" status code.

### 0x0F - `int resolveRelativePath(char * path, char * resolved, int * length);`

This is the underlying function that [`mos_api_getabsolutepath`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x3c-mos_getabsolutepath) uses.

This function will take a relative path, i.e. one that may contain `.` or `..` path components, and resolve it into an absolute path.  Please note that this function does not perform a file path resolution, i.e. it will not resolve any path prefixes or system variables.  This function does however verify that the path provided is valid (at least in terms of does the containing directory exist), and will return an error if it is not.

At the time of writing, this function requires both the source `path` argument and a destination `resolved` pointer to be provided.  To come into line with other functions this may change in the future to allow for the `resolved` pointer to be `NULL` in order to calculate the length of the resolved path.  As with the other functions above, the `length` pointer is used to indicate the size of the destination buffer, and will be updated to reflect the length of the resolved path.

Returns a [MOS status code](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#status-codes), in the `HLU` register.

### 0x10 - `void * getsysvars()`

Returns a pointer to the system variables area.  Directly equivalent to the [`mos_sysvars`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x08-mos_sysvars) API call.

The sysvars pointer will be returned in the `HLU` register.

### 0x11 - `void * getkbmap()`

Returns a pointer to the keyboard map.  Directly equivalent to the [`mos_getkbmap`](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./API.md#0x1e-mos_getkbmap) API call.

The keyboard map pointer will be returned in the `HLU` register.



## Shared layouts and status domain

System-state sysvars are distinct from named MOS 3 variables. Use pinned
`src_startup/globals.asm` and `src/mos_api.inc` for offsets; use configured
`src_fatfs/ff.h` for FIL, DIR and FILINFO rather than host structures.
FatFS uses 512-byte sectors, one volume, no exFAT, long names up to 255,
code page 437, tiny FIL configuration and stack LFN workspace. Formatting,
chmod, expand and forward functionality are disabled in this build.

## Status Codes

Many MOS API calls will return a status code in the `A` register.  In general these follow a consistent set of result values, with a few exceptions which are documented against the individual API calls.  Programs and commands will also return a status code when they complete.  If you are using MOS 3, the status code value can be captured in a system variable if the command or program is run using the [`try` command](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./Star-Commands.md#try).

API calls that are documented above as returning an `FRESULT` value are returning a status code from the FatFS library.  These directly equate to status codes 0-19 in the table below.

Status codes can be translated into a human-readable string using the [`mos_getError`](https://agonplatform.github.io/agon-docs/mos/API/#0x0f-mos_geterror) API call.

The possible status codes are as follows:

| Code | Error message | Description |
| ---- | ------------------- | ----------- |
| 0    | OK | Call succeeded (NB this will not be displayed when running a program or star command) |
| 1	   | Error accessing SD card | An error has occurred when trying to access the SD card |
| 2    | Internal error | An internal error has occurred.  Generally, if possible, a more specific error will be used |
| 3    | SD card failure | The SD card has failed |
| 4    | Could not find file | The file could not be found |
| 5    | Could not find path | The path could not be found |
| 6    | Invalid path name | The path name is invalid |
| 7    | Access denied or directory full | A file could not be saved to a directory either because of an access error or too many files in the directory |
| 8    | Access denied | A file or directory cannot be accessed because it is not readable |
| 9    | Invalid file/directory object | This is an internal filing system error |
| 10   | SD card is write protected | The SD card cannot be written to as it is write protected |
| 11   | Logical drive number is invalid | This is an internal filing system error, which should not occur |
| 12   | Volume has no work area | This is an internal filing system error |
| 13   | No valid FAT volume | The SD card does not contain a FAT format volume your Agon can understand |
| 14   | Error occurred during mkfs | This is an internal filing system error |
| 15   | Volume timeout | A problem has occured attempting to access your SD card |
| 16   | Volume locked | The FAT volume cannot be written to |
| 17   | LFN working buffer could not be allocated | This is an internal filing system error |
| 18   | Too many open files | Occurs when too many separate files have been opened |
| 19   | Invalid parameter | A parameter for the command or API is incorrect |
| 20   | Invalid command | The command was not recognised or found on disc |
| 21   | Invalid executable | An executable program does not have a valid header |
| 22   | Out of memory | Either MOS has run out of internal memory, or a buffer provided to an API was not large enough |
| 23   | Not implemented | The API call is not implemented in this version of MOS |
| 24   | Load overlaps system area | File load prevented to stop overlapping system memory |
| 25   | Bad string | A bad or incomplete string has been encountered |
| 26   | Too deep | Too many nested commands have been detected<br>This is usually caused by a faulty [alias](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./System-Variables.md#command-aliases) definition including [file load/run types](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./System-Variables.md#file-type-variables) |

Please note that Quark MOS 1.04 will only return status codes 0-21.  The MOS 2.x release series added status codes 22-25, and MOS 3.0 added status code 26.

## System State Information (SysVars) {#sysvars}

The MOS API command [mos_sysvars](https://agonplatform.github.io/agon-docs/mos/API/#0x08-mos_sysvars) returns a pointer to the base of the MOS SysVars (system state variables/information) area in IXU as a 24-bit pointer.  These are different from [System Variables](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./System-Variables.md) which can be used in commands and scripts, so these these internal MOS system state variables are often simply referred to as sysvars.

The following sysvars are available in [mos_api.inc](https://agonplatform.github.io/agon-docs/mos/API/#rst):

```
; SysVars (System State Information) indexes for api_sysvars
; Index into _sysvars in globals.asm
;
sysvar_time:			EQU	00h	; 4: Clock timer in centiseconds (incremented by 2 every VBLANK)
sysvar_vpd_pflags:		EQU	04h	; 1: Flags to indicate completion of VDP commands
sysvar_keyascii:		EQU	05h	; 1: ASCII keycode, or 0 if no key is pressed
sysvar_keymods:			EQU	06h	; 1: Keycode modifiers
sysvar_cursorX:			EQU	07h	; 1: Cursor X position
sysvar_cursorY:			EQU	08h	; 1: Cursor Y position
sysvar_scrchar:			EQU	09h	; 1: Character read from screen
sysvar_scrpixel:		EQU	0Ah	; 3: Pixel data read from screen (R,B,G)
sysvar_audioChannel:	EQU	0Dh	; 1: Audio channel
sysvar_audioSuccess:	EQU	0Eh	; 1: Audio channel note queued (0 = no, 1 = yes)
sysvar_scrWidth:		EQU	0Fh	; 2: Screen width in pixels
sysvar_scrHeight:		EQU	11h	; 2: Screen height in pixels
sysvar_scrCols:			EQU	13h	; 1: Screen columns in characters
sysvar_scrRows:			EQU	14h	; 1: Screen rows in characters
sysvar_scrColours:		EQU	15h	; 1: Number of colours displayed
sysvar_scrpixelIndex:	EQU	16h	; 1: Index of pixel data read from screen
sysvar_vkeycode:		EQU	17h	; 1: Virtual key code from FabGL
sysvar_vkeydown			EQU	18h	; 1: Virtual key state from FabGL (0=up, 1=down)
sysvar_vkeycount:		EQU	19h	; 1: Incremented every time a key packet is received
sysvar_rtc:				EQU	1Ah	; 8: Real time clock data
sysvar_keydelay:		EQU	22h	; 2: Keyboard repeat delay
sysvar_keyrate:			EQU	24h	; 2: Keyboard repeat rate
sysvar_keyled:			EQU	26h	; 1: Keyboard LED status
sysvar_scrMode:			EQU	27h	; 1: Screen mode (from MOS 1.04)
sysvar_rtc_enable:		EQU 28h ; 1: RTC enable status (from MOS 2.0.0)
sysvar_mouseX:			EQU 29h ; 2: Mouse X position
sysvar_mouseY:			EQU 2Bh ; 2: Mouse Y position
sysvar_mouseButtons:	EQU 2Dh ; 1: Mouse left+right+middle buttons (bits 0-2, 0=up, 1=down)
sysvar_mouseWheel:		EQU 2Eh ; 1: Mouse wheel delta
sysvar_mouseXDelta:		EQU 2Fh ; 2: Mouse X delta
sysvar_mouseYDelta:		EQU 31h ; 2: Mouse Y delta
```

Example: Reading a virtual keycode in ADL mode (24-bit):
```
		MOSCALL	mos_getkey
		LD	A, (IX + sysvar_vkeycode)	; Load A with the virtual keycode from FabGL
```

Example: Reading a virtual keycode in Z80 mode (16-bit):
```
		MOSCALL	mos_getkey
		LD.LIL	A, (IX + sysvar_vkeycode)	; Load A with the virtual keycode from FabGL
```

### VDP pflags (vdpflags)
The bits to manipulate the flags for `sysvar_vpd_pflags` are defined in the MOS `equs.inc`. They names are relatively self documenting, describing the category of update each is related to. The bits assigned are defined as follows:
```
VDPP_FLAG_CURSOR:	EQU		00000001b
VDPP_FLAG_SCRCHAR:	EQU		00000010b
VDPP_FLAG_POINT:	EQU		00000100b
VDPP_FLAG_AUDIO:	EQU		00001000b
VDPP_FLAG_MODE:		EQU		00010000b
VDPP_FLAG_RTC:		EQU		00100000b
VDPP_FLAG_MOUSE:	EQU		01000000b
```

### Real Time Clock {#sysvar_rtc}

For efficiency, the real-time clock data in the sysvars is stored in a packed format, using subsets of bits within the 8 bytes of the `sysvar_rtc` data.  An API is provided from MOS 3 onwards to allow for this to be unpacked [mos_unpackrtc](https://agonplatform.github.io/agon-docs/mos/API/#0x23-mos_unpackrtc) into a buffer in a friendlier, more easy to use format.  MOS uses the following C function to unpack the RTC data into a `vdp_time_t` object:
```c
void rtc_unpack(UINT8 * sysvar_rtc, vdp_time_t * t) {
	UINT32	d = *(UINT32 *)sysvar_rtc;

	t->month =		(d & 0x0000000F);		// uint32_t month : 4; 		00000000 00000000 00000000 0000xxxx : 00 00 00 0F >> 0
	t->day =		(d & 0x000001F0) >> 4;	// uint32_t day : 5;		00000000 00000000 0000000x xxxx0000 : 00 00 01 F0 >> 4
	t->dayOfWeek = 	(d & 0x00000E00) >> 9;	// uint32_t dayOfWeek : 3;	00000000 00000000 0000xxx0 00000000 : 00 00 0E 00 >> 9
	t->dayOfYear = 	(d & 0x001FF000) >> 12;	// uint32_t dayOfYear : 9;	00000000 000xxxxx xxxx0000 00000000 : 00 1F F0 00 >> 12
	t->hour = 		(d & 0x03E00000) >> 21;	// uint32_t hour : 5;		000000xx xxx00000 00000000 00000000 : 03 E0 00 00 >> 21
	t->minute =		(d & 0xFC000000) >> 26;	// uint32_t minute : 6;		xxxxxx00 00000000 00000000 00000000 : FC 00 00 00 >> 26

	t->second = sysvar_rtc[4];
	t->year = (char)sysvar_rtc[5] + 1980;
}
```

This real-time clock data is also available to programs, scripts, and the command line via [system variables](https://github.com/AgonPlatform/agon-docs/blob/f9806bd3cbff6ed5d1c08bef1d51fed11764b86b/docs/mos/./System-Variables.md#time-and-date).
