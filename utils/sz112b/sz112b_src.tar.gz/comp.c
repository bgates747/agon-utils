#define GLOBALRANGECODER
#define MODELGLOBAL

#include "rangecod.c"
#include "qsmodel.c"
#include "bitmodel.c"
#include "sz_mod4.c"
#include "szip.c"
#include "sz_srt.c"
#include "reorder.c"
